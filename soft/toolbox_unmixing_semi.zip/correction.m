function [R_out, alphaPlus_out, indMPlus_out] = correction(R, alphaPlus, indMPlus)

ind_neg = find(alphaPlus<0.01);

ind_sig = setdiff(1:R,ind_neg);

R_out = length(ind_sig);
alphaPlus_out = alphaPlus(ind_sig);
indMPlus_out  = indMPlus(ind_sig);