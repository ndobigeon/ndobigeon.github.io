function flag = saving_txt(fname,data,row_title,col_title)

[R P] = size(data);

A_cell{1,1} = '######';
for p=1:P
    A_cell{1,p+1} = col_title{p};
    for r=1:R
        A_cell{r+1,p+1} = data(r,p);
    end
end
for r=1:R
    A_cell{r+1,1} = row_title{r};
end

fid = fopen(fname, 'wt');
fprintf(fid,'%s\t',A_cell{1,1:(P+1)});
fprintf(fid,'\n');
for r=1:R
    fprintf(fid,'%s\t',A_cell{r+1,1});
    fprintf(fid,'%f\t',A_cell{r+1,(1:P)+1});
    fprintf(fid,'\n');
end
fclose(fid);

flag = 1;