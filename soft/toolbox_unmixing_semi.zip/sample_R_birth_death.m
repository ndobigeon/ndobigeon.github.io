function [R_out, alphaPlus_out, indMPlus_out] = sample_R_birth_death(R,alphaPlus,indMPlus,y,sigma2,proba_d,proba_u,proba_b,MBiblio,Rmax)

MPlus = MBiblio(:,indMPlus);


% on choisit le type de move
move_R = gen_discrete([-1 0 1],[proba_d(R) proba_u(R) proba_b(R)],1,1);

% on calcul le candidat
R_star = R + move_R;  
    
    
% si on a propos� un mouvement
if R_star ~= R
    % si on augmente R
    if move_R==1
        % il faut ajouter un spectre al�atoirement
        indM = gen_discrete(setdiff(1:Rmax,indMPlus),ones(1,Rmax-R)/(Rmax-R),1,1);
        indMPlus_star = [indMPlus indM];
        
        MPlus_star = MBiblio(:,indMPlus_star);
        
        % il faut ajouter un coef d'abondance
        w = betarnd(1,R,1,1);      
        alphaPlus_star = [alphaPlus*(1-w); w];
        
    % si on diminue R
    else % ie move_R = -1
        
        % il faut enlever un spectre al�atoirement et l'abondance
        % correspondant
        
        i = unidrnd(R);
        indMPlus_star = indMPlus;
        indMPlus_star(i) = [];        
        MPlus_star = MBiblio(:,indMPlus_star);

        alphaPlus_star = alphaPlus;
        w = alphaPlus(i);
        alphaPlus_star(i) = [];
        
        % poids du composant tu�
        alphaPlus_star = alphaPlus_star/sum(alphaPlus_star);        
    end
   
    % on �value la proba de jump
    choix = compute_proba_move_birth_death(MPlus_star,MPlus,alphaPlus_star,alphaPlus,R_star,R,sigma2,y,proba_d,proba_b,w,Rmax);
    
    if choix == 1
        %disp(['accepted jump:' int2str(R_star-R)])
        R_out = R_star;
        alphaPlus_out = alphaPlus_star;
        indMPlus_out = indMPlus_star;
    else
        R_out = R;
        %disp(['refused jump:' int2str(R_star-R)])
        alphaPlus_out = alphaPlus;
        indMPlus_out = indMPlus;
    end
    
else
    
%     % on n'a pas propos� de mouvement
%     R_out = R; 
%     
%     alphaPlus_out = alphaPlus;
%     indMPlus_out = indMPlus;

    [alphaPlus_out, indMPlus_out] = sample_R_switch(R,alphaPlus,indMPlus,y,sigma2,MBiblio,Rmax);
    R_out = R;
end


    
