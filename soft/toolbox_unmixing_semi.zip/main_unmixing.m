clc
clear all
close all

% loading: endmembers;
nfile_endm = 'data_TC_signatures_matlab';
data = load([nfile_endm '.mat'], nfile_endm);
data = getfield(data,nfile_endm);

wavelength_end = data(1:(end-1),1);
SpecLib = data(1:(end-1),2:end);

figure
plot(wavelength_end,SpecLib)

% loading: data hc;
nfile_data = 'data_TC_hc_matlab';
data = load([nfile_data '.mat'], nfile_data);
data = getfield(data,nfile_data);

wavelength = data(:,1);
mixtures = data(:,2:end);
Npix = size(mixtures,2);

figure
plot(wavelength,mixtures)

% UNMIXING
pause
switch nfile_data
    case 'data_TC_hc_matlab'
        R = 5;        
    case 'data_TC_hc_ga_matlab'
        R = 3;
end

M = SpecLib(:,1:R);
MAPabund = zeros(R,Npix);
Nbi = 300;
Nmc = 1000;
for i=1:Npix
    i
    temp = unmixing(mixtures(:,i),M,Nmc);
    MAPabund(:,i) = mean(temp(:,Nbi:end),2);
    plot(temp')
    pause
end

save results_unmixing_hc.mat MAPabund M -MAT
save results_unmixing_hc.txt MAPabund -ASCII
