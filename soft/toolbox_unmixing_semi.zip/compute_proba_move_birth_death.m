function choix = compute_proba_move_birth_death(MPlus_star,MPlus,alphaPlus_star,alphaPlus,R_star,R,sigma2,y,proba_d,proba_b,w,Rmax)

% alpha_star = alphaPlus_star(1:R_star-1);
% alpha =  alphaPlus(1:R-1);

% calcul de la proba d'acceptation
% rapport des vraisemblances
A = -(norm(y-MPlus_star*alphaPlus_star)^2)/(2*sigma2) + (norm(y-MPlus*alphaPlus)^2)/(2*sigma2);



% Jacobien
if R_star-R == 1
    A = A + (R-1)*log(1-w);
else
    A = A - (R-2)*log(1-w);
end

% rapport des proba de move
if R_star-R == 1
    A = A + log(proba_d(R+1)) - log(proba_b(R));
else
    A = A - log(proba_d(R)) + log(proba_b(R-1));
end

% proposal de w
if R_star-R == 1
    A  = A - log(betapdf(w,1,R)) ;
else
    A  = A + log(betapdf(w,1,R-1));
end

% % proposal de s*
% if R_star-R == 1
%     A  = A - log(Rmax-R);
% else
%     A  = A + log(Rmax-(R-1));
% end


% rapport des priors
if R_star-R == 1
    A  = A + log(R);
else
    A  = A - log(R-1);
end

rapport = exp(A);

% terme issus de la proposal : d�pend si R -> R +/- 1
% rapport_q_qstar = 1;

% proba finale
% rapport des priors
    proba_accept_move =  min([1, rapport]);

% on tire suivant cette proba
choix = gen_discrete([1 0],[proba_accept_move 1-proba_accept_move],1,1);


    


