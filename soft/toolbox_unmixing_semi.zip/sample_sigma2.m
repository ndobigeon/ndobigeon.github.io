function sigma2_out = sample_sigma2(L,y,MPlus,R,alphaPlus)

x = gen_gamma(L/2,(norm(y-MPlus(:,1:R)*alphaPlus)^2)/2);
sigma2_out = 1/x;
