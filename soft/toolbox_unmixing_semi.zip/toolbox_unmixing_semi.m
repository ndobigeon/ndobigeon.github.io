clc
clear all
close all

% loading: endmembers;
[filename, pathname] = uigetfile('*.txt', 'Loading the endmembers (.txt format)');
fname_endm = [pathname filename];

[endm_data endm_name wavelength_end] = loading_txt(fname_endm);
Rlib = size(endm_data,2);

figure(1)
plot(wavelength_end,endm_data)
h = legend(endm_name,'location','NorthWest');
xlabel('Wavelength (nm)')
title('Endmembers')
set(h,'Interpreter','none')

% loading: data;
[filename, pathname] = uigetfile('*.txt', 'Loading the data (.txt format)');
fname_data = [pathname filename];

[mix_data mix_name wavelength_mix] = loading_txt(fname_data);
[L Plib] = size(mix_data);

figure(2)
plot(wavelength_mix,mix_data)
h = legend(mix_name,'location','NorthWest');
xlabel('Wavelength (nm)')
title('Mixtures')
set(h,'Interpreter','none')

% choosing the endmembers
flag = 0;
endm_ind = [];

while ~flag || length(endm_ind)<2
    [endm_ind,flag] = listdlg('Name', 'Endmember choice','PromptString','Select (at least 2) endmembers', 'SelectionMode','multiple','ListString',endm_name);
end
M = endm_data(:,endm_ind);
Rmax = size(M,2);

clear flag

% choosing the mixtures
flag = 0;
while ~flag 
    [mix_ind,flag] = listdlg('Name', 'Mixture choice', 'PromptString','Select the mixtures', 'SelectionMode','multiple','ListString',mix_name);
end
Y = mix_data(:,mix_ind);
P = size(Y,2);

clear flag
           
% UNMIXING
Nmc = 2000;
Nbi = 500;
Nr = Nmc-Nbi+1;
A = zeros(3*Rmax+1,P);

tol = 5/100;
for i=1:P
    % estimation
    [TalphaPlus, TindMPlus, TR] = unmixing_semi(Y(:,i),M,Nmc);
    TalphaPlus = TalphaPlus(:,Nbi:Nmc);
    TindMPlus = TindMPlus(:,Nbi:Nmc);
    TR = TR(Nbi:Nmc);
    h = hist(TR,1:Rmax);
    [tmp Rest] = max(h);    
    R_ind = find(sum(TindMPlus~=0)==Rest);
    
    A_chain = TalphaPlus(:,R_ind);
    indM_chain = TindMPlus(:,R_ind);
    
    compt = zeros(1,Rmax);
    ind_est = zeros(1,Rest);
    for r=1:Rmax
        compt(r) = sum(indM_chain(:)==r);
    end
    for r=1:Rest
        [tmp indr] = max(compt);
        ind_est(r) = indr;
        compt(indr) = NaN;        
    end
    ind_est = sort(ind_est);
    indM_chain= sort(indM_chain);
    indM_est = (sum(indM_chain==[zeros(Rmax-Rest,1) ;ind_est(:) ]*ones(1,size(indM_chain,2))))==Rmax;
    
    Aest_current = mean(A_chain(:,indM_est),2);
         
    A(1:Rmax,i) = Aest_current;

    % residual error (NRMSE)
    A(3*Rmax+1,i) = sqrt(sum(abs(Y(:,i)-M*Aest_current).^2)/Rmax)/sqrt(sum(abs(Y(:,i)).^2)/Rmax);    

%     A_chain(A_chain==0) = NaN;
    
    % estimation performance
    A((1:Rmax)+1*Rmax,i) = (mean(diff(A_chain(:,indM_est)')~=0))';

    
    % estimation confidence
    A((1:Rmax)+2*Rmax,i) = mean(abs(A_chain(:,indM_est)-Aest_current*ones(1,sum(indM_est)))<tol,2); 
    

%     A(A==0) = NaN; 
    
    % R estimated
    A(3*Rmax+2,i) = Rest;
    
    % plot
    endm_name_aff = endm_name;
    for r=1:Rest
        endm_name_aff{ind_est(r)} = [endm_name{ind_est(r)} ': ' num2str(100*Aest_current(ind_est(r))) ' %'];
    end
    figure
    plot(wavelength_end,Y(:,i),'k--')
    hold on
    plot(wavelength_end,endm_data(:,ind_est))
    tmp = ['mixt. "' mix_name{mix_ind(i)} '"'];
    h = legend({tmp endm_name_aff{ind_est}},'location','NorthWest');
    set(h,'Interpreter','none')
    xlabel('Wavelength (nm)')
    h2 = title(['Endmembers detected in the mixture "' mix_name{mix_ind(i)} '"']);
    set(h2,'Interpreter','none')

end

endm_name(setdiff(1:Rlib,endm_ind)) = [];
mix_name(setdiff(1:Plib,mix_ind)) = [];

row_title = cell(1,Rmax*3+1);

for r=1:Rmax
    row_title{Rmax*0+r} = ['frac. ' endm_name{r} ' (%)'];
    row_title{Rmax*1+r} = ['perf. ' endm_name{r} ' (%)'];
    row_title{Rmax*2+r} = ['conf. ' endm_name{r} ' (%)'];
end
row_title{Rmax*3+1} = 'Norm. RMSE (%)';
row_title{Rmax*3+2} = 'Estimated number';

col_title = mix_name;

[filename,pathname] = uiputfile('result_semi.txt','Save file name');
fname_result = [pathname filename];

flag = saving_txt(fname_result,A,row_title,col_title);
% 
