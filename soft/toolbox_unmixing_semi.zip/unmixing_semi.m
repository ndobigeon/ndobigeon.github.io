function [TalphaPlus, TindMPlus, TR]= unmixing_semi(y,MBiblio,Nmc)


[L Rmax] = size(MBiblio);

% hyperparam�tres fixes
% nu = 2;
% rho = 2;
% psi = 100;
% mu0 = 0;

% initialisation param�tres/hyperparam�tres

indMPlus = randperm(Rmax);
MPlus = MBiblio(:,indMPlus);
R = length(indMPlus);
sigma2 = 1;

alphaPlus = ones(R,1)/R;

h = waitbar(0,'Monte Carlo sampling...','CreateCancelBtn','closereq', 'name', 'UNMIXING...');

TindMPlus = zeros(Rmax,Nmc);
TalphaPlus = zeros(Rmax,Nmc);
TR = zeros(1,Nmc);

% proba des jumps
if Rmax <= 2
    for m_compt=1:Nmc;
        waitbar(m_compt/Nmc,h)
        % g�n�ration de alpha
        alphaPlus = sample_alphaPlus(alphaPlus,y,MPlus,R,sigma2);  

        TalphaPlus(indMPlus,m_compt) = alphaPlus;

        % g�n�ration de sigma2
        sigma2 = sample_sigma2(L,y,MPlus,R,alphaPlus);
       
        TR(m_compt) = R;
        TindMPlus(1:R,m_compt) = indMPlus;
    end
    
else    
    proba_b = [1/2 1/2  ones(1,Rmax-3)/3  0 ];
    proba_d = [ 0   0   ones(1,Rmax-3)/3 1/2];
    proba_u = 1-(proba_b+proba_d);


    % d�but de la cha�ne
    for m_compt=1:Nmc;
        waitbar(m_compt/Nmc,h)

        % mouvement birth/death
        %[R, alphaPlus, indMPlus] = sample_R(R,alphaPlus,indMPlus,y,sigma2,proba_d,proba_u,proba_b,MBiblio,Rmax);
        [R, alphaPlus, indMPlus ]= sample_R_birth_death(R,alphaPlus,indMPlus,y,sigma2,proba_d,proba_u,proba_b,MBiblio,Rmax);

    %     % mouvement switch
        [alphaPlus, indMPlus ]  = sample_R_switch(R,alphaPlus,indMPlus,y,sigma2,MBiblio,Rmax);

        % correction pour �liminer les abondances n�gligeables
        [R, alphaPlus, indMPlus] = correction(R, alphaPlus, indMPlus);
        TR(m_compt) = R;
        MPlus = MBiblio(:,indMPlus);
        TindMPlus(1:R,m_compt) = indMPlus;

        % g�n�ration de alpha
        alphaPlus = sample_alphaPlus(alphaPlus,y,MPlus,R,sigma2);  

        TalphaPlus(indMPlus,m_compt) = alphaPlus;

        % g�n�ration de sigma2
        sigma2 = sample_sigma2(L,y,MPlus,R,alphaPlus);
    end
end
    
close(h)
% fin de la cha�ne
    