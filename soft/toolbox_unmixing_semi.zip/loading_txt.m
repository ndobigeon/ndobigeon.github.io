function [data name wavelength] = loading_txt(fname)

data = [];
endofile = 0;

fid = fopen(fname, 'r');
fgetl(fid);
while ~endofile
    tline = fgetl(fid);
    if tline == -1
        endofile = 1;
    else
        tline = regexprep(tline, ',', '\t');
        data = [data; sscanf(tline,'%e',inf)'];
    end
end
fclose(fid);

wavelength = data(:,1);
data = data(:,2:end);
R = size(data,2)+1;

fid = fopen(fname, 'r');
name_tmp = textscan(fid, '%q', R+1);
fclose(fid);

name = cell(1,R-1);
for r=1:R-1
    tmp = name_tmp{1}(r+1);
    name{r} = cell2mat(tmp);
end
