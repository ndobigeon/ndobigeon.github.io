function [alphaPlus_out, indMPlus_out] = sample_R_switch(R,alphaPlus,indMPlus,y,sigma2,MBiblio,Rmax)

MPlus = MBiblio(:,indMPlus);


% update si tous les spectres ne sont pas pr�sents

if Rmax-R~=0
    % choix du spectre � remplacer
    indM = gen_discrete(1:R, ones(1,R)/R,1,1);

    % choix du spectre � ajouter
    indMbis = gen_discrete(setdiff(1:Rmax,indMPlus),ones(1,Rmax-R)/(Rmax-R),1,1);    
    indMPlus_star = indMPlus;
    indMPlus_star(indM) = indMbis;

    % on effectue le remplacement
    MPlus_star = MBiblio(:,indMPlus_star);
    
    % on g�n�re un vecteur d'abondance
    % quantit�s communes
%     u = ones(R-1,1);
%     M = MPlus_star(:,1:(R-1));
%     mr = MPlus_star(:,R);
%     invT = inv((M-mr*u')'*(M-mr*u'));

    alphaPlus_star = alphaPlus;
    
    %[alphaPlus_star conv]= sample_alphaPlus(alphaPlus_star,y,invT,MPlus_star,sigma2);
    conv = 1;
     % on �value la proba de jump
     choix = compute_proba_move_switch(MPlus_star,MPlus,alphaPlus_star,alphaPlus,R,Rmax,sigma2,y);

    if choix*conv == 1
        %disp('accepted update')
        indMPlus_out = indMPlus_star;
        alphaPlus_out = alphaPlus_star;
    else
        %disp('refused update')          
        alphaPlus_out = alphaPlus;
        indMPlus_out = indMPlus;
    end
    
else
    
    alphaPlus_out = alphaPlus;
    indMPlus_out = indMPlus;

end

    
