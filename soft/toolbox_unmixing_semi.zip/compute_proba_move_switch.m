function choix = compute_proba_move_switch(MPlus_star,MPlus,alphaPlus_star,alphaPlus,R,Rmax,sigma2,y)

% alpha_star = alphaPlus_star(1:R_star-1);
% alpha =  alphaPlus(1:R-1);

% calcul de la proba d'acceptation
% rapport des vraisemblances
A = -(norm(y-MPlus_star*alphaPlus_star)^2)/(2*sigma2) + (norm(y-MPlus*alphaPlus)^2)/(2*sigma2);

% rapport des proposal
A = A + 0;

rapport = exp(A);

% terme issus de la proposal : d�pend si R -> R +/- 1
% rapport_q_qstar = 1;

% proba finale
proba_accept_move =  min([1, rapport]);

% on tire suivant cette proba
choix = gen_discrete([1 0],[proba_accept_move 1-proba_accept_move],1,1);
