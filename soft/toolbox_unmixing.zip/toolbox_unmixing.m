clc
clear all
close all

% loading: endmembers;
[filename, pathname] = uigetfile('*.txt', 'Loading the endmembers (.txt format)');
fname_endm = [pathname filename];

[endm_data endm_name wavelength_end] = loading_txt(fname_endm);
Rmax = size(endm_data,2);

figure
plot(wavelength_end,endm_data)
h = legend(endm_name,'location','NorthWest');
xlabel('Wavelength (nm)')
title('Mixtures')
set(h,'Interpreter','none')

% loading: data;
[filename, pathname] = uigetfile('*.txt', 'Loading the data (.txt format)');
fname_data = [pathname filename];

[mix_data mix_name wavelength_mix] = loading_txt(fname_data);
[L Pmax] = size(mix_data);

figure(2)
plot(wavelength_mix,mix_data)
h = legend(mix_name,'location','NorthWest');
xlabel('Wavelength (nm)')
title('Mixtures')
set(h,'Interpreter','none')

% choosing the endmembers
flag = 0;
endm_ind = [];

while ~flag || length(endm_ind)<2
    [endm_ind,flag] = listdlg('Name', 'Endmember choice','PromptString','Select (at least 2) endmembers', 'SelectionMode','multiple','ListString',endm_name);
end
M = endm_data(:,endm_ind);
R = size(M,2);

clear flag

% choosing the mixtures
flag = 0;
while ~flag 
    [mix_ind,flag] = listdlg('Name', 'Mixture choice', 'PromptString','Select the mixtures', 'SelectionMode','multiple','ListString',mix_name);
end
Y = mix_data(:,mix_ind);
P = size(Y,2);

clear flag
           
% UNMIXING
Nmc = 200;
Nbi = 50;
Nr = Nmc-Nbi+1;
A = zeros(3*R+1,P);

tol = 5/100;
for i=1:P
    % estimation
    chain = unmixing(Y(:,i),M,Nmc);
    chain = chain(:,Nbi:end);
    Aest_current = mean(chain,2);
    A(1:R,i) = Aest_current;
    
    % estimation performance
    A((1:R)+1*R,i) = (mean(diff(chain')~=0))';
    
    % estimation confidence
    A((1:R)+2*R,i) = mean(abs(chain-Aest_current*ones(1,Nr))<tol,2); 
    
    % residual error (NRMSE)
    A(3*R+1,i) = sqrt(sum(abs(Y(:,i)-M*Aest_current).^2)/R)/sqrt(sum(abs(Y(:,i)).^2)/R);
    
    
    % plot
    endm_name_aff = endm_name;
    for r=1:R
        endm_name_aff{endm_ind(r)} = [endm_name{endm_ind(r)} ': ' num2str(100*Aest_current(endm_ind(r))) ' %'];
    end    
    figure
    plot(wavelength_end,Y(:,i),'k--')
    hold on
    plot(wavelength_end,endm_data(:,endm_ind))
    tmp = ['mixt. "' mix_name{i} '"'];
    h = legend({tmp endm_name_aff{endm_ind}},'location','NorthWest');
    set(h,'Interpreter','none')
    xlabel('Wavelength (nm)')
    h2 = title(['Endmembers detected in the mixture "' mix_name{mix_ind(i)} '"']);
    set(h2,'Interpreter','none')
    
end

endm_name(setdiff(1:Rmax,endm_ind)) = [];
mix_name(setdiff(1:Pmax,mix_ind)) = [];

row_title = cell(1,R*3+1);

for r=1:R
    row_title{R*0+r} = ['frac. ' endm_name{r} ' (%)'];
    row_title{R*1+r} = ['perf. ' endm_name{r} ' (%)'];
    row_title{R*2+r} = ['conf. ' endm_name{r} ' (%)'];
end
row_title{R*3+1} = ['Norm. RMSE (%)'];

col_title = mix_name;

[filename,pathname] = uiputfile('result.txt','Save file name');
fname_result = [pathname filename];

flag = saving_txt(fname_result,A,row_title,col_title);