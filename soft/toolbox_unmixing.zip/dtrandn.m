function X = dtrandn(x_old,mu,sigma,mum,mup)
sigma2 = sigma^2;

mup = (mup-mu)/sqrt(sigma2);
mum = (mum-mu)/sqrt(sigma2);
% mu
accept = 0;
compt = 0;
x = x_old;
N_loop = 200;

while accept==0  & compt<N_loop
    compt = compt + 1;
    z = rand(1)*(mup-mum) + mum;


    if 0<mum
        rho = exp((mum^2-z^2)/2);
    else
        if mup<0
            rho = exp((mup^2-z^2)/2);
        else
            rho = exp(-(z^2)/2);
        end
    end
    
    if rand<rho
        x = z;
        accept=1;
    else 
        accept = 0;        
    end;
end

X = (x*sqrt(sigma2) + mu)*(accept) + x_old*(1-accept);
    

