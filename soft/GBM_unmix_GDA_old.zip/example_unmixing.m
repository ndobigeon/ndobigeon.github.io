clc
clear all
close all

% loading: endmember matrix (R=3 components)
load endmembers.mat MPlus


alpha0=[0.3 0.6 0.1]'; % Actual abundance vector
gamma0=[0.5 0.1 0.3]'; % Actual gamma vector
sigma20= 3*10^-4; % Actual noise variance  

y=  MPlus*alpha0 + ...
    gamma0(1)*alpha0(1)*alpha0(2)*MPlus(:,1).*MPlus(:,2) + ...
    gamma0(2)*alpha0(1)*alpha0(3)*MPlus(:,1).*MPlus(:,3) + ...
    gamma0(3)*alpha0(2)*alpha0(3)*MPlus(:,2).*MPlus(:,3) + ...
    sqrt(sigma20)*randn(size(MPlus,1),1);

% Unmixing procedure
tic
[alpha gamma] = GBM_gradient(y,MPlus);
toc

[LAbund NLAbund] = exploitation(alpha,gamma,y,MPlus,alpha0,gamma0);
