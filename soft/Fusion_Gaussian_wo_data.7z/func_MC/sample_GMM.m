function [Mark_sample,miu_x_sample,s2_sample,Mark,miu_x,s2_inv]=sample_GMM(X,miu_x,s2_inv,Num_G,Phi,eta,Mark,beta)
[N_row N_col L]=size(X);
% X=reshape(X,[N_row*N_col L])*P_vec;
X=reshape(X,[N_row*N_col L]);
%Sample the hidden variable: Mark
Prob=zeros([N_row N_col Num_G]);s2_sample=zeros(L,L,Num_G);
if Num_G>1
    [Mark_nei]=neighbor(Mark);
    for j=1:Num_G
        temp=reshape(sum(Mark_nei==j,3),[N_row*N_col 1]); %count the number of neighbors who belong to ith class
        temp_PDF=mvnpdf(X,miu_x(j,:),inv(s2_inv(:,(j-1)*L+1:j*L))).*exp(beta*temp); %The beta affects the probability with the state of neighbors beta=0 means uniform prior
        Prob(:,:,j)=reshape(temp_PDF,[N_row N_col]);
    end
    Prob=Prob./repmat(sum(Prob,3),[1 1 Num_G]);
    test=rand([N_row N_col]);sum_PDF=zeros([N_row N_col Num_G]);sum_PDF(:,:,1)=Prob(:,:,1);Mark=zeros([N_row N_col]);
    Mark(test<=sum_PDF(:,:,1))=1;
    for j=2:Num_G
        sum_PDF(:,:,j) = sum_PDF(:,:,j-1)+Prob(:,:,j);
        Mark(test>=sum_PDF(:,:,j-1) & test<sum_PDF(:,:,j))=j;
    end
else
    Mark=ones([N_row N_col]);
    Mark=ones([1 1]);
end
    

%This is the Chormatic Gibbs sampler using checkersquence method
% for m=1:2
%   for n=1:2
%     [Mark_nei]=neighbor(Mark);
%     for j=1:Num_G
%         temp=reshape(sum(Mark_nei==j,3),[N_row*N_col 1]); %count the number of neighbors who belong to ith class
%         temp_PDF=mvnpdf(X,miu_x(j,:),inv(s2_inv(:,(j-1)*L+1:j*L))).*exp(beta*temp); %The beta affects the probability with the state of neighbors beta=0 means uniform prior
%         Prob(:,:,j)=reshape(temp_PDF,[N_row N_col]);
%     end
%     Prob=Prob./repmat(sum(Prob,3),[1 1 Num_G]);
%     test=rand([N_row N_col]);sum_PDF=zeros([N_row N_col Num_G]);sum_PDF(:,:,1)=Prob(:,:,1);Mark_t=zeros([N_row N_col]);
%     Mark_t(test<sum_PDF(:,:,1))=1;
%     for j=2:Num_G
%         sum_PDF(:,:,j) = sum_PDF(:,:,j-1)+Prob(:,:,j);
%         Mark_t(test>=sum_PDF(:,:,j-1) & test<sum_PDF(:,:,j))=j;
%     end
%     Mark(m:2:end,n:2:end)=Mark_t(m:2:end,n:2:end);
%   end
% end

Mark_sample=Mark;
% figure(5);imshow(Mark,[]);
%Sample the mean and variance matrix for every Gaussian component
for j=1:Num_G
    % The following three lines extract the jth-class Gaussian pixels
    temp_X=X;
    temp_X(Mark~=j,:)=[]; % This is equal to I=find(Mark~=j);temp(I,:)=[];
    
    %%Method 1: Sample the covariance matrix in the Gibbs scheme
    if size(miu_x,1)>1
        temp_mu=miu_x-temp_X;
    else
        temp_mu=repmat(miu_x(j,:),size(temp_X,1),1)-temp_X;
    end
    s2_inv(:,(j-1)*L+1:j*L) = wishrnd(inv(Phi+temp_mu'*temp_mu),size(temp_X,1)+eta); 
    
    %%Method 2:  The covariance matrix is assigned the empirical covariance matrix
%     s2_inv(:,(j-1)*L+1:j*L) = s2inv_0*(eta-size(temp_X,2)-1); 
%     s2_inv(:,(j-1)*L+1:j*L)=0.001*eye(L);
    s2_sample(:,1:L,j)=s2_inv(:,(j-1)*L+1:j*L);
%     %% Sampling the mean
%     if size(miu_x,1)==1
%         cov_cache=size(temp_X,1)*s2_inv(:,(j-1)*L+1:j*L); mean_cache=mean(temp_X,1)';
%         temp_Cov=inv(eye(L)+cov_cache); temp_miu = (eye(L)+cov_cache)\(miu_x0+cov_cache*mean_cache);
%         miu_x(j,:) = mvnrnd(temp_miu,temp_Cov);
%     end
%     miu_x(j,:)=0;
end
if size(miu_x,1)==1 % Because miu_x has been shaped as a 2D matrix
    miu_x_sample = miu_x';
else
    miu_x_sample=ones(L,1);
end