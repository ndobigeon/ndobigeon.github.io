function [X,rho,zeta,accept_r,Window] = sample_X_hamiltonian(X,Y_dec,Z,psfY,psfZ,sigma2y,sigma2z,nbleapfrog,zeta,Window,s2_inv,miu_x,Mark,prior,Num_G,P_dec,Nbi,i)
% function [X,rho,zeta,accept_r,Window] = sample_X_hamiltonian(X,Y,Z,psfY,psfZ,sigma2y,sigma2z,nbleapfrog,zeta,Window,s2_inv,miu_x,Mark,prior,Num_G,P_vec,Nbi,i)
%% Obtain the corresponding observation in subspace
sigma2y_dec=P_dec*diag(sigma2y)*P_dec';
inv_sigma2y_dec=inv(sigma2y_dec);
p_cov=1; p = sqrt(p_cov)*randn(size(X)); % If p=0, the HMC degrades to be MAP estimation % p_cov=(1/sigma2y+1/sigma2z+1/s2);
% 1/sigma2y+1/sigma2z+min(diag(s2_inv))
X_cand = X;p_cand=p;
gradU = func_grad(X_cand,Y_dec,Z,psfY,psfZ,sigma2y_dec,sigma2z,s2_inv,miu_x,prior,Mark,Num_G);
p_cand = p_cand - 1/2*zeta*gradU;
for leapfrog = 1:nbleapfrog 
    X_cand = X_cand + zeta*p_cand/p_cov;
    if strcmp(prior,'Uniform')
        p_cand(X_cand<0 | X_cand>1)=(-1)*p_cand(X_cand<0|X_cand>1);
        X_cand(X_cand<0)=(-1)*X_cand(X_cand<0);
        X_cand(X_cand>1)=2-X_cand(X_cand>1);
    end    
%     gradU = func_grad(X_cand,Y,Z,psfY,psfZ,sigma2y,sigma2z,s2_inv,miu_x,prior,Mark,Num_G,P_vec);
    gradU = func_grad(X_cand,Y_dec,Z,psfY,psfZ,sigma2y_dec,sigma2z,s2_inv,miu_x,prior,Mark,Num_G);
    if leapfrog<nbleapfrog
        p_cand = p_cand - zeta*gradU;       
    end
end
p_cand = p_cand - zeta/2*gradU; 
% X_cand = X_cand + zeta*p_cand/p_cov;
% if strcmp(prior,'Uniform')
%     p_cand(X_cand<0 | X_cand>1)=(-1)*p_cand(X_cand<0|X_cand>1);
%     X_cand(X_cand<0)=(-1)*X_cand(X_cand<0);
%     X_cand(X_cand>1)=2-X_cand(X_cand>1);
% end    
% gradU = func_grad(X_cand,Y,Z,psfY,psfZ,sigma2y,sigma2z,s2_inv,miu_x,prior,Mark);
% p_cand = p_cand - 1/2*zeta*gradU;

% err_courY = Y-func_blurringY(var_dim(X,P_vec,'inc'),psfY);      
err_courY = Y_dec-func_blurringY(X,psfY);      
err_courY = err_courY(1:psfY.ds_r:end,1:psfY.ds_r:end,:);
err_courY = reshape(err_courY,size(err_courY,1)*size(err_courY,2),size(err_courY,3));
obj_courY = trace(err_courY*inv_sigma2y_dec*err_courY');

err_courZ = Z-func_blurringZ(X,psfZ);
err_courZ = reshape(err_courZ,size(Z,1)*size(Z,2),size(Z,3))/diag(sqrt(sigma2z));

% err_candY = Y-func_blurringY(var_dim(X_cand,P_vec,'inc'),psfY);
err_candY = Y_dec-func_blurringY(X_cand,psfY);
err_candY = err_candY(1:psfY.ds_r:end,1:psfY.ds_r:end,:);
err_candY = reshape(err_candY,size(err_candY,1)*size(err_candY,2),size(err_candY,3));
obj_candY = trace(err_candY*inv_sigma2y_dec*err_candY');

err_candZ = Z-func_blurringZ(X_cand,psfZ);
err_candZ = reshape(err_candZ,size(Z,1)*size(Z,2),size(Z,3))/diag(sqrt(sigma2z));

if strcmp(prior,'Gaussian')
%     if block_diag==0
%         obj_cour = s2_inv/2*norm(X(:)-miu_x)^2;
%         obj_cand = s2_inv/2*norm(X_cand(:)-miu_x)^2; 
%     elseif block_diag==1
%         deltaX=zeros(size(X));deltaX_cand=zeros(size(X));
%         for i=1:size(X,3)
%             deltaX(:,:,i)=X(:,:,i)-miu_x(i);
%             deltaX_cand(:,:,i)=X_cand(:,:,i)-miu_x(i);  
%         end
%         temp_cour=reshape(deltaX,[N_row*N_col L])*s2_inv.*reshape(deltaX,[N_row*N_col L]);               obj_cour=1/2*sum(temp_cour(:));
%         temp_cand=reshape(deltaX_cand,[N_row*N_col L])*s2_inv.*reshape(deltaX_cand,[N_row*N_col L]);     obj_cand=1/2*sum(temp_cand(:));
%     end
elseif strcmp(prior,'MRF') || strcmp(prior,'GMM') || strcmp(prior,'Dic') || strcmp(prior,'Laplacian')
    [~,obj_cour]= func_grad(X,Y_dec,Z,psfY,psfZ,sigma2y_dec,sigma2z,s2_inv,miu_x,prior,Mark,Num_G);
    [~,obj_cand]= func_grad(X_cand,Y_dec,Z,psfY,psfZ,sigma2y_dec,sigma2z,s2_inv,miu_x,prior,Mark,Num_G);
%     [~,obj_cour]= func_grad(X,Y,Z,psfY,psfZ,sigma2y,sigma2z,s2_inv,miu_x,prior,Mark,Num_G,P_vec);
%     [~,obj_cand]= func_grad(X_cand,Y,Z,psfY,psfZ,sigma2y,sigma2z,s2_inv,miu_x,prior,Mark,Num_G,P_vec);
elseif strcmp(prior,'Uniform')
    obj_cour = 0;    obj_cand = 0; 
end
% obj_cour = obj_cour + 1/2 * norm(err_courY(:))^2 + 1/2 * norm(err_courZ(:))^2 + 1/(2*p_cov)*norm(p(:))^2;
% obj_cand = obj_cand + 1/2 * norm(err_candY(:))^2 + 1/2 * norm(err_candZ(:))^2 + 1/(2*p_cov)*norm(p_cand(:))^2; 

obj_cour = obj_cour + 1/2 * obj_courY + 1/2 * norm(err_courZ(:))^2 + 1/(2*p_cov)*norm(p(:))^2;
obj_cand = obj_cand + 1/2 * obj_candY + 1/2 * norm(err_candZ(:))^2 + 1/(2*p_cov)*norm(p_cand(:))^2; 

rho = min([1 exp(obj_cour-obj_cand)]);
if rand<rho
    X = X_cand;  ac_Mark=1;
else
    ac_Mark=0;
end
[~,Col]=size(Window);Window=[Window(:,2:Col) ac_Mark];accept_r=sum(Window,2)/Col;
%Adjust the stepsize adaptively with the acceptance ratio
epsilon_u=0.25;epsilon_d=0.35;
if i<=Nbi
    if  accept_r<0.65-epsilon_d
        zeta=zeta*(1-0.1);
    elseif accept_r>0.65+epsilon_u
        zeta= zeta*(1+0.1);
    end
elseif i>Nbi
    if  accept_r<0.65-epsilon_d
        zeta=zeta*(1-0.1*exp(-0.01*(i-Nbi)));
    elseif accept_r>0.65+epsilon_u
        zeta= zeta*(1+0.1*exp(-0.01*(i-Nbi)));
    end    
end