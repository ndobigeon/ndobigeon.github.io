%% Gibbs sampler consists of Prior_Ini,MMSE_Sam,sample_x_hamiltonian
function [miu_x_sample,s2_sample,sigma2y_sample,sigma2z_sample,Mark_sample,psfZ_sample,X_MMSE,MAP_est,X_Var,RMSE_HMC,zeta,X_test,track_change,rho,accept_r]...
        =Gibbs_sampler(X,Y,Z,psfY,psfZ_true,Nbi,Nmc,length_max,prior,P_inc,P_dec,para,band_set,Para_Prior,sample_kernel,X_real,Verbose)
% X_sample=zeros([size(X) Nmc]);
%% Prior Information  
[N_row N_col L]=size(X);
Prior_Ini;% Initialization
%% MCMC Initial parameter
zeta= 1e-3*ones(1,Nmc);    Window=(-1)*floor(rand(1,30)-0.6); accept_r=zeros(1,Nmc); rho=zeros(1,Nmc);
%% Some displays 
if strcmp(prior,'GMM') || strcmp(prior,'Laplacian')
    miu_x_sample=zeros(L,Nmc,para.Num_G);
    s2_sample=zeros(L,Nmc*L,para.Num_G);
%     Mark_sample=zeros([N_row N_col Nmc]);Mark=ones(N_row,N_col);
    Mark_sample=zeros([1 1 Nmc]);Mark=ones(1,1);
elseif strcmp(prior,'Dic')
    s2_sample=zeros(1,Nmc);miu_x_sample=zeros(1,Nmc);   
    Mark_sample=zeros([N_row N_col Nmc]);Mark=ones(N_row,N_col);
end
X_test=zeros(1,Nmc);SNR_HMC=zeros(1,Nmc); RMSE_HMC=zeros(2,Nmc);% The evaluation criterion
sigma2y_sample=zeros(size(Y,3),Nmc);sigma2y = zeros(size(Y,3),1);
sigma2z_sample=zeros(size(Z,3),Nmc);sigma2z = zeros(size(Z,3),1);
track_change=zeros(1,Nmc-1);X_MMSE=0;X_Var=0;
%% Prior for sampling the spectral response 
psfZ_ref=psfZ_true*P_inc;
% psfZ_ref=psfZ_true;
psfZ_0=zeros(size(psfZ_ref));
% psfZ=psfZ_0;
% psfZ_0=psfZ_ref; 
s2psf_0=1e3; 
psfZ_sample=zeros(size(psfZ_0,1),size(psfZ_0,2),Nmc);
%% Begin the cycle
if strcmp(Verbose,'on')
%     figure(0122);plot((psfZ_ref*P_vec')');title('Spectral response in subspace')
    figure(0122);plot(psfZ_ref');title('Spectral response in subspace')
    hwait1=waitbar(1,'Please wait>>>>>>>> The Cycle');
end
rng(1,'v5normal'); 
% seed=clock;
X_real_sub=var_dim(X_real,P_dec);
Y_dec=var_dim(Y,P_dec);
for i=1:Nmc        
    %% Verbose the sampling and sequential MMSE estimates
%     [X_MMSE,X_MMSE_inc,X_Var]=MMSE_Sam(i,Nbi,X,X_MMSE,X_Var,P_vec);
    [X_MMSE,X_Var]=MMSE_Sam(i,Nbi,X,X_MMSE,X_Var);X_MMSE_inc=var_dim(X_MMSE,P_inc);
%     SNR_HMC(:,i)  = 20*log10(norm(X_real(:))/norm(X_real(:) - X_MMSE_inc(:)));
%     RMSE_HMC(2,i)=sqrt(mean((X_MMSE_inc(:)-X_real(:)).^2));
    RMSE_HMC(1,i)=sqrt(mean((X_MMSE(:)-X_real_sub(:)).^2));
    %% Sec 4: Sample the variance of noise, denoted sigma2y,sigma2z
    temp_X=var_dim(X,P_inc);
    tempY=Y-func_blurringY(temp_X,psfY);  tempY=tempY(1:psfY.ds_r:end,1:psfY.ds_r:end,:);
    for j=1:size(Y,3)
        tempY_b=tempY(:,:,j);
        sigma2y(j,1)=1/gamrnd((numel(tempY_b)+nuH)/2,2/(norm(tempY_b,'fro')^2+gammaH(j)));    
    end
    tempZ=Z-func_blurringZ(X,psfZ_ref);      %tempZ=tempZ(1:psfY.ds_r:end,1:psfY.ds_r:end,:);
    for j=1:size(Z,3)
        tempZ_b=tempZ(:,:,j);
        sigma2z(j,1)=1/gamrnd((numel(tempZ_b)+nuM)/2,2/(norm(tempZ_b,'fro')^2+gammaM(j)));
    end
%     sigma2z=sigma2z_real;
%     sigma2y=sigma2y_real;                 
    sigma2y_sample(:,i)=sigma2y;           sigma2z_sample(:,i)=sigma2z;
    %% Sec 1:Sample the variance of X, denoted as s2; Sample the mean of X, denoted as miu_x;
    if strcmp(prior,'MRF')
        miu_x=[]; s2_inv=[];
    elseif strcmp(prior,'GMM') || strcmp(prior,'Laplacian')
        [Mark_sample(:,:,i),miu_x_sample(:,i,:),s2_sample(:,(i-1)*L+1:i*L,:),Mark,miu_x,s2_inv]=sample_GMM(X,miu_x,s2_inv,para.Num_G,Phi,eta,Mark,para.beta_v); 
%         Mark=ones([N_row N_col]);miu_x=(P_dec*miu_x_real)';s2_inv=P_dec*s2_real*P_inc;s2_inv=inv((s2_inv+s2_inv')/2);
%          Y_tem=Y(1:psfY.ds_r:end,1:psfY.ds_r:end,:);
%          miu_x=(P_vec'*squeeze(mean(mean(Y_tem,1),2)))';
%          s2_inv=P_vec'*cov(reshape(Y_tem,[size(Y_tem,1)*size(Y_tem,2) size(Y_tem,3)]))*P_vec;s2_inv=inv((s2_inv+s2_inv')/2);
    elseif strcmp(prior,'Dic')
        [s2_inv,s2_sample(:,i),miu_x]=sample_Dic(X,miu_x,para.D,para.supp);
        temp_X=var_dim(miu_x,P_inc);
        figure(113);imshow(temp_X(:,:,band_set),[]);
%         s2_inv=0.01;
%         miu_x=X_real;
    end
    %% Sec 2: Sample the spectral response of MS data
%    psfZ=sample_psfZ(Z,var_dim(X_real,P_dec),diag(sigma2z_real),psfZ_0,s2psf_0);
%     psfZ=sample_psfZ(Z,X,diag(sigma2z),psfZ_0,s2psf_0);
%     psfZ_sample(:,:,i)=psfZ;
    psfZ=psfZ_ref;
%     figure(0123);
%     subplot(2,1,1);plot(psfZ_ref');
%     subplot(2,1,2);plot(psfZ');
%     psfZ_show=psfZ*P_vec'*inv(P_vec*P_vec'+eye(size(P_vec,1))*1e-4);
    %% Sec 3: Sample X
    if strcmp(sample_kernel,'HMC')      %Method 1: Hybrid Monte Carlo
%         nbleapfrog=floor(rand*length_max+1)/10+45;       
       nbleapfrog=floor(rand*5+length_max);  
%          nbleapfrog=floor(rand*length_max+1);

        [X,rho(:,i),zeta(:,i+1),accept_r(:,i),Window] = ...
        sample_X_hamiltonian(X,Y_dec,Z,psfY,psfZ,sigma2y,sigma2z,nbleapfrog,zeta(:,i),Window,s2_inv,miu_x,Mark,prior,para.Num_G,P_dec,Nbi,i); 
%         X=var_dim(X_real,P_dec);%+0.0*randn(N_row,N_col,size(P_vec,2));
%         if strcmp(Verbose,'on');
%             temp_X=var_dim(X,P_inc);
%             temp_show=temp_X(:,:,band_set);temp_show=(temp_show-min(temp_show(:)))/(max(temp_show(:))-min(temp_show(:)));
%             figure(1018);imagesc(temp_show); axis image;
%         end
    elseif strcmp(sample_kernel,'PO')   %Method 2: PO
        [X,Symbol,step_PO] = sample_X_po(X,Y,Z,psfY,psfZ,sigma2y,sigma2z,s2_inv,miu_x,epsilon,Mark,para.Num_G,P_vec);
%         if strcmp(Verbose,'on');
% %             temp_X=var_dim(X,P_vec,'inc');
% %             temp_show=temp_X(:,:,1:3);temp_show=(temp_show-min(temp_show(:)))/(max(temp_show(:))-min(temp_show(:)));
% %             figure(1018);imshow(X(:,:,1:3)); 
%         end
    end
    if strcmp(Verbose,'on')
        figure(0325);plot(RMSE_HMC');
        %title('SNR'); xlabel('N_{MC}');ylabel('dB'); 
    end
%     X_sample(:,:,:,i)=X;
    X_test(1,i) = X(5,5,1);
    if i>=2; 
        track_change(1,i-1)=norm(X(:)-X_form(:));
    end; 
    X_form=X; %Track Change
    %% One loop finish
    if strcmp(Verbose,'on')
        str1=['Processing...',num2str(i*100/Nmc),'%']; 
        waitbar(i/Nmc,hwait1,str1); 
    end
    if strcmp(prior,'GMM')
%         Post_prior=sum(log10(mvnpdf(reshape(X,[N_row*N_col L]),miu_x,inv(s2_inv))+1e-300));
%         Post_llh=sum(log10(mvnpdf(tempY(:),0,sigma2y)))+sum(log10(mvnpdf(tempZ(:),0,sigma2z)));
%         Post_hypprior=-log10(sigma2y)-log10(sigma2z)+log10(mvnpdf(miu_x,miu_x0,eye(L)))+log10(invwishpdf(inv(s2_inv),eye(L),2*L+4));%nv=L+3 here the second parameter is L+3+L+1
%         Post=Post_prior+Post_llh+Post_hypprior;
%         if Post>MaxPost
%             MAP_est.X=X;
%             MAP_est.miu_x=miu_x;
%             MAP_est.s2_inv=s2_inv;
%             MAP_est.sigma2y=sigma2y;
%             MAP_est.sigma2z=sigma2z;
%             MaxPost=Post;
%         end
        MAP_est.X=X;
        MAP_est.miu_x=miu_x;
        MAP_est.s2_inv=s2_inv;
        MAP_est.sigma2y=sigma2y;
        MAP_est.sigma2z=sigma2z;
%         mvnpdf(reshape(X,[1 N_row*N_col*L]),repmat(miu_x,1,N_row*N_col),blkdiag(speye(0),temp{:}));
    else %strcmp(prior,'Dic')
        MAP_est.X=X;
        MAP_est.miu_x=miu_x;
        MAP_est.s2_inv=s2_inv;
        MAP_est.sigma2y=sigma2y;
        MAP_est.sigma2z=sigma2z;
%         MaxPost=Post;
    end

end
% psfZ_sample=repmat(psfZ_ref,[1 1 Nmc]);
zeta=zeta(:,1:Nmc);
if strcmp(Verbose,'on'); close(hwait1); end