function x_out = udconv(x_in,h)

lx = length(x_in);
lh = length(h);
cur_data = zeros(lx+lh,1);
% x_out = zeros(lx,1);

cur_data(1:lx) = x_in;
cur_data(lx+1:lx+lh) = x_in(1:lh);

% for j = 1:lx
%   for i = 1:lh 
%       x_out(j) = x_out(j) + cur_data(j+i-1)*h(lh-i+1);
%   end
% end

x_out = conv(cur_data,h,'valid');
x_out = x_out(1:lx);

