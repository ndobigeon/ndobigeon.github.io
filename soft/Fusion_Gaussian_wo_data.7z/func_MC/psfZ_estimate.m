function [psfZ_est] = psfZ_estimate(Xmld,Xp,psfY)
Ymld = reshape(Xmld,size(Xmld,1)*size(Xmld,2),size(Xmld,3))';

%Degrade the Xp image
Xp_deg = func_blurringY(Xp,psfY);
Xp_deg = Xp_deg(1:psfY.ds_r:end,1:psfY.ds_r:end,:);
Yp_deg = reshape(Xp_deg,size(Xp_deg,1)*size(Xp_deg,2),size(Xp_deg,3))';

%Estimate the spectral response
psfZ_est=Yp_deg*Ymld'/(Ymld*Ymld');