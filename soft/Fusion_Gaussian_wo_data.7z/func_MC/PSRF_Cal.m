function PSRF = PSRF_Cal(N_Chain,Mean_cache,Var_cache,Nmc,Nbi)
if N_Chain==1
    PSRF=0;
    return;
else
    temp=mean(Mean_cache,4);
    for i=1:N_Chain
        Mean_cache(:,:,:,i)=Mean_cache(:,:,:,i)-temp;
    end
    W_PSFR=mean(Var_cache,4); B_PSFR=1/(N_Chain-1)*sum(Mean_cache.^2,4);
    PSRF=(Nmc-Nbi-1)/(Nmc-Nbi)+(N_Chain+1)/N_Chain*squeeze(B_PSFR./W_PSFR);
    PSRF=mean2(PSRF);
end