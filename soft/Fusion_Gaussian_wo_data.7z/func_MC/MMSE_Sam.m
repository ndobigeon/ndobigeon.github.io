%% MMSE
function [X_MMSE,X_Var]=MMSE_Sam(i,Nbi,X,X_MMSE,X_Var)
% Xaff = abs(X/max(abs(X(:))));
if i<=Nbi
    X_MMSE = X;
    X_Var = 0;
%     figure(11);subplot(1,2,1);imshow(Xaff)    
elseif i>Nbi
    X_MMSE = X_MMSE+1/(i+1-Nbi)*(X-X_MMSE);
    X_Var=(i-Nbi-1)/(i-Nbi)*X_Var+(i-Nbi+1)/(i-Nbi)^2*(X-X_MMSE).^2;   
%     X_Var_show=mean2(X_Var);
%     figure(11);
%     subplot(1,2,1);imshow(Xaff)  
%     subplot(1,2,2);imshow(X_MMSEaff)
    %% Test2: N_r
%     test_MSE_Nr(i-Nbi)=norm(X_MMSE(:)-X_real(:))^2;
end
% X_MMSE_inc=var_dim(X_MMSE,P_vec,'inc');
% SNR_HMC = 20*log10(norm(X_real(:))/norm(X_real(:)-X_MMSE_inc(:)));