%I: Prior of X: Gaussian Distribution
% epsilon0=4+1e-3;  epsilon1=2;
% epsilon=1e-0; %Parameters for F'Orieux's method
% Prior of s2
% II: Prior of X: IGMRF
% if strcmp(prior,'MRF')
%     %% The prior of X
%     Z_r=squeeze(mean(X_real,3));
%     % Estimate the IGMRF parameters from the high spatial resoltution panchormatic image
%     [bx1,by1,bu1,bv1,bx2,by2,bu2,bv2] = func_IGMRF(X_real);
% %     figure(123)
% %     title('IGMRF Parameters')
% %     subplot(2,2,1);imshow(bx1,[]);    subplot(2,2,2);imshow(by1,[]);
% %     subplot(2,2,3);imshow(bu1,[]);    subplot(2,2,4);imshow(bv1,[]);
% end

%% Prior Parameters Selection
nuH=Para_Prior.nuH;
gammaH=Para_Prior.gammaH;
nuM=Para_Prior.nuM;
gammaM=Para_Prior.gammaM;

miu_x=Para_Prior.miu_x;

Phi=Para_Prior.Phi;
eta=Para_Prior.eta;
%% Initialization
s2_inv=Para_Prior.invCov_U0; %

