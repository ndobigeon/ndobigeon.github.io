%% Gradient fuction
% function [Grad_U_mod,U] = func_grad(X,Y,Z,psfY,psfZ,sigma2y,sigma2z,s2_inv,miu_x,prior,Mark,Num_G,P_vec)
function [Grad_U_mod,U] = func_grad(X,Y,Z,psfY,psfZ,sigma2y,sigma2z,s2_inv,miu_x,prior,Mark,Num_G)
global block_diag;
[N_row N_col L]=size(X);
if strcmp(prior,'Gaussian')
%     %Method 1:
%     for i=1:N_row
%         for j=1:N_col
%             temp(i,j,:) = s2\squeeze((X(i,j,:)-miu_x(i,j,:)));
%         end
%     end
%     %Method 2:
%     x1=X(:,:,1)-miu_x(:,:,1);new(1,:)=x1(:)';
%     x2=X(:,:,2)-miu_x(:,:,2);new(2,:)=x2(:)';
%     x3=X(:,:,3)-miu_x(:,:,3);new(3,:)=x3(:)';
%     temp=reshape((s2\new)',size(X));
    %Method 3:
    if block_diag==0
        Grad_U_mod = s2_inv*(X-miu_x);
    elseif block_diag==1
%         temp=reshape(shiftdim(X-miu_x,L-1),[L N_row*N_col]);
%         temp=reshape((s2\temp)',size(X));
        X_temp=zeros(size(X));
        for i=1:L; X_temp(:,:,i)=X(:,:,i)-miu_x(:,i); end
        X_temp=reshape(X_temp,[N_row*N_col L]);% The implementation of block matrix multiplication
        Grad_U_mod=reshape((s2_inv*X_temp')',size(X));
    end
elseif strcmp(prior,'MRF')  
    num=L;
%     num=1;
    bx_1=repmat(bx1,[1 1 num]);       bx_2=repmat(bx2,[1 1 num]);
    by_1=repmat(by1,[1 1 num]);       by_2=repmat(by2,[1 1 num]);
    bu_1=repmat(bu1,[1 1 num]);       bu_2=repmat(bu2,[1 1 num]);
    bv_1=repmat(bv1,[1 1 num]);       bv_2=repmat(bv2,[1 1 num]);
    
%     Xc=zeros(N_row+2,N_col+2,L);
%     for i=1:L
%         Xc_u= 2*X(1,:,i)-X(2,:,i);
%         Xc_d= 2*X(end,:,i)-X(end-1,:,i);
%         Xc_l= 2*X(:,1,i)-X(:,2,i);
%         Xc_r= 2*X(:,end,i)-X(:,end-1,i);  
%         Xc(:,:,i)=[(Xc_u(1)+Xc_l(1))/2,Xc_u,(Xc_u(1)+Xc_r(1))/2;
%             Xc_l,X(:,:,i),Xc_r;
%             (Xc_d(1)+Xc_l(1))/2,Xc_d,(Xc_d(1)+Xc_r(1))/2;];
%     end

%     Xx_1=X-Xc(1:end-2,2:end-1,:);
%     Xx_2=X-Xc(3:end,2:end-1,:);
%     Xy_1=X-Xc(2:end-1,1:end-2,:);
%     Xy_2=X-Xc(2:end-1,3:end,:);
%     Xu_1=X-Xc(1:end-2,1:end-2,:);
%     Xu_2=X-Xc(3:end,3:end,:);
%     Xv_1=X-Xc(1:end-2,3:end,:);
%     Xv_2=X-Xc(3:end,1:end-2,:);
%     Grad_U = bx_1.*Xx_1+bx_2.*Xx_2+by_1.*Xy_1+by_2.*Xy_2+...
%         bu_1.*Xu_1+bu_2.*Xu_2+bv_1.*Xv_1+bv_2.*Xv_2;

%% In this case, the MRF prior will degrade to Gaussian prior
Xx_1=X-miu_x;Xy_1=X-miu_x;
Xu_1=X-miu_x;Xv_1=X-miu_x;
Grad_U = bx_1.*Xx_1+ bu_1.*Xu_1 +by_1.*Xy_1+bv_1.*Xv_1;
    %%
    Grad_U_mod = 2*Grad_U;       
    if nargout>1
        U_temp = bx_1.*(Xx_1.^2)+by_1.*(Xy_1.^2)+bu_1.*(Xu_1.^2)+bv_1.*(Xv_1.^2);
        U = sum(U_temp(:));
    end
elseif strcmp(prior,'Uniform')
    Grad_U_mod = 0;
elseif strcmp(prior,'GMM')
    U=0;Grad_U_vec=zeros(N_row*N_col,L);
    for j=1:Num_G
        X_temp=reshape(X,[N_row*N_col L]);
        X_temp(Mark~=j,:)=[]; % This is equal to I=find(Mark~=j);temp(I,:)=[];
        if size(miu_x,1)>1
            X_temp = X_temp-miu_x;
        else
            X_temp = X_temp-repmat(miu_x(j,:),[size(X_temp,1) 1]);
        end
%         Grad_U_vec(Mark==j,:)= (s2_inv(:,(j-1)*L+1:j*L)*X_temp')';
        Grad_U_vec= (s2_inv(:,(j-1)*L+1:j*L)*X_temp')'; %% Is true when Num_G=1
        if nargout>1
            U_temp=X_temp *s2_inv(:,(j-1)*L+1:j*L).*X_temp;
            U= U + 1/2*sum(U_temp(:));
        end
    end
    Grad_U_mod =reshape(Grad_U_vec,size(X));
elseif strcmp(prior,'Dic')
   X_temp=X-miu_x;Grad_U_mod=s2_inv*X_temp; 
   if nargout>1
       U= s2_inv/2*norm(X_temp(:))^2;
   end
elseif strcmp(prior,'PO')
    Grad_U_mod=0;
elseif strcmp(prior,'Laplacian')
    H_kernel=fspecial('laplacian');
    temp=imfilter(X,H_kernel,'circular');
    Grad_U_mod= 5*imfilter(temp,H_kernel','circular');
    if nargout>1
       U= 5/2*norm(temp(:))^2;
   end
end
% Grad_U_mod = Grad_U_mod-...
% 1/sigma2y*var_dim(func_blurringY(Y-func_blurringY(var_dim(X,P_vec,'inc'),psfY),psfY,1),P_vec,'dec')-...
% 1/sigma2z*var_dim(func_blurringZ(Z-func_blurringZ(var_dim(X,P_vec,'inc'),psfZ),psfZ'),P_vec,'dec');

% tempY=Y-func_blurringY(var_dim(X,P_vec,'inc'),psfY);
% tempY=reshape(reshape(tempY,[size(Y,1)*size(Y,2) size(Y,3)])/diag(sigma2y),[size(Y,1) size(Y,2) size(Y,3)]);
% Grad_U_y=var_dim(func_blurringY(tempY,psfY,1),P_vec,'dec');

tempY=Y-func_blurringY(X,psfY);
tempY=reshape(reshape(tempY,[size(Y,1)*size(Y,2) size(Y,3)])/(sigma2y),[size(Y,1) size(Y,2) size(Y,3)]);
Grad_U_y=func_blurringY(tempY,psfY,1);

% tempZ=Z-func_blurringZ(var_dim(X,P_vec,'inc'),psfZ);
tempZ=Z-func_blurringZ(X,psfZ);
tempZ=reshape(reshape(tempZ,[size(Z,1)*size(Z,2) size(Z,3)])/diag(sigma2z),[size(Z,1) size(Z,2) size(Z,3)]);
Grad_U_z=func_blurringZ(tempZ,psfZ');

Grad_U_mod = Grad_U_mod-Grad_U_y-Grad_U_z;