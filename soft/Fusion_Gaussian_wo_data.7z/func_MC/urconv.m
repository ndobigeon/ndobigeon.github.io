function x_out2 = urconv(x_inl,x_inh,lo_r,hi_r)
%URCONV, X_INL, X_INH, LO_R, HI_R

lx = length(x_inl);%(size(x_inl))[1]
lh = length(lo_r);%(size(Lo_R))[1]
% x_out = zeros(lx,1);

l_data = zeros(lx+lh,1);
h_data = zeros(lx+lh,1);

% Following two loops indices needs to be checked
l_data(lh+1:lx+lh)=x_inl(1:lx);
h_data(lh+1:lx+lh)=x_inh(1:lx);

j = lh:-1:1;
l_data(j) = l_data(j+lx);
h_data(j) = h_data(j+lx);
% 

% for j = 1:lx 
%   for i = 1:lh  
%       x_out(j) = x_out(j) + (l_data(j+i-1)*lo_r(lh-1+i) + h_data(j+i-1)*hi_r(lh+1-i))/2;
%   end
% end

ld_lr = conv(l_data,lo_r,'valid');
hd_hr = conv(h_data,hi_r,'valid');
x_out2 = (ld_lr(1:lx)+hd_hr(1:lx))/2;

% for j = lh+1:lx+lh
%     l_data(j) = x_inl(j-lh);
%   h_data(j) = x_inh(j-lh);
% end
% for j = 1:lh
%   l_data(j) = l_data(j+lx);
%   h_data(j) = h_data(j+lx);
% end
% for j = 1:lx
%   l_data(j) = x_inl(j);
%   h_data(j) = x_inh(j);
% end
% for j = lx+1:lx+lh
%   l_data(j) = l_data(j-lx);
%   h_data(j) = h_data(j-lx);
% end
