function [X,rho,zeta,accept_r,Window]=sample_hmc_IGMRF(Y,X,psfY,sigma2y,Window,zeta,nbleapfrog,bx1,by1,bu1,bv1,bx2,by2,bu2,bv2)
[~,Col]=size(Window);
p_cov=10;
p = sqrt(p_cov)*randn(size(X));
p_cand=p;
X_cand = X;
[~,U_cour] = func_grad(X_cand,bx1,by1,bu1,bv1,bx2,by2,bu2,bv2);

for leapfrog = 1:nbleapfrog
    % Caculate the gradient of cost function
    [Grad_U,~] = func_grad(X_cand,bx1,by1,bu1,bv1,bx2,by2,bu2,bv2); 
    Grad_U = Grad_U-1/sigma2y*func_blurringY(Y -func_blurringY(X_cand,psfY),psfY);
    p_prime = p_cand - 1/2*zeta.*Grad_U;
    X_cand = X_cand + zeta.*p_prime/p_cov;
    [Grad_U,~] = func_grad(X_cand,bx1,by1,bu1,bv1,bx2,by2,bu2,bv2); 
    Grad_U = Grad_U-1/sigma2y*func_blurringY(Y -func_blurringY(X_cand,psfY),psfY);
    p_cand = p_prime - 1/2*zeta.*Grad_U;
end
[~,U_cand] = func_grad(X_cand,bx1,by1,bu1,bv1,bx2,by2,bu2,bv2); 

% Caculate the accept ratio
err_courY = Y-func_blurringY(X,psfY);
err_candY = Y-func_blurringY(X_cand,psfY);
obj_cour = 1/(2*sigma2y) * norm(err_courY(:))^2+ U_cour +1/(2*p_cov)*norm(p(:))^2;
obj_cand = 1/(2*sigma2y) * norm(err_candY(:))^2+ U_cand +1/(2*p_cov)*norm(p_cand(:))^2;
rho = min([1 exp(obj_cour-obj_cand )]);
if rand<rho
    X = X_cand;
    ac_Mark=1;
else
    ac_Mark=0;
end

Window=[Window(:,2:Col) ac_Mark];
accept_r=sum(Window,2)/Col;
%Adjust the stepsize adaptively with the acceptance ratio
alpha=1;
if accept_r*alpha+rho*(1-alpha)<0.3
    zeta=zeta*0.9;
elseif accept_r*alpha+rho*(1-alpha)>0.9
    zeta=zeta*1.1;
end