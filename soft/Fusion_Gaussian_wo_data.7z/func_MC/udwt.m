function d_image = udwt(in_image,lo_d, hi_d, level)

% Wavelet transform of the input image
% in_image: the input image
% Lo_D: the low-pass decomposition filter
% Hi_D: the high-pass decomposition filter
% Level: the wavelet decomposition level

% cols = (size(in_image))[1]
% rows = (size(in_image))[2]
[rows,cols]=size(in_image);


% d_image = fltarr(cols, rows, 3*level+1)
d_image = zeros(rows,cols,3*lvel+1);


cur_image = in_image;
% l_image = fltarr(cols, rows)
% h_image = fltarr(cols, rows)
l_image = zeros(rows,cols);
h_image = zeros(rows,cols);

for k = 1:level %0, level-1 do begin

  sample_space = 2^k;

  for l = 1:sample_space %0, sample_space-1 do begin
%     cur_data = fltarr(cols/sample_space)
    cur_data = zeros(round(cols/sample_space));
    
    for i = 1:rows %0, rows-1 do begin
      for j = l:cols %l, cols-1, sample_space do cur_data[j/sample_space] = cur_image[j,i]
          cur_data(round(j/sample_space)) = cur_image(i,j);
      end
      l_data = udconv(cur_data, lo_d);
      h_data = udconv(cur_data, hi_d);
      for j = l:cols %l, cols-1, sample_space do begin
%         l_image[j,i] = l_data[j/sample_space]
%         h_image[j,i] = h_data[j/sample_space]
            l_image(i,j) = l_data(round(j/sample_space));
            h_image(i,j) = h_data(round(j/sample_space));
       end
     end
  end

  for l = 1:sample_space %0, sample_space-1 do begin
%     cur_data = fltarr(rows/sample_space)
    cur_data = zeros(round(rows/sample_space));
    for j = 1:cols %0, cols-1 do begin
      for i = l:sample_space:rows % l, rows-1, sample_space do cur_data[i/sample_space] = l_image[j,i]
          cur_data(round(i/sample_space)) = l_image(i,j);
      end;
      l_data = udconv(cur_data, lo_d);
      h_data = udconv(cur_data, hi_d);
      for i = l:sample_space:rows %l, rows-1, sample_space do begin
        cur_image(i,j) = l_data(round(i/sample_space));
        d_image(i,j,3*k) = h_data(round(i/sample_space));
      end
    end


    for j = 1:cols  %0, cols-1 do begin
      for i = l:sample_space:rows %l, rows-1, sample_space do cur_data[i/sample_space] = h_image[j,i]
          cur_data(round(i/sample_space)) = h_image(i,j);
      end
      l_data = udconv(cur_data, lo_d);
      h_data = udconv(cur_data, hi_d);
      for i = l:sample_space:rows %l, rows-1, sample_space do begin
        d_image(i,j,3*k+1) = l_data(round(i/sample_space));
        d_image(i,j,3*k+2) = h_data(round(i/sample_space));
      end
    end
  end

end

d_image(:,:,3*level) = cur_image;


% return, d_image
% 
% 
% END