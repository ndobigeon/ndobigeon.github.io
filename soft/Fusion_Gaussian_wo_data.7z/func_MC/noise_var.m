SNR_set=5:5:30;band_set=[45 25 8];
for nu=1:6
 load(num2str(SNR_set(nu)));
 sigma2y_MMSE(nu)=mean(sigma2y.sample(Nbi:end));
 sigma2y_real_set(nu)=sigma2y_real;
 sigma2z_MMSE(nu)=mean(sigma2z.sample(Nbi:end));
 sigma2z_real_set(nu)=sigma2z_real;
 sigma2y_var(nu)=var(sigma2y.sample(Nbi:end));
 sigma2z_var(nu)=var(sigma2z.sample(Nbi:end));
%  disp([sigma2y_real      sigma2y_MMSE(nu)  sigma2y_var(nu)])
%  disp([sigma2z_real(nu)  sigma2z_MMSE(nu)  sigma2z_var(nu)])
%  tempY=func_blurringY(X_real-var_dim(var_dim(X_real,P_vec,'dec'),P_vec,'inc'),psfY);
%  tempZ=func_blurringZ(X_real-var_dim(var_dim(X_real,P_vec,'dec'),P_vec,'inc'),psfZ_unk);
%  tempY2=tempY.*(randn(size(Y))*sqrt(sigma2y_real(nu)));
%  tempZ2=tempZ.*(randn(size(Z))*sqrt(sigma2z_real(nu)));
%  deltaY(nu)=(2*sum(tempY2(:))+norm(tempY(:))^2)/(numel(Y)-2);
%  deltaZ(nu)=(2*sum(tempZ2(:))+norm(tempZ(:))^2)/(numel(Z)-2);
%  disp([deltaY(nu)  sigma2y_MMSE(nu)-deltaY(nu)])
%  disp([deltaZ(nu)  sigma2z_MMSE(nu)-deltaZ(nu)])
end
figure(10)
if min(SNR_MS)==max(SNR_MS)
    subplot(2,1,1)
    x_name=SNR_HS;
    plot(x_name,sigma2y_real_set, 'ro-');
    hold on
    errorbar(x_name,sigma2y_MMSE,sqrt(sigma2y_var),'b-')
    xlabel('SNR_1(dB)')
    ylabel('$$\widehat{s}^2_1$$','Interpreter','Latex')
    legend('Actual','Estimation')
    hold off
    print(figure(10),'-depsc','D:\qwei2\Bayesian_fusion\figures\Var_Noise1.eps')
elseif min(SNR_HS)==max(SNR_HS)
    subplot(2,1,2)
    x_name=SNR_MS;
    plot(x_name,sigma2z_real_set, 'ro-');
    hold on
    errorbar(x_name,sigma2z_MMSE,sqrt(sigma2y_var),'b-')
    xlabel('SNR_2(dB)')
    ylabel('$$\widehat{s}^2_2$$','Interpreter','Latex')
    legend('Actual','Estimation')
    hold off
    print(figure(10),'-depsc','D:\qwei2\Bayesian_fusion\figures\Var_Noise2.eps')
end
% axis([5 35 min(sigma2y_real)*0.9 max(sigma2y_MMSE)*1.1])
nb=size(XM,3);
sigma2y.MMSE=  mean(sigma2y.sample(:,Nbi+1:end),2);
sigma2y.var =  var(sigma2y.sample(:,Nbi+1:end),0,2);
sigma2z.MMSE=  mean(sigma2z.sample(:,Nbi+1:end),2);
sigma2z.var =  var(sigma2z.sample(:,Nbi+1:end),0,2);
figure(10);
subplot(2,1,1);semilogy(1:N_band,sigma2y.MMSE,'b-',1:N_band,sigma2y_real,'r-');
hold on; errorbar(1:N_band,sigma2y.MMSE,sqrt(sigma2y.var),'b-');xlim([1 N_band])
xlabel('HS bands','FontSize',18);ylabel('Noise Variances','FontSize',18)
legend('Estimation','Actual');
print(figure(10),'-depsc','D:\qwei2\Bayesian_fusion\figures\Var_Noise1.eps')
subplot(2,1,2);semilogy(1:nb,sigma2z.MMSE,'b-',1:nb,sigma2z_real,'r-');
hold on; errorbar(1:nb,sigma2z.MMSE,sqrt(sigma2z.var),'b-');xlim([1 nb])
xlabel('MS bands','FontSize',18);ylabel('Noise Variances','FontSize',18)
legend('Estimation','Actual');
print(figure(10),'-depsc','D:\qwei2\Bayesian_fusion\figures\Var_Noise2.eps')
% % subplot(2,1,2)
% plot(x_name,sigma2z_real,'r-')
% hold on
% errorbar(x_name,sigma2z_MMSE,sqrt(sigma2z_var),'b-')
% % 'bo',SNR_MS,sigma2z_MMSE-deltaZ,'k*')
% % (SNR_MS,sigma2y_MMSE,sqrt(sigma2y_var),'b-')
% legend('Actual','Estimation')
% % axis([5 35 min(sigma2y_real)*0.9 max(sigma2y_MMSE)*1.1])
% legend('Actual','Estimation')
% xlabel('SNR_2(dB)')
% ylabel('$$\widehat{s^2_2}$$','Interpreter','Latex')

