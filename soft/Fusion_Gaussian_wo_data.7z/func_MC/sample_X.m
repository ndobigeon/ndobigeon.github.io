function X = sample_X(Y,X,psf,sigma2y,s2)

[N_row N_col L] = size(X);

% h = waitbar(0,'Please wait...');
for i=1:N_row
%     waitbar(i/N_row,h)
    for j=1:N_col
        
              
        for k=1:L

            X_i = squeeze(X(:,:,k));
            X_i(i,j) = 0;
            e1 = squeeze(Y(:,:,k)) - func_blurring(X_i,psf);
            MATzeros_i = zeros(N_row,N_col);
            MATzeros_i(i,j) = 1;
            h1 = func_blurring(MATzeros_i,psf);
            h1Te1 = h1(:)'*e1(:);                       
            
            eta2 = 1/(1/s2 + norm(h1)^2/sigma2y);
    
            mu = eta2*(h1Te1/sigma2y);
            
            X(i,j,k) = randn(1)*sqrt(eta2) + mu;

           
            
            
        end
    end
end
% close(h)