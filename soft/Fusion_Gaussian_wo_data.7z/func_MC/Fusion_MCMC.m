%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%  The implementation of Hybrid Monte Carlo method to evaluate the joint posterior distribution
%   AUTHOR: Qi WEI, University of Toulouse, qi.wei@n7.fr
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sample_kernel='HMC';
% length_max=20*10^((SNR_MS-5)/20)
% length_max=20+(SNR_MS-5)*2;
length_max=100;
% SNR_R_set=4:2:30;  SNR_R_set=inf;
% for i_R=1:length(SNR_R_set)
%     SNR_R=SNR_R_set(i_R);
%% All Model Parameters 
Para_Prior_Initial;
%% Parameters for MCMC
Nbi = 1000; Nmc = Nbi+1000;
para.Num_G=1;para.beta_v=0;
%% Prior Parameters
prior='GMM'; 
if strcmp(prior,'Dic')
    load('data\Dic_pleiades_subset.mat');para.D=D;
    load('supporte');para.supp=supp;
end
%% Sampler
%Nbr_PC = 1:1:1; for nu=1:length(Nbr_PC)  
%% Run 5 chains to judge when to converge
N_Chain=1; Mean_Chain=zeros([size(X_real,1) size(X_real,2) nb_sub N_Chain]);Var_cache=zeros(size(Mean_Chain));
% Interpolate the MS image to generate the roughly restored HRHS image
Z_int=repmat(XM,[1 1 floor(size(XHd_int,3)/size(XM,3)+1)]);Z_int=Z_int(:,:,1:size(X_real,3));
for Chain=1:N_Chain  
    X=(1-(Chain-1)/N_Chain)*XHd_int+((Chain-1)/N_Chain)*Z_int;    
    % X=(XHd_int+Z_int)/2; X=Z_int;
    X=var_dim(X,P_dec);
    tic
    [miu_x.sample,Cov_x.sample,sigma2y.sample,sigma2z.sample,Mark.sample,psfZ_sample,X_MMSE,MAP_est,X_Var,...
        RMSE_HMC,zeta_Chain,X_test,track_change,rho,accept_r] = Gibbs_sampler(X,XH,XM,psfY,psfZ_unk,...
        Nbi,Nmc,length_max,prior,P_inc,P_dec,para,band_set,Para_Prior,sample_kernel,X_real,Verbose);
    Costime.(FusMeth)=toc;
    if strcmp(Verbose,'on')
        plot_results;
    end
    Mean_Chain(:,:,:,Chain)=X_MMSE;
    Var_cache(:,:,:,Chain)=X_Var;
end
%     X_MMSE_R_set(:,:,:,i_R)=X_MMSE;
% end
%% Calculate the PSRF
PSRF=PSRF_Cal(N_Chain,Mean_Chain,Var_cache,Nmc,Nbi);
X_MAP=X_real;
Mean_TSNR=var_dim(X_MMSE,P_inc);
HSFusion.(FusMeth)=Mean_TSNR;