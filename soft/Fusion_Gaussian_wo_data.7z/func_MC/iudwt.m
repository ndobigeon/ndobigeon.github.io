function r_image = iudwt(d_image, lo_r, hi_r, level)

% Inverse wavelet transform
% d_image: wavelet coefficients of an image
% lo_r: the low-pass reconstruction filter
% hi_r: the high-pass reconstruction filter
% level: the wavelet decomposition level

% result = size(d_image)
% cols = result(1)
% rows = result(2)
[rows,cols] = size(d_image);
cur_LL = zeros(rows, cols);
cur_LH = zeros(rows, cols);
cur_HL = zeros(rows, cols);
cur_HH = zeros(rows, cols);

cur_LL(:,:) = d_image(:,:,3*level);

for k = level:-1:0  

  cur_LH(:,:) = d_image(:,:,3*k);
  cur_HL(:,:) = d_image(:,:,3*k+1);
  cur_HH(:,:) = d_image(:,:,3*k+2);

  sample_space = 2^k;

  l_data = zeros(round(rows/sample_space));
  h_data = zeros(round(rows/sample_space));
  l_image = zeros(rows, cols);
  h_image = zeros(rows, cols);

  for l = 1:sample_space%0, sample_space-1  
    for j = 1:cols %0, cols-1  
      for i = l:sample_space:rows %l, rows-1, sample_space  
        l_data(round(i/sample_space)) = cur_LL(i,j);
        h_data(round(i/sample_space))= cur_LH(i,j);
      end
      l_data = urconv(l_data, h_data, lo_r, hi_r);
      for i = l:sample_space:rows%do l_image(i,j) = l_data(i/sample_space)
          l_image(i,j) = l_data(round(i/sample_space));
      end
      for i = l:sample_space:rows  
        l_data(i/sample_space) = cur_HL(i,j);
        h_data(i/sample_space) = cur_HH(i,j);
      end
      h_data = urconv(l_data, h_data, lo_r, hi_r);
      for i = l:sample_space:rows %do h_image(i,j) = h_data(i/sample_space)
          h_image(i,j) = h_data(round(i/sample_space));
      end
    end
  end


  l_data = zeros(round(cols/sample_space));
  h_data = zeros(round(cols/sample_space));
  for l = 1:sample_space %0, sample_space-1  
    for i = 1:rows %0, rows-1  
      for j = l:sample_space:cols 
        l_data(round(j/sample_space)) = l_image(i,j);
        h_data(round(j/sample_space)) = h_image(i,j);
      end
      l_data = urconv(l_data, h_data, lo_r, hi_r);
      for j = l:sample_space:cols % do l_image(i,j) = l_data(j/sample_space)
          l_image(i,j) = l_data(round(j/sample_space));
      end
    end
  end


  cur_LL = l_image;

end

r_image = cur_LL;
% 
% 
% return, r_image
% 
% END