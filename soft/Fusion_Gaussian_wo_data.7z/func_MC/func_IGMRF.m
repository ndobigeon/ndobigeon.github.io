function [bx1,by1,bu1,bv1,bx2,by2,bu2,bv2] = func_IGMRF(Z_r)
global Z_max; global X_real;
% Z_r=squeeze(mean(Z_r,3));
Z_rc=zeros(size(Z_r,1)+2,size(Z_r,2)+2,size(Z_r,3));
 for i=1:size(Z_r,3)
     Z_r_u= 2*Z_r(1,:,i)-Z_r(2,:,i);
     Z_r_d= 2*Z_r(end,:,i)-Z_r(end-1,:,i);
     Z_r_l= 2*Z_r(:,1,i)-Z_r(:,2,i);
     Z_r_r= 2*Z_r(:,end,i)-Z_r(:,end-1,i);
     Z_rc(:,:,i)=[(Z_r_u(1)+Z_r_l(1))/2,Z_r_u,(Z_r_u(1)+Z_r_r(1))/2;
         Z_r_l,Z_r(:,:,i),Z_r_r;
         (Z_r_d(1)+Z_r_l(1))/2,Z_r_d,(Z_r_d(1)+Z_r_r(1))/2;];
 end


% Z_rc=zeros(size(Z_r,1)+2,size(Z_r,2)+2,size(Z_r,3));
% Z_rc(2:end-1,2:end-1,:)= Z_r;

% bx1 = 1./(8*max((Z_r-Z_rc(1:end-2,2:end-1,:)).^2,1/Z_max));
% by1 = 1./(8*max((Z_r-Z_rc(2:end-1,1:end-2,:)).^2,1/Z_max));
% bu1 = 1./(8*max((Z_r-Z_rc(1:end-2,1:end-2,:)).^2,1/Z_max));
% bv1 = 1./(8*max((Z_r-Z_rc(1:end-2,3:end,:)).^2,1/Z_max));
% bx2 = 1./(8*max((Z_r-Z_rc(3:end,2:end-1,:)).^2,1/Z_max));
% by2 = 1./(8*max((Z_r-Z_rc(2:end-1,3:end,:)).^2,1/Z_max));
% bu2 = 1./(8*max((Z_r-Z_rc(3:end,3:end,:)).^2,1/Z_max));
% bv2 = 1./(8*max((Z_r-Z_rc(3:end,1:end-2,:)).^2,1/Z_max));
% bx1=mean(bx1,3);
% by1=mean(by1,3);
% bu1=mean(bu1,3);
% bv1=mean(bv1,3);
% bx2=mean(bx2,3);
% by2=mean(by2,3);
% bu2=mean(bu2,3);
% bv2=mean(bv2,3);


% bx1=1./mean2(1./bx1)*ones(size(Z_r));
% by1=1./mean2(1./by1)*ones(size(Z_r));
% bu1=1./mean2(1./bu1)*ones(size(Z_r));
% bv1=1./mean2(1./bv1)*ones(size(Z_r));
% bx2=1./mean2(1./bx2)*ones(size(Z_r));
% by2=1./mean2(1./by2)*ones(size(Z_r));
% bu2=1./mean2(1./bu2)*ones(size(Z_r));
% bv2=1./mean2(1./bv2)*ones(size(Z_r));

% bx1=mean2(bx1)*ones(size(Z_r));
% by1=mean2(by1)*ones(size(Z_r));
% bu1=mean2(bu1)*ones(size(Z_r));
% bv1=mean2(bv1)*ones(size(Z_r));
% bx2=mean2(bx2)*ones(size(Z_r));
% by2=mean2(by2)*ones(size(Z_r));
% bu2=mean2(bu2)*ones(size(Z_r));
% bv2=mean2(bv2)*ones(size(Z_r));

bx1=1/(8*var(X_real(:)))*ones(size(Z_r));
by1=bx1;
bu1=bx1;
bv1=bx1;
bx2=bx1;
by2=bx1;
bu2=bx1;
bv2=bx1;