function uiqi_value=uiqi(A,B)
% L=size(A,3);
% miu_a=zeros(1,L); sigma2_a=zeros(1,L);
% miu_b=zeros(1,L); sigma2_b=zeros(1,L);
% sigma_ab=zeros(1,L);uiqi_value=zeros(1,L);
% for i=1:L
%     miu_a(1,i) = mean2(squeeze(A(:,:,i)));
%     miu_b(1,i) = mean2(squeeze(B(:,:,i)));
%     sigma_ab(1,i)=covariance_matrix(squeeze(A(:,:,i)),squeeze(B(:,:,i)));
%     sigma2_a(1,i)=covariance_matrix(squeeze(A(:,:,i)),squeeze(A(:,:,i)));
%     sigma2_b(1,i)=covariance_matrix(squeeze(B(:,:,i)),squeeze(B(:,:,i)));
%     uiqi_value(1,i)=4*sigma_ab(1,i)*miu_a(1,i)*miu_b(1,i)/(sigma2_a(1,i)+sigma2_b(1,i))/(miu_a(1,i)^2+miu_b(1,i)^2);
% end
% uiqi_value=mean(uiqi_value);

miu_a = squeeze(mean(mean(A,1),2));sigma2_a =covariance_matrix(A,A);
miu_b = squeeze(mean(mean(B,1),2));sigma2_b =covariance_matrix(B,B);
sigma_ab =covariance_matrix(A,B);
uiqi_value =4*diag(sigma_ab).*miu_a.*miu_b./diag(sigma2_a+sigma2_b)./(miu_a.^2+miu_b.^2);
uiqi_value=mean(uiqi_value);