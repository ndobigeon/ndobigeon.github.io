%% Draw figures
colorset=['r-' 'g-' 'b-'];size_d=size(P_dec',2);
if strcmp(prior,'Gaussian1')
    figure(2)
    subplot(2,2,1);
    xlabel('N_{MC}');ylabel('\mu_x');
    for i=1:block_diag*(L-1)+1
        hold on;plot(1:Nmc,miu_x.sample(i,:),colorset(i),'LineWidth',1);
        hold on;plot(1:Nmc,kron(ones(1,Nmc),squeeze(miu_x_real(i))),colorset(i),'LineWidth',2)
    end
    legend('Band-R Sample','Band-R Real','Band-G Sample','Band-G Real','Band-B Sample','Band-B Real')

    subplot(2,2,2);
    xlabel('N_{MC}');ylabel('\sigma_x^2')
    for i=1:block_diag*(L-1)+1
        hold on;semilogy(1:Nmc,s2.sample(i,i:block_diag*(L-1)+1:end),colorset(i),'LineWidth',1); 
        hold on;semilogy(1:Nmc,s2_real(i,i),colorset(i),'LineWidth',2);  
    end 
    legend('Band-R Sample','Band-R Real','Band-G Sample','Band-G Real','Band-B Sample','Band-B Real')
    
    disp([squeeze(miu_x_real)  mean(miu_x.sample(:,Nbi:end),2).*ones(L,1)])
    s2_MMSE=zeros(L,block_diag*(L-1)+1);
    for i=1:block_diag*(L-1)+1
        s2_MMSE(:,i)=mean(s2.sample(:,Nbi*L+i:block_diag*(L-1)+1:end),2);
    end
    if block_diag==0
        disp([s2_real 1./s2_MMSE]);
    elseif block_diag==1
        disp([s2_real inv(s2_MMSE)]);
    end
    disp([sigma2y_real mean(sigma2y.sample(Nbi:end))])
    disp([sigma2z_real mean(sigma2z.sample(Nbi:end))])
elseif strcmp(prior,'GMM')
%     disp([P_vec*squeeze(miu_x_real)  squeeze(mean(miu_x.sample(:,Nbi:end,:),2))])
    s2_MMSE=zeros(size_d,size_d,para.Num_G);
    for i=1:size_d
        s2_MMSE(:,i,:)=mean(Cov_x.sample(:,Nbi*size_d+i:size_d:end,:),2);
    end
    for i=1:para.Num_G
%         disp([P_vec*s2_real*P_vec' inv(squeeze(s2_MMSE(:,:,i)))]);
        disp(inv(squeeze(s2_MMSE(:,:,i))));
    end
%     disp([sigma2y_real mean(sigma2y.sample(:,Nbi:end),2) var(sigma2y.sample(:,Nbi:end),0,2)])
%     disp([sigma2z_real mean(sigma2z.sample(:,Nbi:end),2) var(sigma2z.sample(:,Nbi:end),0,2)])
end
figure(6)
% subplot(2,1,1);semilogy(1:Nmc,sigma2y.sample,'b-',1:Nmc,sigma2y_real*ones(1,Nmc),'r-');xlabel('N_{MC}');ylabel('s_1^2')
subplot(2,1,1);semilogy(1:N_band,mean(sigma2y.sample(:,Nbi+1:end),2),'b-',1:N_band,sigma2y_real,'r-','LineWidth',2);xlabel('HS Bands','FontSize',13);ylabel('Noise Variances','FontSize',13)
mean(sigma2y.sample(:,Nbi+1:end),2);
legend('MMSE','Actual');%axis([0 N_band min(mean(sigma2y.sample(:,Nbi+1:end),2)) max(mean(sigma2y.sample(:,Nbi+1:end),2))])
% axis([0 Nmc sigma2y_real*0.95  mean(sigma2y.sample(Nbi:end))*1.05 ])
% subplot(2,1,2);semilogy(1:Nmc,sigma2z.sample,'b-',1:Nmc,sigma2z_real*ones(1,Nmc),'r-');xlabel('N_{MC}');ylabel('s_2^2')
subplot(2,1,2);semilogy(1:size(XM,3),mean(sigma2z.sample(:,Nbi+1:end),2),'b-',1:size(XM,3),sigma2z_real,'r-','LineWidth',2);xlabel('MS bands','FontSize',13);ylabel('Noise Variances','FontSize',13)
% axis([0 Nmc sigma2z_real*0.8 mean(sigma2z.sample(Nbi:end))*4 ])
legend('MMSE','Actual');%axis([0 Nmc min(sigma2z.sample) max(sigma2z.sample)])
print(figure(6),'-depsc','D:\qwei2\Bayesian_fusion\figures\Noise_Estimate.eps')

figure(3);
if strcmp(sample_kernel,'HMC')
    subplot(2,2,1);plot(1:Nmc,accept_r,1:Nmc,0.9*ones(1,Nmc),1:Nmc,0.3*ones(1,Nmc));title('Counted Accept Ratio');xlabel('N_{MC}');
    subplot(2,2,2);plot(1:Nmc,RMSE_HMC);title('RMSE'); xlabel('N_{MC}');ylabel('dB');    
    subplot(2,2,3);plot(1:Nmc,zeta_Chain(:,1:Nmc));title('Stepsize');xlabel('N_{MC}');
    subplot(2,2,4);plot(1:Nmc,rho);title('Caculated Accept Ratio');xlabel('N_{MC}');
else
    plot(1:Nmc,SNR_HMC);title('SNR'); xlabel('N_{MC}');ylabel('dB');  
end


figure(4)
subplot(2,1,1);plot(X_test);title('Correlation of Samples'); xlabel('N_{MC}');
subplot(2,1,2);plot(track_change);title('Different of Samples');    xlabel('N_{MC}');

figure(5);
h_ref=plot((psfZ_unk*P_inc)','r--');hold on
h_est=plot((mean(psfZ_sample(:,:,Nbi+1:end),3))','bo');hold off
title('Spectral Response of MS')
% subplot(2,2,4);plot(X_Var_show(Nbi+1:end)); title('Variance of Samples')

% figure(5)
% % subplot(1,2,1);imshow(Mark,[]);
% subplot(1,2,2);imshow(mean(Mark.sample,3),[]);

%Plot the covariance of each pixel
% X_Varaff = (X_Var-min(X_Var(:)))/(max(X_Var(:))-min(X_Var(:)));
% figure(13)
% for i=1:L
% %     figure(12+i);
%     subplot(1,L,i)
%     imshow(X_Varaff(:,:,i));
% %     title(['Variance of Fused image: Band ',int2str(i)])
%     colormap gray  %colorbar('YTickLabel',{0.1:0.1:1})
% end