function [psfZ] = sample_psfZ(Z,X,sigma2z,psfZ_0,s2psf_0)
%% Step 1: Generate the matrix which has the identity covaraince matrix
% X=var_dim(X,P_vec,'inc');
U=sigma2z;
X=reshape(X,size(X,1)*size(X,2),size(X,3))';
Z=reshape(Z,size(Z,1)*size(Z,2),size(Z,3))';
% V=inv(X'*X/diag(sigma2z)+eye(size(X,3))/s2psf_0);
V=inv(X*X'+eye(size(X,1))/s2psf_0);
[Q1,D1]=eig(U);
[Q2,D2]=eig(V);

% mu_psfZ=(Z'*X/diag(sigma2z)+psfZ_0/s2psf_0)*Q*sqrt(D);
mu_psfZ=sqrt(D1)\Q1'*(Z*X'+psfZ_0/s2psf_0)*Q2*sqrt(D2);

% Z_b=func_blurringY(Z,psfY);Z_bs=Z_b(1:psfY.ds_r:end,1:psfY.ds_r:end,:);
% Y_s=Y(1:psfY.ds_r:end,1:psfY.ds_r:end,:);
% Y_s=var_dim(Y_s,P_vec,'dec');
% Y_s=reshape(Y_s,size(Y_s,1)*size(Y_s,2),size(Y_s,3));
% Z_bs=reshape(Z_bs,size(Z_bs,1)*size(Z_bs,2),size(Z_bs,3));
% V=inv(Y_s'*Y_s/sigma2z+eye(size(Y_s,3))/s2psf_0);
% [Q,D]=eig(V);
% mu_psfZ=(Z_bs'*Y_s/sigma2z+psfZ_0/s2psf_0)*Q*sqrt(D);

psfZ=randn(size(mu_psfZ))+mu_psfZ;
%% Step 2: Get the desired sample
psfZ=Q1*sqrt(D1)*psfZ*sqrt(D2)*Q2';

% psfZ=Z_bs'*Y_s*inv(Y_s'*Y_s);  %% least squares 