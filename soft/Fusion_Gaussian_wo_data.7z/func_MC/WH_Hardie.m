%% Hardie's method and its counterpart in Wavelet domain
function [HSFusion,time,var_noise_est]= WH_Hardie(Y_int,Z,psfY,sigma2y_real,P_inc,P_dec,FusMeth)
% Z_dec=imresize(func_blurringY(Z,psfY,mask),[size(Z,1),size(Z,2)],'bilinear');
Z_dec=func_blurringY(Z,psfY);
Z_dec=Z_dec(1:psfY.ds_r:end,1:psfY.ds_r:end,:);
% Z_dec=imresize(Z_dec,[size(Z,1),size(Z,2)],'bicubic');
Z_dec=ima_interp_spline(Z_dec,psfY.ds_r);
%% Decrease the dimension
Y_dec=var_dim(Y_int,P_dec);
%% Fusion
if strcmp(FusMeth,'Hardie')
    tic; HSFusion.(FusMeth)  = BayesFusion(Y_dec,Z,Z_dec,P_dec*diag(sigma2y_real)*P_dec');  time.Hardie=toc;var_noise_est=[];
elseif strcmp(FusMeth,'Zhang')
    level=floor(log2(min(size(Z,1),size(Z,2))));
    tic; [HSFusion.(FusMeth),var_noise_est] = BayesFusionWave(Y_dec,Z,Z_dec,level,P_dec*diag(sigma2y_real)*P_dec'); time.Zhang=toc;
end
HSFusion.(FusMeth) = var_dim(HSFusion.(FusMeth),P_inc); % Increase the dimension
