function [ y ] = obser( x )
%OBSERVATION Summary of this function goes here
%   Detailed explanation goes here
    y=exp(x)+x.^2;
end

