function [Mark_nei]=neighbor(Mark)
%Produce neighbor map
Mark_t=zeros(size(Mark)+2); Mark_t(2:end-1,2:end-1)= Mark;
Mark_nei(:,:,1)=Mark_t(1:end-2,1:end-2);%Mark_ul
Mark_nei(:,:,2)=Mark_t(1:end-2,2:end-1);%Mark_um
Mark_nei(:,:,3)=Mark_t(1:end-2,3:end);  %Mark_ur
Mark_nei(:,:,4)=Mark_t(2:end-1,1:end-2);%Mark_ml
Mark_nei(:,:,5)=Mark_t(2:end-1,3:end);  %Mark_mr
Mark_nei(:,:,6)=Mark_t(3:end,1:end-2);  %Mark_dl
Mark_nei(:,:,7)=Mark_t(3:end,2:end-1);  %Mark_dm
Mark_nei(:,:,8)=Mark_t(3:end,3:end);    %Mark_dr