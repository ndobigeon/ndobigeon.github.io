function [SNR,UIQI,SAM]=Quality(HSFusion,Mean_TSNR,X_MAP,X_real,SNR,UIQI,SAM,display)
%Calculate the SNR
SNR.Hardie = 20*log10(norm(X_real(:))/norm(X_real(:)-HSFusion.Hardie(:)));
SNR.WF     = 20*log10(norm(X_real(:))/norm(X_real(:)-HSFusion.Wavelet(:)));
SNR.P      = 20*log10(norm(X_real(:))/norm(X_real(:)-Mean_TSNR(:)));
SNR.MAP    = 20*log10(norm(X_real(:))/norm(X_real(:)-X_MAP(:)));
%Calculate the SSIM
UIQI.Hardie = uiqi(X_real,HSFusion.Hardie);
UIQI.WF     = uiqi(X_real,HSFusion.Wavelet);
UIQI.P      = uiqi(X_real,Mean_TSNR);
UIQI.MAP    = uiqi(X_real,X_MAP);
%Calculate the SAM
SAM.Hardie_whole = acos(sum(X_real.*HSFusion.Hardie,3)./sqrt((sum(X_real.^2,3).*sum(HSFusion.Hardie.^2,3))));   
SAM.Hardie=mean2(SAM.Hardie_whole)/pi*180;

SAM.WF_whole = acos(sum(X_real.*HSFusion.Wavelet,3)./sqrt((sum(X_real.^2,3).*sum(HSFusion.Wavelet.^2,3)))); 
SAM.WF=mean2(SAM.WF_whole)/pi*180;

SAM.P_whole = acos(sum(X_real.*Mean_TSNR,3)./sqrt((sum(X_real.^2,3).*sum(Mean_TSNR.^2,3))));                               
SAM.P=mean2(SAM.P_whole)/pi*180;

SAM.MAP_whole = acos(sum(X_real.*X_MAP,3)./sqrt((sum(X_real.^2,3).*sum(X_MAP.^2,3))));                               
SAM.MAP=mean2(SAM.MAP_whole)/pi*180;

% Display the results
if strcmp(display,'on')
    disp('       Hardie        ZHANG      Proposed    MAP')
    disp([SNR.Hardie,SNR.WF,SNR.P,SNR.MAP ])
%     disp([UIQI.Hardie,UIQI.WF,UIQI.P,UIQI.MAP])
%     disp([SAM.Hardie,SAM.WF,SAM.P,SAM.MAP])
end
% HSFusion_Wavelet_aff=abs(HSFusion_Wavelet/max(HSFusion_Wavelet(:)));
% HSFusion_Hardie_aff=abs(HSFusion_Hardie/max(HSFusion_Hardie(:)));
% figure(6);
% subplot(1,3,1);imshow(HSFusion_Hardie_aff); title('Hardie method')
% subplot(1,3,2);imshow(HSFusion_Wavelet_aff);title('Zhang method')
% subplot(1,3,3);imshow(X_MMSEaff);title('Proposed method')