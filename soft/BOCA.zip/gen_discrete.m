function Y = gen_discrete(X,p,N,M);

% clear all
% clc
% X = [1 8 6];
% p = [.25 .3 .45];
% N = 1;
% M = 1000;


p = p/sum(p);
cum_p = [0 cumsum(p)];

NM = N*M;

z = rand(1,NM);

for i=1:NM
    ind = min(find(z(i)<cum_p));
    Y(i) = X(ind-1);
end
 
Y = reshape(Y,N,M);