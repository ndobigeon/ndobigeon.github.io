function [S_MAP W_MAP Tab_W Tab_S Tab_Q Tab_sigma2 Tab_lambda Tab_crit] = BOCA(X,N,Nmc,isplot)

[M T] = size(X);


% parameter tables
Tab_W = zeros(M,N,Nmc);
Tab_S = zeros(N,T,Nmc);
Tab_Q = zeros(N,T,Nmc);
Tab_sigma2 = zeros(1,Nmc);
Tab_lambda = zeros(1,Nmc);
Tab_a2 = zeros(1,Nmc);
Tab_crit = zeros(1,Nmc);

% MCMC

% fixed hyperparameters
alpha0 = 1;
alpha1 = 1;

beta0 = 1;
beta1 = 1;

% initialization
lambda_est = 0.5;
sigma2_est = 0.001;
a2_est=1;

% initialization with svd
[tmp,Sy,Vy] = svd(X);
W_est = tmp(:,1:N);
clear Sy Vy


S_est = pinv(W_est) * X;
S_est(S_est<max(S_est(:))/10) = 0;
Q_est = double(S_est~=0);
Q_est(:,sum(Q_est,1)>1) = 0;

% MAP computation
logf_opt = -1/eps;
S_MAP = zeros(N,T);
W_MAP = zeros(M,N); 

h = waitbar(0,'Please wait...');
for imc=1:Nmc  
   
    waitbar(imc/Nmc,h)

    logf_cour = eval_logf(W_est,S_est,X,alpha0,alpha1,beta0,beta1);
    if logf_cour>logf_opt && imc>30
        logf_opt = logf_cour;
        W_MAP = W_est;
        S_MAP = S_est;
    end
    
    Tab_W(:,:,imc) = W_est;
    Tab_S(:,:,imc) = S_est;
    Tab_Q(:,:,imc) = Q_est;
    Tab_sigma2(imc) = sigma2_est;
    Tab_lambda(imc) = lambda_est;
    Tab_a2(imc) = a2_est;
    Tab_crit(imc) = norm(norm(X-W_est*S_est))/norm(norm(X));
    
    if isplot
        h1=figure(1);
        plot(Tab_crit)
        title('Lack of fit')
        
        h2=figure(2);
        plot(W_est,'b');        
        hold on
        plot(W_MAP,'b:');
        hold off
        title('Estimated basis')
    
        h3=figure(3);
        for i=1:min([N 4])       
            subplot(min([N 4]),1,i)
            S_estp = S_est;
            S_estp(S_est==0) = NaN;
            S_MAPp = S_MAP;
            S_MAPp(S_MAP==0) = NaN;
            plot(S_estp(i,:),'*')
            hold on
            plot(S_MAPp(i,:),'d')
            plot(zeros(T,1))
            hold off              
        end
        title('Estimated coefficients')
    end
    
    % sampling variance
    sigma2_est = sample_sigma2(S_est,W_est,X);
        
    % sampling binary indicator variables
    if imc<30
        Q_est = sample_Q_ortho_opt(Q_est,W_est,lambda_est,sigma2_est,a2_est,X);
    else
        Q_est = sample_Q_ortho(Q_est,W_est,lambda_est,sigma2_est,a2_est,X);
    end

    % sampling a2
    a2_est = sample_a2(S_est, alpha0, alpha1);
    
    % sampling lambda
    lambda_est = sample_lambda(S_est, beta0, beta1);
    
    % sampling non-zero amplitudes
    S_est = sample_S(Q_est,W_est,sigma2_est,a2_est,X);
    
    % sampling basis vectors
    W_est = sample_W(W_est, S_est , X, sigma2_est);
    

end
close(h)
if isplot
    close(h1)
    close(h2)
    close(h3)
end