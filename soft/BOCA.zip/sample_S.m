function S = sample_S(Q,W,sigma2,a2,X)


[N T] = size(Q);

mu = a2/(sigma2);

S = zeros(N,T);

for t=1:T%randperm(T)%
    q = Q(:,t);
    L = sum(q);
    if L>0
        x = X(:,t);
        ind = (q~=0);
        G0 = W(:,ind);    

        S(ind,t) = a2/sigma2 * (1/(mu+1)) * G0'* x + sqrt(1/(mu+1))*randn(L,1);
    end

end
% S(abs(S)<abs(max(S(:))/20)) = 0;
