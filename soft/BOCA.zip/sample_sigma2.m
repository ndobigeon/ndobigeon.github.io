function sigma2_out = sample_sigma2(S_est,W_est,X)

[N T] = size(S_est);
M = size(X,1);

coeff1 = M*T/2;
coeff2 = 1/2*sum(sum((X-W_est*S_est).^2));

sigma2_out= 1/gamrnd(coeff1,1/coeff2);
