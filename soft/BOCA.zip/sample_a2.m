function a2 = sample_a2(S, alpha0, alpha1)

[N T] = size(S);

VS = S(:);
n1 = sum(VS~=0);
n0 = T*N-1;

tmp1 = alpha0/2+n1/2;
tmp2 = alpha1/2+sum(VS.^2);

a2 = 1./gamrnd(tmp1,1/tmp2);