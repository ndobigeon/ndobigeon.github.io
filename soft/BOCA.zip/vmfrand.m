function R_out = vmfrand(kmu)

if length(kmu)<2
   
    
    error('Parameter size must be greater than 1');
else

    kmu = kmu(:)';

    kap = sqrt(sum(kmu.^2));
    mu = kmu/kap;

    m = length(mu);

    b = ( -2*kap + (4*kap^2+(m-1)^2).^(1/2) )/(m-1);

    x0 = (1-b)/(1+b);
    if (1-x0^2)==0
        c = kap*x0 +(m-1)*log(1e-190);
    else
        c = kap*x0 +(m-1)*log(1-x0^2);
    end
    done =0;
    while ~done 
         Z = betarnd((m-1)/2, (m-1)/2);
         W = ( 1-(1+b)*Z)/(1-(1-b)*Z);
         if (1-x0^2)==0
            done = ( kap*W+(m-1)*log(1e-190)-c > log(rand(1)) );
         else
             done = ( kap*W+(m-1)*log(1-x0^2)-c > log(rand(1)) );
         end
    end
    V = randn(m-1,1) ;
    V = V/sqrt(sum(V.^2));

    x1 = [(1-W^2)^(1/2)*V',W]';    

    R = [null(mu(:)') mu(:)];

    R_out = R*x1;

end