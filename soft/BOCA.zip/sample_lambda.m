function lambda_out = sample_lambda(S_est, alpha0, alpha1)

[N T] = size(S_est);

n1 = sum(S_est(:)~=0);
n0 = N*T-n1;

coeff1 = alpha1 + n1;
coeff0 = alpha0 + n0;

lambda_out = betarnd(coeff1,coeff0);