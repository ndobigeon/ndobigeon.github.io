function Q = sample_Q_ortho(Q,W,lambda,sigma2,a2,X)


[N T] = size(Q);

mu = a2/sigma2;

for t=randperm(T);%1:T
    q = Q(:,t);
    x = X(:,t);

    for i=randperm(N);%i=1:N%  %

        G0 = W(:,q~=0);

        invC0 = 1/(mu+1);        

        w_i = W(:,i);      
        delta_i = (-1)^q(i);

        tau_i = delta_i + mu*norm(w_i)^2-mu^2*w_i'*G0*G0'*w_i*invC0;

        tmp_i = x'*w_i-mu*x'*G0*G0'*w_i*invC0;

        dfi = log(delta_i*tau_i)-mu/(sigma2*tau_i)*tmp_i^2+2*delta_i*log(1/lambda-1);

        if rand>1/(1+exp(-dfi/2))
            q(i) = q(i) + delta_i;
        end       

    end  
    Q(:,t)=q;
end
