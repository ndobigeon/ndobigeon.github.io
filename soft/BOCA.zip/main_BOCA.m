clear all
close all
clc


M = 30;
N = 2;
T = 200;
lambda_true = 0.1;
SNRdB = 15;
a2_true = 100;

% DATA GENERATION
% label genertion
Q_true = zeros(N,T);
for t=1:T
    for i=1:N
        Q_true(i,t) = 2*(rand(1)<lambda_true)/2;
    end
end
% Q_true(:,sum(Q_true,1)>1) = 0;
ind = sum(Q_true,2)==0;
Q_true(ind==1,15) = 1;


% data generation
S_true = Q_true.*(randn(N,T)*sqrt(a2_true));


% basis generation
f0 = 0.01*100/M;
W_true = zeros(M,N);
for i=1:N
    W_true(:,i) = cos(2*i*pi*f0*(1:M))';
end
W_true = orth(W_true);

% data without noise
X = W_true*S_true;
Ps = mean(X(:).^2);

% noise
sigma2_true = Ps*10^(-SNRdB/10);
E = randn(M,T)*sqrt(sigma2_true);

X = X + E;

figure(98)
plot(W_true,'b')


figure(99)
% S_true(S_true==0) = NaN;
for i=1:min([N 4])       
    subplot(min([N 4]),1,i)
    plot(S_true(i,:),'b.')
end

Nmc = 100;
isplot = 0;
[S_MAP W_MAP Tab_W Tab_S Tab_Q Tab_sigma2 Tab_lambda Tab_crit] = BOCA(X,N,Nmc,isplot);

% finding permutations
MATperf = W_true'*W_MAP;
Tind = 1:N;
S_MAPp = S_MAP*0;
W_MAPp = W_MAP*0;
for i=1:(N)
     [indm  indij] = (max(abs(MATperf(i,Tind))));
     S_MAPp(i,:) = S_MAP(indij,:)*sign(MATperf(i,indij));
     W_MAPp(:,i) = W_MAP(:,indij)*sign(MATperf(i,indij));
     MATperf(:,indij) = 0;
end

figure(98)
hold on
plot(W_MAPp,'r')
hold off


figure(99)
S_MAP(S_MAPp==0) = NaN;
for i=1:min([N 4])       
    subplot(min([N 4]),1,i)
    hold on
    plot(S_MAPp(i,:),'rd')
    hold off
end