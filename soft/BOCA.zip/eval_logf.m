function logf_out = eval_logf(W_est,S_est,X,alpha0,alpha1,beta0,beta1)

[N M] = size(W_est);
T = size(S_est,2);

tmp1 = X-W_est*S_est;
tmp1 = tmp1(:);

n1 = sum(tmp1~=0);
n0 = N*T-n1;

logf_out = -T*M/2 * log(sum(tmp1.^2))+eval_logbeta(beta1+n1,beta0+n0) + gammaln(alpha0/2+n1/2) ...
             - (n1/2+alpha0/2)*log(alpha1/2 + 1/2 * sum(S_est(:).^2));
        

%%
function logbeta_out = eval_logbeta(x,y)

logbeta_out = gammaln(x)+gammaln(y)-gammaln(x+y);
