function W_out= sample_W(W_in, S, X, sigma2)

[N T] = size(S);

W_out = W_in;

for j=randperm(N);1:N;%
        
        comp_j = setdiff(1:N,j);
        E = X-W_out(:,comp_j)*S(comp_j,:);
        
        muj = sum(E*S(j,:)'*ones(1,T),2);
        
        Nj = null(W_out(:,comp_j)');

                
        tmp = 1/(sigma2) * muj' *  Nj;
        
        if length(tmp)>1
        
            if sum(tmp)==0
                tmp = tmp+eps^2;
            end

            vj = vmfrand((tmp));
            W_out(:,j) = Nj*vj; 
            
        else
            if sum(tmp)==0

                vj = rand*2*pi - pi;
            
                 vj = cos(vj);% + (1-sign(tmp))*pi/2;
                 W_out(:,j) = Nj*vj;%/norm(Nj*vj); %
            else           
            
                vj = randraw('vonmises',[(1-sign(tmp))*pi/2 abs(tmp)]) ;

                vj = cos(vj) ;%+ (1-sign(tmp))*pi/2;
                W_out(:,j) = Nj*vj/norm(Nj*vj); %
            end
            
            
        end
            
        
%         if sum(muj)~=0
% 
%             Nj = null(W_out(:,comp_j)');
% 
%             tmp = 1/(sigma2) * muj' *  Nj;
% 
%             vj = vmfrand((tmp));
%             W_out(:,j) = Nj*vj; 
% 
%         end

        
end

