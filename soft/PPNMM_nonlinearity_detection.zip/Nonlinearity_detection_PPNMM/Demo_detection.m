clear all
close all
clc

% Loading the endmember matrix
load spectres.txt spectres

R = 3; % Number of endmembers (bounded to 6 due to the 
       % length of the library "spectres.txt"

N= 400; % Number of pixels 

MPlus= spectres(:,2:R+1);
wavelength=spectres(:,1);

L= size(MPlus,1); % Number of spectral bands

%% Generation of synthetic pixels according to the PPNMM
display('Generating synthetic pixels...')
y=zeros(L,N);
sigma2=5*10^(-4);
B=zeros(N,1);
B(1:floor(N/2))=-0.3+ 0.6*rand(floor(N/2),1);
alpha=zeros(N,R);
for n=1:N
    alpha(n,:)=gamrnd(1,1,1,R);
    alpha(n,:)=alpha(n,:)/sum(alpha(n,:));
    y(:,n)=gene_poly2(MPlus,alpha(n,:)',B(n))+ sqrt(sigma2)*randn(L,1);
end

%% Nonlinear unmixing using the PPNMM (gradient-based method)
display('Unmixing procedure...')
alpha_est=zeros(N,R);
B_est=zeros(N,1);
sigma2_est=zeros(N,1);
waitbar_flag = waitbar(0,'PPNMM unmixing Subgradient','Name','Unmixing procedure');
for n=1:N
    waitbar(n/N,waitbar_flag)
    [alp_est b_est] = SPPNMM_unmix_subgradient(y(:,n),MPlus);
    alpha_est(n,:)=alp_est;
    B_est(n)=b_est;
    sigma2_est(n)=1/L*norm(y(:,n)-gene_poly2(MPlus,alpha_est(n,:)',B_est(n)))^2;
end
delete(waitbar_flag);

%% Nonlinearity detection
display('Nonlinearity detection...')
PFA=0.05;
decision=zeros(N,1);
for n=1:N
    decision(n) = nonlinearity_detection(MPlus,alpha_est(n,:)',B_est(n),sigma2_est(n),PFA);
end

figure
subplot(221)
imagesc(reshape(B,20,20))
title('Actual b')
colorbar
subplot(222)
imagesc(reshape(B_est,20,20))
title('Estimated b')
colorbar
subplot(223)
imagesc(reshape(decision,20,20))
title('Detection map')
colormap('gray')
colorbar

