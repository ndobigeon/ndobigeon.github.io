function A = sample_A_const(X, S, A, R, N, sigma2e)

%------------------------------------------------------------------
% This function allows to sample the scores
% according to its posterior f(A|...)
%
% USAGE
% A = sample_A(X, S, A, R, N, sigma2e)
%
% INPUTS
% X, S, A : matrices of mixture, sources and mixing coefficients 
% R, N    : number of sources, observations
% sigma2e : the current state of the noise variance
%
% OUTPUTS
% A       : the new state of the A parameter
%
%------------------------------------------------------------------

% USEFUL QUANTITIES
ord = randperm(R); 
jr = ord(R);
comp_jr = ord(1:(R-1));
alpha    = A(:,comp_jr);

u = ones(R-1,1);
M_R = S(jr,:)';
M_Ru = M_R*u';
M = S(comp_jr,:)';
T = (M-M_Ru)'*(M-M_Ru);
T(T==0) = 1000*eps;

for n = 1:N

    % Covariance matrix
    Sigma = pinv(T/sigma2e(n)); 
    % Mean vector
    Mu    = Sigma*((1/sigma2e(n))*(M-M_Ru)'*(X(n,:)'-M_R));

    % Generating according to a truncated multivariate normal distribution
    alpha(n,:) = dtrandnmult(alpha(n,:), Mu, Sigma);

end

% Reconstruction of A
A(:,ord(1:(R-1))) = alpha;
A(:,ord(R))       = max(1-sum(alpha,2), 0);
