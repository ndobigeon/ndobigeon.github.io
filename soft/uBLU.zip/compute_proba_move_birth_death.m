function [ accept proba_accept_move ] = ...
    compute_proba_move_birth_death(M_star, M_est, A_star, A_est, ...
    sigma2, Y)

%------------------------------------------------------------------
% This function allows ones to compute the likelihood ratio
% for the birth/death move
% 
% USAGE
% [ accept proba_accept_move ] = ...
%   compute_proba_move_birth_death(M_star, M_est, A_star, A_est, ...
%   sigma2, Y)
%
% INPUTS
% M_star  : candidate of the factor matrix
% M_est   : current state of the factor matrix
% A_star  : candidate of the score matrix
% A_est   : current state of the score matrix
% sigma2  : noise variance
% Y       : data matrix to be unmixed
%
% OUTPUTS
% accept            : equal to one if the new state is accepted
%                     equal to zero otherwise 
% proba_accept_move : probability of accepted move
%
%------------------------------------------------------------------

% USEFUL QUANTITIES
sigma2 = sigma2(1);
[R N] = size(A_est);

% LIKELIHOOD RATIO
A = -(sum(sum((Y-M_star*A_star).^2)))/(2*sigma2) + ...
    (sum(sum((Y-M_est*A_est).^2)))/(2*sigma2);

ratio = exp(A);

% FINAL PROBABILITY
proba_accept_move =  min([1, ratio]);

% SAMPLING ACCORDING TO proba_accept_move
accept = gen_discrete([1 0], ...
    [proba_accept_move 1-proba_accept_move], 1, 1);
