function Tsigma2p = sample_sigma2(A_est, M_est, Y)

%------------------------------------------------------------------
% This function allows to sample the noise variances
% according to its posterior f(sigma2|...)
%
% USAGE
% Tsigma2p = sample_sigma2(A_est, M_est, Y)
%
% INPUTS
% A_est    : current score matrix
% M_est    : current factor matrix
% Y        : data matrix
%
% OUTPUTS
% Tsigma2p : the new state of the noise variance vector
%
%------------------------------------------------------------------


% Useful quantities
[G N] = size(Y);

tmp = Y - M_est*A_est;

coeff1 = 1/2 * N*G;
coeff2 = 1/2 * sum(sum(tmp.^2))';

% Sampling according to an inverse gamma distribution
Tsigma2p = 1 / gamrnd(coeff1, 1./coeff2);