function X = trandn(Mu, Sigma)

%------------------------------------------------------------------
% This function allows to generate samples according to a 
% positive normal distribution
%
% USAGE
% X = trandn(Mu, Sigma)
%
% INPUTS
% Mu    : mean vector
% Sigma : covariance matrix
%
% OUTPUTS
% X     : generated samples
%
%------------------------------------------------------------------

Mu    = Mu(:);
Sigma = Sigma(:);

T = length(Mu);

U = rand(T,1);
V = erf(- Mu./(sqrt(2)*max(Sigma,eps)));
X = Mu + sqrt(2*Sigma.^2) .* erfinv(-(((1-V).*U + V)==1)*eps+(1-V).*U + V);
X = max(X,eps);
