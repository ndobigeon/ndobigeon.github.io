%% GENERATING SYNTHETIC DATASET

clear all
close all
clc

% USEFUL PARAMETERS
R_true = 3;     % True number of factors
G = 512;        % Number of genes
N = 128;        % Number of samples
SNRdB = 20;     % Signal-to-noise ratio (dB)

% GENERATING SYNTHETIC DATASETS
p = 0.05; % Probability
M_true = (rand(G,R_true)<p) .* randn(G,R_true)*10; % <GxR_true> matrix
M_true = abs(M_true); % Positivity constraint
A_true = rand(R_true,N); % <R_truexN> matrix
A_true = A_true ./ ( ones(R_true,1)*sum(A_true) ); % Sum-to-one constraint

X = M_true * A_true; % <GxN> matrix

% Additive white Gaussian noise
SNR = 10^(SNRdB/10);
sigma2 = mean(1/G * sum(X.^2,2)) / SNR; % Noise variance

Y = X + sqrt(sigma2)*randn(G,N); % <GxN> matrix
Y = abs(Y); % Positivity constraint
Y = Y'; % <NxG> matrix


%% uBLU ALGORITHM

if size(Y,1) == G
    Y = Y';
end % Y = <NxG> matrix

% USEFUL PARAMETERS
Nmc = 500;    % Number of computation iterations
Nbi = 50;     % Number of the Burn-In period
Rmax = 8;       % Maximum number of factors

% supervised : fixed number of factors
% unsupervised : number of factors estimated
Tmode = {'supervised', 'unsupervised'};
mode = Tmode{1};

% Evolving or static mode
switch mode
    case 'supervised'
        R = R_true;
    case 'unsupervised'
        R = Rmax;
end

% ALGORITHM
tic
[Tab_A_MAP Tab_M_MAP Tab_R A_MMSE M_MMSE Tab_error Tab_sigma2 Nmc] = uBLU(Y, R, Nmc, Nbi, mode);
elapsed_time = toc;

% FIRST RESULTS (unsupervised mode)
if strcmp(mode, 'unsupervised')
    hist_R = hist(Tab_R(Nbi+1:end), 1:Rmax);
    [tmp R_MAP] = max(hist_R);
    
    figure('name', 'Tab_R')
    plot(Tab_R);
    xlabel('Number of MCMC iterations');
    ylabel('R');
    
    figure('name', 'Histogram: Tab_R');
    hist(Tab_R(Nbi:end), 1:Rmax);
end
