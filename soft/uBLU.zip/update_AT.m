function [A_out T_out] = update_AT(A_est, T_est, Y, Tsigma2p, ...
    proba_d, proba_u, proba_b, Yphull, Rmax, U, Y_bar)

%------------------------------------------------------------------
% This function allows to update the unknown matrices (A, T) using 
% a birth-death process
%
% USAGE
% [A_out T_out] = update_AT(A_est, T_est, Y, Tsigma2p, ...
%   proba_d, proba_u, proba_b, Yphull, Rmax, U, Y_bar)
%
% INPUTS
% A_est    : current mixing coefficients matrix
% T_est    : current projected factors matrix
% Y        : data matrix
% Tsigma2p : noise variances
% proba_d  : probabilities of death moves
% proba_u  : probabilities of switch moves
% proba_b  : probabilities of birth moves
% Yphull   : convex hull
% Rmax     : maximum number of sources
% U        : inverse projection matrix
% Y_bar    : empirical mean of the data matrix
%
% OUTPUTS
% A_out    : the new state of the A parameter (mixing coefficients)
% T_out    : the new state of the T parameter (projected sources)
%------------------------------------------------------------------


% Useful quantities
[R N] = size(A_est);
G = size(Y, 1);
sigma2 = Tsigma2p;

% The type of proposed move is chosen
move_R = gen_discrete([-1 0 1], [proba_d(R) proba_u(R) proba_b(R)], 1, 1);

% The candidate R is set
R_star = R + move_R;

Nhull = size(Yphull,1);

M_est = U*T_est + Y_bar*ones(1,R);

if R_star ~= R 

    % A move with dimension matching is proposed
    % Birth/death moves
    
    if move_R==1 % BIRTH
%         disp('-> birth proposed')
        % A source is randomly added
        indT = gen_discrete(1:Nhull, ones(1,Nhull), 1, 1);
        
        % The candidat MPlus is built
        ti = Yphull(indT,:)';
        T_star = [T_est ti];
               
        flag_resid = 0;
        if R_star > 3
            flag_resid = test_residual_const(ti, T_est);
        end
        
        if flag_resid == 0
            % A mixing coefficient is added
            w = max([1/N/(1/N+R) betarnd(1/N,R,1,1)])*ones(1,N);
            MAT_w = ones(R,1) * w;
            % The remaining coefficients are re-scaled
            A_star = [A_est.*(1-MAT_w); w];
        end 

        
    else  % DEATH
%         disp('-> death proposed')
        flag_resid = 0;

        % A spectrum is randomly removed
        i = unidrnd(R_star);
        j = unidrnd(R_star);
        T_star = T_est;
%       ti = T_star(:,i);
        T_star(:,i) = [];        
        % The corresponding mixing coefficient is removed
        A_star = A_est;
        w = A_star(i,:);
        A_star(i,:) = [];
        % and distributed to the other coefficients
        A_star(j,:) = A_star(j,:) + w;
        M_star =  U*T_star + Y_bar*ones(1,R_star);
        error_cand = sum(sum((Y - M_star*A_star).^2))/N;
        error_est = sum(sum((Y - M_est*A_est).^2))/N;
        if error_cand > error_est*G
            flag_resid = 1;
        end
        
    end
   
    % Computation of the acceptance ratio

    M_star =  U*T_star + Y_bar*ones(1,R_star);
    
    if flag_resid==0
        % Birth evaluated
        [accept proba_accept_move] = ...
            compute_proba_move_birth_death(M_star, M_est, A_star, A_est, ...
            sigma2, Y);
        if accept == 1
%             disp('move ACCEPTED')           
            A_out = A_star;
            T_out = T_star;
        else
%             disp('move rejected')
            A_out = A_est;
            T_out = T_est;          
        end
        
    else
        % birth or death rejected (when proposed)
        A_out = A_est;
        T_out = T_est;   
    end   
    
else
        
    A_out = A_est;
    T_out = T_est;

end