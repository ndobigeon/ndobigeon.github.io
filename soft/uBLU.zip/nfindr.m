function [endm envlp] = nfindr(y_proj, Niter)

% nfindr cod� avec recuit simul�

[Nb_pix Nb_bandes] = size(y_proj);

Nb_endm = Nb_bandes+1;
 
% Enveloppe QHULL
ind = convhulln(y_proj);

envlp = y_proj(unique(ind),:);

[Nb_sommet Nb_bandes] = size(envlp); 

% Initialisation
ind_perm = randperm(Nb_sommet);
combi = sort(ind_perm(1:Nb_endm));

% calcul du crit�re
candidat_n = envlp(combi,1:Nb_bandes)';
critere_n = -abs(det([candidat_n;ones(1,Nb_endm)]));
candidat_opt = candidat_n;
critere_opt = critere_n;

for iter = 1:Niter

    % candidate
    ind_perm = randperm(Nb_sommet);
    combi = sort(ind_perm(1:Nb_endm));
    candidat = envlp(combi,1:Nb_bandes)';
    critere = -abs(det([candidat;ones(1,Nb_endm)]));
    
    % test
    delta_critere = critere-critere_n;
    if delta_critere<0
        critere_n = critere;
        if critere < critere_opt
            critere_opt = critere;
            candidat_opt = candidat;
        end
    end

end

endm = candidat_opt;


