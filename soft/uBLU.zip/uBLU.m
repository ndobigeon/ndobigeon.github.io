function [Tab_A_MAP Tab_M_MAP Tab_R A_MMSE M_MMSE error Tab_sigma2 Nmc] = uBLU(Y, Rmax, Nmc, Nbi, mode)


%------------------------------------------------------------------
% Unsupervised Bayesian linear unmixing algorithm (uBLU)
%
% USAGE
% [Tab_A_MAP Tab_M_MAP Tab_R error Tab_sigma2 Nmc] = ...
%   unsupervised_blind_unmix_online(Y, Rmax, Nmc, Nbi)
%
% INPUTS
% Y         : data matrix (N samples, G genes)
% Rmax      : maximum number of factors
% Nmc       : number of MCMC iterations
% Nbi       : burn-in period
% mode      : 'supervised' (Rmax is the number of factors to be found)
%             or 'unsupervised' (Rmax is the maximum number of factors that can
%             be found, the number of factors in the mixture is estimated)
%
% OUTPUTS
% Tab_A_MAP : MAP estimation of the factor score matrix (A)
% Tab_M_MAP : MAP estimation of the factors (M)
% Tab_R     : estimated number of factors (R)
% error     : reconstruction error 
% Tab_sigma2: estimated noise variance
% Nmc       : number of MCMC iterations
% -------------------------------------------------------------------------


% USEFUL QUANTITIES
[N, G] = size(Y);		% N: number of samples
                        % G: number of genes

disp('Unsupervised Bayesian linear unmixing (uBLU)...')

% Evolving or static mode
switch mode
    case 'unsupervised'
        disp('UNSUPERVISED MODE');
        disp(['--> Maximum number of factors = ' num2str(Rmax)])
        % Probabilities of moves
        proba_b = [1/3 1/3 ones(1,Rmax-3)/6  0 ]; % Birth move
        proba_d = [ 0   0  ones(1,Rmax-3)/6 1/3]; % Death move
        proba_u = [2/3 2/3 ones(1,Rmax-3)/2 2/3]; % Switch move
        % Initialization
        R = round(Rmax/2);
        A_MMSE = NaN;
        M_MMSE = NaN;
    case 'supervised'
        disp('SUPERVISED MODE');
        disp(['--> R = ' num2str(Rmax) ' factors']);
        % Initialization
        R = Rmax;
        A_MMSE = zeros(R,N);
        M_MMSE = zeros(G,R);
end

% PRE-PROCESSING
[tmp1, tmp2, matU, Y_bar, endm_proj] = find_endm(Y, Rmax, 'nfindr');
clear tmp1 tmp2 tmp3;
T_est = endm_proj(:,1:Rmax);
M_est = matU*T_est + Y_bar*ones(1,Rmax);
M_est = abs(M_est); % Positivity constraint
Y = Y';

% INITIALIZATIONS
A_est = abs(pinv(M_est)*Y); % Positivity constraint
A_est = A_est ./ (sum(A_est,1)'*ones(1,Rmax))'; % Sum-to-one constraint
Tsigma2p = ones(N,1)*5;
Tsigma2r = ones(N,1)*100;
logf_MAP(1:Rmax) = -1/eps;

if strcmp(mode, 'unsupervised')
    for i = 1:20
        if R>2
            [A_est T_est] = update_AT_adhoc(A_est, T_est, matU, ...
                Y_bar, Y, endm_proj);
        end
        R = size(A_est,1);
    end
end

% Initialization of outputs
Tab_R = zeros(1, Nmc);
Tab_sigma2 = zeros(1, Nmc);
Tab_M_MAP = cell(1, Rmax);
Tab_A_MAP = cell(1, Rmax);
error = zeros(1, Nmc);



% MCMC ALGORITHM
waitbar_flag = waitbar(0, ...
    'Please wait during burn-in iterations...', ...
    'Name', 'Unsupervised Bayesian linear unmixing (uBLU)' , ...
    'CreateCancelBtn','setappdata(gcbf,''canceling'',1)');
setappdata(waitbar_flag,'canceling',0)

global run_simulation, run_simulation = 1;

m_compt = 1;
disp('MONTE CARLO ITERATIONS')

while m_compt<=Nmc && run_simulation
    if m_compt > Nbi
        set(findobj(waitbar_flag,'type','patch'), 'edgecolor','g','facecolor','g');
        set(get(findobj(waitbar_flag,'type','axes'),'title'), 'string', 'Push cancel button to get Monte Carlo estimates');
        if getappdata(waitbar_flag,'canceling')
            break
        end
    end
    
     waitbar(m_compt/Nmc, waitbar_flag)
    
    if strcmp(mode, 'unsupervised')
        % UPDATING A and T by birth-and-death process
        [A_est T_est] = update_AT(A_est, T_est, Y, Tsigma2p, ...
            proba_d, proba_u, proba_b, endm_proj(:,1:Rmax)', ...
            Rmax, matU, Y_bar); 
        for i = 1:20
            if R > 2
                [A_est T_est] = update_AT_adhoc(A_est, T_est, matU, ...
                    Y_bar, Y, endm_proj);
            end
            R = size(A_est,1);
        end    
        M_est = matU*T_est + Y_bar*ones(1,R); 
    end
   
    % SAMPLING A and T
    A_est = sample_A_const(Y', M_est', A_est', R, N, Tsigma2p)';
    [T_est M_est] = sample_T_const(A_est, M_est, T_est, Tsigma2p, ...
        matU, Y_bar, Y, endm_proj(:,1:R), Tsigma2r);
    
    % SAMPLING sigma2
    sigma2 = sample_sigma2(A_est, M_est, Y);
    Tsigma2p = sigma2*ones(N,1);
    
    % MAP COMPUTATION
    if m_compt > Nbi
        tmp = Y - M_est*A_est;
        tmp(tmp==0) = 10*eps;
        tmp2 = sum(tmp,1);
        tmp2(tmp2==0) = 10*eps;
        logf_cand = -G*sum(log(tmp2));
        if logf_cand > logf_MAP(R)
            Tab_M_MAP{R} = M_est;
            Tab_A_MAP{R} = A_est;
            logf_MAP(R) = logf_cand;
        end
        if strcmp(mode, 'supervised')
            A_MMSE = (A_MMSE*(m_compt-1) + A_est)/(m_compt);
            M_MMSE = (M_MMSE*(m_compt-1) + M_est)/(m_compt);
        end
        
    end
    
    Tab_R(m_compt) = R;
    Tab_sigma2(m_compt) = sigma2;
    % Computation of reconstruction error (at each MCMC iteration)
    error(1,m_compt) = sum(sum((Y-M_est*A_est).^2))/N/G;

    m_compt = m_compt+1; % next iteration
    
end % MCMC iterations

close;

if run_simulation; delete(waitbar_flag); end
Nmc = m_compt;

disp('END')

if strcmp(mode, 'supervised')
   Tab_A_MAP = Tab_A_MAP{R};
   Tab_M_MAP = Tab_M_MAP{R};
   Tab_R = R;
end

