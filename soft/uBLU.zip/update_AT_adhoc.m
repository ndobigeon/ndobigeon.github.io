function [A_est T_est] = update_AT_adhoc(A_est, T_est, U, Y_bar, Y, ...
    endm_proj)

[R N]= size(A_est);
G = size(Y, 1);

r = 1;

T_t = T_est;
M_t = U*T_t + Y_bar*ones(1,R);
A_t = A_est;

while r<R

    T_cand = T_est(:,setdiff(1:R,r));
    ti = T_est(:,r);
    B = orth(T_cand);
    Vreg = B'*ti;
    tproj = B*Vreg;
    residual = ti-tproj;    
   
    if norm(residual)<(norm(tproj)/((50)))

        disp('err')
        A_est(r,:) = [];
        T_est(:,r) = [];
        
        M_est = U*T_est + Y_bar*ones(1,R-1);  
        
        sigma2 = sample_sigma2(A_est, M_est, Y);
        Tsigma2p = sigma2*ones(N,1);
        
        [T_est M_est] = sample_T_const(A_est, M_est, T_est, Tsigma2p, ...
            U, Y_bar, Y, endm_proj(:,1:R-1), ones(N,1)*100);    
        A_est = sample_A_const(Y', M_est', A_est', R-1, N, Tsigma2p)';
        
        error_cand = sum(sum((Y - M_est*A_est).^2))/N;
        error_t = sum(sum((Y - M_t*A_t).^2))/N;

        if error_cand > error_t*G
            A_est = A_t; 
            T_est = T_t;
        end

        R = size(A_est,1);
   end

   r = r+1;

end
