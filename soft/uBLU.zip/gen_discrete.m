function x = gen_discrete(valeurs, probas, N, M);

%------------------------------------------------------------------
% This function allows to sample the discrete variable x
% which takes the values collected in valeurs
% with the corresponding probabilities probas
%
% USAGE 
% x = gen_discrete(valeurs, probas, N, M);
% 
% INPUTS
% valeurs : possible values for x
% probas  : probabilities of having each discrete value
% N       : number of lines of x to be sampled
% M       : number of columns of x to be sampled
%
% OUTPUTS
% x       : a N-by-M matrix of values belonging in valeurs with
%           probabilities probas
%
%------------------------------------------------------------------

if sum(probas)~=1.,
   probas = probas / sum(probas);
end;

% Cumulative probabilities
probas = probas(:).';
L      = length(probas);
K      = N*M;
psup   = cumsum(probas);
pinf   = [0 psup(1:end-1)];
Pinf   = kron(ones(1,K),pinf(:));
Psup   = kron(ones(1,K),psup(:));

% Generating uniform variables
u = rand(1,K);
U = kron(ones(L,1),u);

% Comparisons
C = (U>Pinf) & (U<Psup);

% Constructing xi from the uniform variables
V = kron(valeurs(:),ones(1,K));
X = V.*C;
x = sum(X);

% Matrix
x = reshape(x,N,M);

