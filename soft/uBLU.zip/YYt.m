function [y] = YYt(x,A)

y = A*(A'*x) / size(A,2);

