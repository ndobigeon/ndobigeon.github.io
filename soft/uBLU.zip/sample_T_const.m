function [T_out M_out] = sample_T_const(A, M, T, Tsigma2p, U, ...
    Y_bar, Y, E_prior, Tsigma2r)

%------------------------------------------------------------------
% This function allows to sample the projected factors
% according to its posterior f(T|...)
%
% USAGE
% [T_out M_out] = sample_T_const(A, M, T, Tsigma2p, Tsigma2r, U, ...
%   Y_bar, Y, E_prior, Tsigma2r)
%
% INPUTS
% A, M, T  : matrices of mixing coefficients, sources and projected sources
% Tsigma2p : noise variances
% U        : inverse projection matrix
% Y_bar    : empirical mean of the data matrix
% Y        : data matrix
% E_prior  : hyperparameters (mean vectors)
% Tsigma2r : hyperparameters (variances)
%
% OUTPUTS
% T_out    : the new state of the T parameter (projected sources)
% M_out    : the new state of the M parameter (sources)
%------------------------------------------------------------------


% Initialisation
T_out = T;
M_out = M;


% Useful quantities
K = size(T_out, 1);
R = size(A,1);
[G N] = size(Y);


% Computation
for r = randperm(R)
    comp_r = setdiff(1:R,r);
    
    alpha_r = A(comp_r,:);
    alphar(1:N) = A(r,:);
    invSigma_r = sum((A(r,:).^2)'./Tsigma2p)*U'*U + 1/Tsigma2r(r)*eye(K);
    Sigma_r = pinv(invSigma_r); 
    
    er = E_prior(:,r);
    
    for k = randperm(K);

        tr = T_out(:,r);
        
        comp_k = setdiff(1:K,k);
        M_r = M_out(:,comp_r);
        Delta_r = (Y-M_r*alpha_r-Y_bar*alphar);
    
        mu = Sigma_r*(U'*(sum(Delta_r.*(ones(G,1)*alphar)./(ones(G,1)*Tsigma2p'),2)) + er/Tsigma2r(r));
        
        skr = Sigma_r(comp_k,k);
        Sigma_r_k = Sigma_r(comp_k,comp_k);
        
        inv_Sigma_r_k = pinv(Sigma_r_k);
        
        muk = mu(k) + skr'*inv_Sigma_r_k*(tr(comp_k,1)-er(comp_k,1));
        s2k = Sigma_r(k,k) - skr'*inv_Sigma_r_k*skr;
        
        % Troncation
        vect_e = (-Y_bar-U(:,comp_k)*tr(comp_k,1))./U(:,k);
        setUp = find(U(:,k)>0);
        setUm = find(U(:,k)<0);
        mup = min([ 1/eps min(vect_e(setUm))]);
        mum = max([-1/eps max(vect_e(setUp))]);

        % Candidate 
        T_cand = T_out;
        T_cand(k,r) = dtrandn_MH(T_out(k,r), muk, sqrt(s2k), mum, mup);
        
        % Residual testing
        flag_resid = test_residual_const(T_cand(:,r), T_cand(:,setdiff(1:R,r)));
        if flag_resid==0
            T_out(k,r) = T_cand(k,r);
            M_out(:,r) = U*T_out(:,r)+Y_bar;
        end      
        
    end
     
end
