function X = dtrandn_MH(X, Mu, Sigma, Mum, Mup)

%------------------------------------------------------------------
% This function allows to generate samples according to a 
% multivariate gaussian distribution, truncated on [Mum, Mup]
%
% USAGE
% X = dtrandn_MH(X, Mu, Sigma, Mum, Mup)
%
% INPUTS
% X     : current samples
% Mu    : mean vector
% Sigma : covariance matrix
% Mum   : lower bound
% Mup   : upper bound
%
% OUTPUTS
% S  : generated samples
%
%------------------------------------------------------------------


Mu_new = Mu - Mum;
Mup_new = Mup - Mum;

if Mu<Mup
    Z = randnt(Mu_new,Sigma,1);
else
    delta = Mu_new - Mup_new;
    Mu_new = -delta;
    Z= randnt(Mu_new, Sigma, 1);
    Z = -(Z-Mup_new );
end

Z = Z + Mum;
cond = (Z<=Mup) &&  (Z>=Mum);
X = (Z.*cond + X.*(~cond));