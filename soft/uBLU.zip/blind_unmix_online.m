function [Tab_A_MAP Tab_M_MAP Tab_R error matU Nmc Tab_A Tab_T] = blind_unmix_online(Y, R, mode, Nmc, MCchains, geo_method, bool_plot)

% Useful quantities
[P L] = size(Y);

% Dimension of space of interest
L_red = R-1;

% Evolving or static mode
switch mode
    case 'evolving'
        disp('EVOLVING MODE');
        disp(['--> Maximum number of factors = ' num2str(R)])
        % Proba of moves
        proba_b = [1/3 1/3 ones(1,R-3)/6  0 ];
        proba_d = [ 0   0  ones(1,R-3)/6 1/3];
        proba_u = [2/3 2/3 ones(1,R-3)/2 2/3];
        % Initialization
        R_est = round(R/2);
    case 'static'
        disp('STATIC MODE');
        disp(['--> R = ' num2str(R) ' factors']);
        % Initialization
        R_est = R;
end

% PCA (Principal Component Analysis)
% (Crude) Geometrical estimation
disp('GEOMETRICAL ENDMEMBER EXTRACTION')
[endm matP matU Y_bar endm_proj y_proj] = find_endm(Y, R, geo_method);

Y = Y';

% MC initialization
T_est = endm_proj(:,1:R_est);
M_est = matU*T_est + Y_bar*ones(1,R_est);
A_est = abs(pinv(M_est)*Y);
A_est = A_est ./ (sum(A_est,1)'*ones(1,R_est))';

Tsigma2p = ones(P,1)*5  ;
Tsigma2r = ones(P,1)*100;

if strcmp(mode, 'evolving')
    for i = 1:20
        if R_est>2
            [A_est T_est] = update_AT_adhoc(A_est, T_est, matU, Y_bar, Y, endm_proj);
        end
        R_est = size(A_est,1);
    end
end

% Plot
if bool_plot
    figure(1)
    plot(M_est)
    title(['Estimated endmembers via Nfindr'])% geo_method])
    drawnow
    disp('--> Press any key to continue')
    pause
end

% MC chains (initialization)
if strcmp(MCchains, 'chains')
     Tab_A = zeros(R, P, Nmc);
     Tab_T = zeros(L_red, R, Nmc);
     Tab_sigma2 = zeros(Nmc, 1);
else
     Tab_A = NaN;
     Tab_T = NaN;
     Tab_sigma2 = NaN;
end
Tab_R = zeros(1, Nmc);
error = zeros(1, Nmc);

% MAP estimates (initialization)
Tab_M_MAP = cell(1, R);
Tab_A_MAP = cell(1, R);
Tab_M_MAP{R_est} = M_est;
Tab_A_MAP{R_est} = A_est;
logf_MAP(1:R) = -1/eps;


% MCMC algorithm
waitbar_flag = waitbar(0,'Push cancel button to stop Monte Carlo iterations','Name','Bayesian linear unmixing','CreateCancelBtn','waitbar_stop');
global run_simulation, run_simulation = 1;
m_compt = 1;
disp('MONTE CARLO ITERATIONS')
while m_compt<=Nmc && run_simulation
    waitbar(m_compt/Nmc,waitbar_flag)

    if strcmp(mode, 'evolving')
        % Updating A and T by birth-and-death process
        [A_est T_est] = update_AT(A_est, T_est, Y, Tsigma2p, proba_d, proba_u, proba_b, endm_proj(:,1:R)', R, matU, Y_bar);  
        for i = 1:20
            if R_est > 2
                [A_est T_est] = update_AT_adhoc(A_est, T_est, matU, Y_bar, Y, endm_proj);
            end
            R_est = size(A_est,1);
        end    
        M_est = matU*T_est+Y_bar*ones(1,R_est); 
    end
    
    % Sampling proportions vectors (abundances or scores) (A)
    A_est = sample_A(Y',M_est',A_est',R_est,P,Tsigma2p)';  

    % Sampling endmembers (M) or factor projections (T)
    [T_est M_est] = sample_T_const(A_est,M_est,T_est,Tsigma2p,Tsigma2r,matU,Y_bar,Y,endm_proj(:,1:R_est));  
    
    % Sampling noise variance (sigma2)
    sigma2 = sample_sigma2(A_est,M_est,Y);
    Tsigma2p = sigma2*ones(P,1);
    
    % Computing MAP estimates
    tmp = Y-M_est*A_est;
    tmp(tmp==0) = 10*eps;
    tmp2 = sum(tmp,1);
    tmp2(tmp2==0) = 10*eps;
    logf_cand = -L*sum(log(tmp2));
    if logf_cand > logf_MAP(R_est)
        Tab_M_MAP{R_est} = M_est;
        Tab_A_MAP{R_est} = A_est;
        logf_MAP(R_est) = logf_cand;
%         disp('update')
    end
    
    % Plot
    if bool_plot
        % Estimated endmembers
        figure(1)
        plot(M_est)
        title('Estimated endmembers')
        drawnow
        % Estimated projected endmembers
        figure(2)            
        scatter(y_proj(1,:),y_proj(2,:),'k.')
        hold on
        for r=1:R_est
            scatter(endm_proj(1,r),endm_proj(2,r),'bo');
            scatter(T_est(1,r),T_est(2,r),'g*');           
        end
        hold off
        legend('Pixels','Est. Endm. (geo)','Current Est. Endm.')
        title('Scatter plot in 2 spectral bands')
        drawnow
    end
  
    % Saving the MC chains
    Tab_R(m_compt) = R_est;
    if strcmp(MCchains, 'yes')
        Tab_A(1:R_est, :, m_compt) = A_est;
        Tab_T(:, 1:R_est, m_compt) = T_est;
    end
    Tab_sigma2(m_compt) = sigma2;
    % Reconstruction error
    error(m_compt) = sum(sum((Y-M_est*A_est).^2))/P;
  
    
    if rem(m_compt,500) == 0
       save(['tmp_uBLU_H3N2_R9_cpt' num2str(m_compt) '.mat']);%, 'A_est', 'T_est', 'M_est', 'sigma2', ) 
    end
    
    m_compt = m_compt + 1;
    
end
close;

if run_simulation; delete(waitbar_flag); end
Nmc = m_compt;
disp('END')

if strcmp(mode, 'static')
   Tab_A_MAP = Tab_A_MAP{R};
   Tab_M_MAP = Tab_M_MAP{R};
   Tab_R = R;
end

end %Function