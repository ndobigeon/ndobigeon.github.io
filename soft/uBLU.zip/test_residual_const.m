function flag_const = test_residual_const(ti, T_cand)

B = orth(T_cand);

Vreg = B'*ti;

tproj = B*Vreg;

residual = ti-tproj;

flag_const = norm(residual)<(norm(tproj)/(50));
