function [endm matP matU Y_bar endm_proj Y_proj] = find_endm(Y, R, geo_method)

% Useful quantities
L_red = R-1;
% Sizing
[P, L] = size(Y);

Y_raw = reshape(Y, P, L);
clear Y;

% Masking
mask = ones(1, L);
Y = Y_raw(:,find(mask==1));
clear Y_raw;
L = length(Y(1,:));

Y = Y';

Y_bar = mean(Y,2);

% PCA (Principal Component Analysis)
disp('Begin - Principal Component Analysis')
Rmat = Y - (Y_bar*ones(1,P)); % <L x P> matrix
% Options for eigs.m
OPTIONS.issym = true; % symetric matrix
OPTIONS.tol = 1.e-10; % convergence
OPTIONS.disp = 0; % diagnostic information display level
OPTIONS.maxit = 5000; % maximum number of iterations
[vect_prop, D] = eigs(@(x)YYt(x,Rmat), L, L_red, 'LM', OPTIONS);
% vect_prop = <L x L_red> matrix
% D = <L_red x L_red> matrix
vect_prop = vect_prop'; %<L_red x L> matrix
disp('End - Principal Component Analysis')

% First L_red eigenvectors
V = vect_prop(1:L_red,:);
V_inv = pinv(V);

% First L_red eigenvalues
D = D(1:L_red, 1:L_red);

% Dsqrtinv = D.^(-1/2);
% Dsqrtinv(find(Dsqrtinv==Inf)) = 0;
Dsqrtinv = D^(-1/2);

% Projector
matP = Dsqrtinv * V;
% Inverse projector
matU = V_inv * D^(1/2);

% Projecting
Y_proj = matP * (Y - Y_bar*ones(1,P)); %<L_red x P> matrix
Y_proj = Y_proj(1:L_red,:)'; %<P x L_red> matrix


switch geo_method
    case 'nfindr'
        % NFINDR
        disp('Begin - N-FINDR')
        Nb_iter = 5000;
        [endm_proj yhull] = nfindr(Y_proj, Nb_iter);
        disp('End - N-FINDR')
        % In hyperspectral space
        % endm = matU*endm_proj + Y_bar*ones(1,R);
        endm = vect_prop'*D^(1/2)*(endm_proj) + Y_bar*ones(1,R); %<L x R> matrix
    case 'vca'
        % VCA
        disp('Begin - VCA')
        [endm] = VCA(Y, 'Endmembers', R, 'verbose', 'off');
        disp('End - VCA')
        % In projected space
        endm_proj = matP*(endm - Y_bar*ones(1,R));
end
    
end % Function
