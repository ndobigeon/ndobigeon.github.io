# # Generate data (noise with a predefined SNR)
# n = 50^2 + 100^2 + 200^2 # total number of pixels
# sz = [0; 50^2; 100^2; 200^2]
# l = 224
# r = 4
# M = max(randn(l, r), 0.0)
# M .= broadcast(./, M, sqrt(sum(M.^2, 1)))
# A = max(randn(r, n), 0.0)
# Y = M*A + 1e-4*randn(l, n)
# M0 = max(randn(l,r),0.0)
# M0 .= broadcast(./, M0, sqrt(sum(M0.^2, 1)))
# A0 = max(randn(r, n), 0.0)
# #
# using JLD
# jldopen("data.jld", "w") do file
#     write(file, "M0", M0)
#     write(file, "A0", A0)
#     write(file, "M", M)
#     write(file, "A", A)
#     write(file, "Y", Y)
#     write(file, "l", l)
#     write(file, "r", r)
#     write(file, "n", n)
#     write(file, "sz", sz)
# end

# Generate data (noise with a predefined SNR)
n = 3*100^2 # total number of pixels
sz = [0; 100^2; 100^2; 100^2]
l = 224 # tester aussi avec un dictionnaire fat (dans un second temps)
r = 4
M = max(randn(l, r), 0.0)
M .= broadcast(./, M, sqrt(sum(M.^2, 1)))
A = max(randn(r, n), 0.0)
Y = M*A + 1e-4*randn(l, n)
M0 = max(randn(l,r),0.0)
M0 .= broadcast(./, M0, sqrt(sum(M0.^2, 1)))
A0 = max(randn(r, n), 0.0)
#
using JLD
jldopen("data.jld", "w") do file
    write(file, "M0", M0)
    write(file, "A0", A0)
    write(file, "M", M)
    write(file, "A", A)
    write(file, "Y", Y)
    write(file, "l", l)
    write(file, "r", r)
    write(file, "n", n)
    write(file, "sz", sz)
end

# S = SharedArray(Int, (3,4), init = S -> S[indexpids(S):length(procs(S)):length(S)] = myid())
#
# l = 4
# r = 3
# S = SharedArray(Int, (4,3), init = S -> S[(indexpids(S)-1)*4+1:indexpids(S)*4] = myid())
