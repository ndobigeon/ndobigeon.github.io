function write_results(dataname::String, filenames::Array{String,1}, texname::String)
    # Instantiate variables
    RE         = zeros(length(filenames))
    GMSE_A     = zeros(length(filenames))
    GMSE_dM    = zeros(length(filenames))
    aSAM_Y     = zeros(length(filenames))
    aSAM_M     = zeros(length(filenames))
    timing     = zeros(length(filenames))
    # Load ground truth
    file       = matopen(dataname)
    # varnames = names(file) # unused ?
    Mth        = read(file,"Mth")
    Ath        = read(file,"Ath")
    Y          = read(file,"Y")
    close(file)
    # Write objective functions (see if different files are absolutely needed)
    for i = 1:length(filenames)
        t = jldopen(filenames[i], "r") do file
            read(file, "t")
        end
        f = jldopen(filenames[i], "r") do file
            read(file, "f")
        end
        A = jldopen(filenames[i], "r") do file
            read(file, "A")
        end
        M = jldopen(filenames[i], "r") do file
            read(file, "M")
        end
        Y_tilde   = M*A
        RE[i]     = sum((Y .- Y_tilde).^2)/(size(Y,1)*size(Y,2))
        GMSE_A[i] = sum((A.- Ath).^2)/(size(A,1)*size(A,2))
        aSAM_M[i] = 180*sum(acos(sum(M.*Mth,1)./sqrt(sum(M.^2,1).*sum(Mth.^2,1))))/size(M,2)/pi  # pogù^pag
        aSAM_Y[i] = sum(acos(sum(Y.*Y_tilde,1)./sqrt(sum(Y.^2,1).*sum(Y_tilde.^2,1))))/size(Y,2) # ikkjzoituh
        id        = findfirst(t[2:end] .<= 0.)
        t         = cumsum(t)
        timing[i] = t[id]
        outputname = "v$(i).txt"
        open(outputname, "w") do file
            writedlm(file, zip(t[1:id], f[1:id]), "\t")
        end
    end
    # Write .tex table of results + voir gestion du format d'écriture (comme en C)
    file = open(texname, "w")
    # s = @sprintf "this is a %s %15.1f" "test" 34.567;
    str = """\\begin{table}[t!]
    \\legende{Résultats de simulation sur données synthétiques.}
        \\begin{center}
            \\begin{tabular}{@{}lcc@{}} \\toprule
                &   Sync.   &   Async.  \\\\   \\cmidrule{2-3}
    aSAM(\$\\mathbf{M}\$) (\\degre)\t""";
    write(file, str)
    # aSAM_M
    for i = 1:length(filenames)
        @printf(file,"& \t %1.2e \t",aSAM_M[i])
    end
    write(file,"\\\\ \n")
    # GMSE_A
    write(file, "GMSE(\$\\mathbf{A}\$)\t")
    for i = 1:length(filenames)
        @printf(file,"& \t %1.2e \t",GMSE_A[i]) # writedlm(file, GMSE_A', "\t&\t")
    end
    write(file,"\\\\ \n")
    # RE
    write(file, "RE\t")
    for i = 1:length(filenames)
        @printf(file,"& \t %1.2e \t",RE[i])
    end
    write(file,"\\\\ \n")
    # aSAM_Y
    write(file, "aSAM(\$\\mathbf{Y}\$) (\\degre)\t")
    for i = 1:length(filenames)
        @printf(file,"& \t %1.2e \t",aSAM_Y[i])
    end
    write(file,"\\\\ \n")
    # time (s)
    write(file, "temps (s)\t")
    for i = 1:length(filenames)
        @printf(file,"& \t %1.2e \t",timing[i])
    end
    write(file,"\\\\ \\bottomrule \n")
    str = """       \\end{tabular}
        \\end{center}
        \\label{tab:results}
    \\end{table}
    """;
    write(file, str)
    close(file)
end

using JLD
using MAT
dataname  = "data/data_async_R9.mat"                    # contains the ground truth
filenames = ["results/sync_R9.mat","results/async_R9.mat"] # files to be compared "palm_sync_R9_stop.jld","async_v3_R9_stop.jld"
texname   = "tabs/tab_results.tex"                      # laTeX table
write_results(dataname, filenames, texname)

# str = """
# Hello,
# world.
# """

# open(texname, "w") do file
#     # s = "\\begin{table}[t!] \n"
#     # s = @sprintf "this is a %s %15.1f" "test" 34.567;
#     str = """\\begin{table}[t!]
#     \\legende{Résultats de simulation sur données synthétiques.}
#         \\begin{center}
#             \\begin{tabular}{@{}lccc@{}} \\toprule
#                 &   Série   &   Sync.   &   Async.  \\\\   \\cmidrule{2-4}
#     aSAM(\$\\mathbf{M}\$) (\\degre)\t&\t""";
#     write(file, str)
#     writedlm(file, RE', "\t&\t")
#     write(file,"\\\\ \n")
#     write(file, "GMSE(\$\\mathbf{A}\$)\t&\t")
#     writedlm(file, GMSE_A', "\t&\t")
#     write(file,"\\\\ \n")
#     # write(file, "GMSE(\$\\mathbf{dM}\$)\t&\t")
#     # writedlm(file, GMSE_dM', "\t&\t")
#     # write(file,"\\\\ \n")
#     write(file, "aSAM(\$\\mathbf{Y}\$)\t&\t")
#     writedlm(file, aSAM_Y', "\t&\t")
#     write(file,"\\\\ \n")
#     write(file, "temps (s)\t&\t")
#     writedlm(file, timing', "\t&\t")
#     write(file,"\\\\ \\bottomrule \n")
#     str = """       \\end{tabular}
#         \\end{center}
#         \\label{tab:results}
#     \\end{table}
#     """;
#     write(file, str)
#end
