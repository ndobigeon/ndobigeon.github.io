# Code ok : gain de temps observé pour la version distribuée (*2)
using MAT
addprocs(3)
include("src_sync/distributed_palm.jl") # _nodM
@time palm_unmix("mat","data/data_async_var_R3.mat","results/sync_var_R3_2.mat",1,1e-3,1e-3,1.) # data_async_R9
print("End of warmup and compilation.")
@time palm_unmix("mat","data/data_async_var_R3.mat","results/sync_var_R3_2.mat",1000,1e-3,1e-5,1.e-4)
print("End of the algorithm.")
rmprocs(workers()) # version très efficace en termes de %gc
exit()
using PyPlot
using JLD
t = jldopen("results/sync_var_R3.mat", "r") do file # resultsDPalm_nodM.jld
    read(file, "t")
end
f = jldopen("results/sync_var_R3.mat", "r") do file
    read(file, "f")
end

figure();
semilogy(cumsum(t), f, color = "blue", label = "Distributed (sync)")
hold

t2 = jldopen("results/async_var_R3.mat", "r") do file # resultsDPalm_nodM.jld
    read(file, "t")
end
f2 = jldopen("results/async_var_R3.mat", "r") do file
    read(file, "f")
end
semilogy(cumsum(t2), f2, color = "red", label = "Distributed (async)")
legend()

#
#
# using MAT
# t = matopen("real/async_rd100.mat", "r") do file # resultsDPalm_nodM.jld
#     read(file, "t")
# end
# f = matopen("real/async_rd100.mat", "r") do file
#     read(file, "f")
# end
# id         = findfirst(t[2:end] .<= 0.)
# t          = cumsum(t)
# outputname = "async_rd100.txt"
# open(outputname, "w") do file
#     writedlm(file, zip(t[1:id], f[1:id]), "\t")
# end
# t = jldopen("resultsPalm_nodM.jld", "r") do file
#     read(file, "t")
# end
# f = jldopen("resultsPalm_nodM.jld", "r") do file
#     read(file, "f")
# end
# semilogy(cumsum(t), f, color = "red", label = "Distributed (sync)", label = "serial")
# xlabel("k")
# ylabel("f")
# legend()


# a = randn(2,100)
# b = @parallel (max) for i  = 1:5
#     max(view(a, :, (i-1)*20+1:i*20))
# end
