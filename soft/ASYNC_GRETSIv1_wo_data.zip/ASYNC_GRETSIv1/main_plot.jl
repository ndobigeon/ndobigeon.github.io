using PyPlot
using JLD

f = jldopen("async_coord.jld", "r") do file
    read(file, "f") # alternatively, say "@write file A"
end
t = jldopen("async_coord.jld", "r") do file
    read(file, "t") # alternatively, say "@write file A"
end
figure()
semilogy(cumsum(t), f, label = "coordinate palm (async)")
hold

f = jldopen("sapalm_async2.jld ", "r") do file # sapalm_async2.jld  sync_coord.jld
    read(file, "f") # alternatively, say "@write file A"
end
t = jldopen("sapalm_async2.jld", "r") do file
    read(file, "t") # alternatively, say "@write file A"
end
semilogy(cumsum(t), f, label = "coordinate palm (sync)")

f = jldopen("palm.jld", "r") do file
    read(file, "f")
end
t = jldopen("palm.jld", "r") do file
    read(file, "t")
end
semilogy(cumsum(t), f, label = "palm (sync)")


legend()
xlabel("t (s)")
ylabel("f")
# savefig("ascpalm_vs_scpalm_index.png")
