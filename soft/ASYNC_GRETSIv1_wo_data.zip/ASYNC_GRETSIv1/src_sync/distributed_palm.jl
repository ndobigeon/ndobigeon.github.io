@everywhere function splxProj!(v, r::Float64)
    if r < 0
    error("Radius of simplex is negative: r = $(r)")
    end
    u     = sort(v, rev = true) # sort in descending order
    sv    = cumsum(u)
    rho   = findlast(u .> (sv - r)./(1:length(u)))
    theta = (sv[rho] - r) / rho
    v    .= max(v .- theta, 0.0)
end

# This function retuns the (irange,jrange) indexes assigned to this worker
@everywhere function myrange(q::SharedArray)
    idx = indexpids(q)
    if idx == 0
        # This worker is not assigned a piece
        return 1:0, 1:0
    end
    nchunks = length(procs(q))
    splits  = [round(Int, s) for s in linspace(0,size(q,2),nchunks+1)]
    splits[idx]+1:splits[idx+1]
    # 1:size(q,1), splits[idx]+1:splits[idx+1]
end

@everywhere function updateAdM_chunk!(Y::SharedArray{Float64,2}, M::Array{Float64,2}, A::SharedArray{Float64,2}, dM::SharedArray{Float64,2}, sigma::Float64, id_channel, myrange)
    r  = size(M,2)
    Mn = Array(Float64,size(M))
    # B  = zeros(size(M))
    C  = zeros(r,r)
    D  = zeros(size(M))
    c  = 0.0
    for n in myrange # (p, n) in myrange
        # Update A
        E = view(dM, :, r*(n-1)+1:r*n)
        Mn .= M .+ E
        mu = vecnorm((Mn.')*Mn, 2)
        A[:,n] .-= (Mn.')*(Mn*view(A,:,n) .- view(Y,:,n))/mu
        splxProj!(view(A,:,n), 1.0)
        C .+= view(A,:,n)*(view(A,:,n))'
        # ccall((:simplexproj_Condat,"D:\\Test_julia\\SplxDll.dll"), Void, (Ref{Cdouble},Ref{Cdouble},UInt64,Ref{Cdouble},),A[:,n],y,R,r); # do in parallel voir Ref{A[:,n]}
        # see http://docs.julialang.org/en/release-0.4/manual/parallel-computing/
        # Update dM
        mu = vecnorm(view(A,:,n)*(view(A,:,n).'), 2)
        dM[:, (n-1)*r+1:n*r] .-= (Mn*view(A,:,n) .- view(Y,:,n))*(view(A,:,n).')/mu
        # E .= max(E,-M) # rajouter par la suite
        E .= E*min(1.0, sigma/vecnorm(E, 2))
        # B .= max(-E, B)
        D .+= (E*view(A,:,n) - view(Y, :, n))*(view(A,:,n).')
        c += sum((E*view(A,:,n) - view(Y, :, n)).^2)
    end
    put!(id_channel, (C, D, c)) # put!(id_channel, (B, C, D, c))
end
@everywhere updateAdM_shared_chunk!(Y, M, A, dM, sigma, id_channel) = updateAdM_chunk!(Y, M, A, dM, sigma, id_channel, myrange(A))

function updateM!(M::Array{Float64,2}, C::Array{Float64,2}, D::Array{Float64,2}, GGt::Array{Float64,2})
    mu  = vecnorm(C + GGt, 2)
    M .-= (M*(C + GGt) + D)/mu # GGt = beta*GGt (pour simplifer)
    broadcast!(max, M, M, 0.)
end

function mdist_prior(R)
    G = zeros(R,R*R);
    el = zeros(R,1);
    for k = 0:R-1
        el[k+1] = 1.;
        G[:,1+k*R:(k+1)*R] = -eye(R) + el*ones(1,R);
        el[k+1] = 0.;
    end
    GGt = G*(G.')
    return GGt
end

# function updateM!(M::Array{Float64,2}, B::Array{Float64,2}, C::Array{Float64,2}, D::Array{Float64,2})
#     mu  = vecnorm(C, 2);
#     M .-= (M*C + D)/mu
#     M  .= max(M, 0.0)
#     M  .= max(M, B) # B = max(max(-dM),0)
# end

function palm_unmix(dataType::String, InputFile::String, OutputFile::String, nIter::Int, sigma::Float64, mu::Float64, stop::Float64)
    # local M::Array{Float64}(2)
    # local A::Array{Float64}(2) # créé une erreur inattendue...
    # local Y::Array{Float64}(2)
    if dataType == "jld"
        Y = jldopen(InputFile, "r") do file
            read(file, "Y")
        end
        M = jldopen(InputFile, "r") do file
            read(file, "M0")
        end
        A = jldopen(InputFile, "r") do file
            read(file, "A0")
        end
    else #.mat
        file = matopen(InputFile)
        M    = read(file, "M0")
        A    = read(file, "A0")
        Y    = read(file, "Y")
        close(file)
    end
    # B     = zeros(size(M))
    D     = zeros(size(M))
    (L,N) = size(Y)
    R     = size(M,2)
    dM    = zeros(L,N*R)
    # Conversion step
    A     = convert(SharedArray, A)
    Y     = convert(SharedArray, Y)
    dM    = convert(SharedArray, dM)
    # Initialization
    f                = zeros(nIter+1)
    const id_channel = RemoteChannel(()->Channel{Tuple}(nworkers()))
    C                = Array(Float64, (size(M,2), size(M,2)))
    timing           = zeros(nIter+1)
    f[1]             = sum((Y .- M*A).^2)/2 # to be computed in parallel ?
    q                = 1
    crit             = 1.
    # Generate GGt for endmember mutual distance
    GGt = mdist_prior(R)
    GGt = mu*GGt
    # PALM
    # for q = 1:nIter
    while (q < nIter) && (crit > stop)
        tic()
        @sync begin
            for k in workers()
                @async remotecall_fetch(updateAdM_shared_chunk!, k, Y, M, A, dM, sigma, id_channel)
            end
        end
        # Update auxiliary variables
        # B .= 0.0
        C .= 0.0
        D .= 0.0
        c  = 0.0
        for k in workers()
            Cw, Dw, cw = take!(id_channel)
            C .+= Cw
            D .+= Dw
            c  += cw
        end
        # for k in workers()
        #     Bw, Cw, Dw, cw = take!(id_channel)
        #     B  .= max(B,Bw)
        #     C .+= Cw
        #     D .+= Dw
        #     c  += cw
        # end
        # Update M
        # updateM!(M, B, C, D)
        updateM!(M, C, D, GGt)
        # Compute objective function
        f[q+1]      = 0.5*(sum(M.*(M*(C + GGt))) + c) + sum(M.*D)
        timing[q+1] = toq()
        crit        = abs(f[q+1] - f[q])/f[q]
        q          += 1
    end
    # Save results (JLD format)
    if dataType == "jld"
        # Save results (JLD format)
        jldopen(OutputFile, "w") do file
            write(file, "A", A)
            write(file, "M", M)
            write(file, "dM", dM)
            write(file, "f", f)
            write(file, "t", timing)
        end
    else #.mat
        A = sdata(A)
        dM = sdata(dM)
        file = matopen(OutputFile, "w")
        write(file, "M", M)
        write(file, "dM", dM)
        write(file, "A", A)
        write(file, "f", f)
        write(file, "t", timing)
        close(file)
    end
    # finalize(id_channel)
    return
end
