function splxProj!(v, r::Float64) # préciser le type de l'ensemble des parmètres d'entrée
    if r < 0.
        error("Radius of simplex is negative: r = $(r)")
    end
    u     = sort(v,rev = true) # sort in descending order
    sv    = cumsum(u)
    rho   = findlast(u .> (sv - r)./(1:length(u)))
    theta = (sv[rho] - r) / rho
    v    .= max(v .- theta, 0.0)
end

function updateA!(Y::Array{Float64,2}, M::Array{Float64,2}, A::Array{Float64,2})
    X   = (M.')*M
    mu  = vecnorm(X,2)
    A .-= (X*A .- (M.')*Y)/mu     # A .-= (M.')*(M*A .- Y)/mu
    for n = 1:size(A,2)
        splxProj!(view(A,:,n), 1.0)
    end
    return
end

function updateM!(Y::Array{Float64,2}, M::Array{Float64,2}, A::Array{Float64,2})
    X   = A*(A.')
    mu  = vecnorm(X, 2) # max(vecnorm(X, 2),eps())
    M .-= (M*X .- Y*(A.'))/mu
    M .= max(M, 0.0)
end

function palm_unmix(InputFile::String, OutputFile::String, nIter::Int)
    local M::Array{Float64,2}
    local A::Array{Float64,2}
    local Y::Array{Float64,2}
    file     = matopen(InputFile)
    varnames = names(file) # unused ?
    M        = read(file,"M")
    A        = read(file,"A")
    Y        = read(file,"Y")
    close(file)
    (L,N)    = size(Y)
    R        = size(M,2)
    # Initialization
    f        = zeros(nIter+1)
    timing   = zeros(nIter+1)
    f[1]     = 0.5*sum((Y .- M*A).^2)
    # PALM
    for q = 1:nIter
        tic()
        # Update A
        updateA!(Y, M, A)
        # Update M
        updateM!(Y, M, A)
        # Compute objective function
        f[q+1] = 0.5*sum((Y .- M*A).^2)
        timing[q+1] = toq()
    end
    # Save results (JLD format)
    jldopen(OutputFile, "w") do file
        write(file, "A", A)
        write(file, "M", M)
        write(file, "f", f)
        write(file, "t", timing)
    end
    return
end

using MAT
using JLD
using PyPlot
palm_unmix("Moffett_julia.mat","resultsPalm_nodM.jld",1)
print("OK")
@time palm_unmix("Moffett_julia.mat","resultsPalm_nodM.jld",1000) # 1000 iter: 22.161028 seconds (65.10 M allocations: 24.296 GB, 13.09% gc time)

# t = jldopen("resultsPalm_nodM.jld", "r") do file
#     read(file, "t")
# end
# f = jldopen("resultsPalm_nodM.jld", "r") do file
#     read(file, "f")
# end
#
# figure();
# semilogy(cumsum(t), f, color = "red", label = "Distributed (sync)", label = "serial")
# xlabel("t (s)")
# ylabel("f")
