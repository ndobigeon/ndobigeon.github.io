@everywhere function splxProj!(v, r::Float64)
    if r < 0
    error("Radius of simplex is negative: r = $(r)")
    end
    u     = sort(v, rev = true) # sort in descending order
    sv    = cumsum(u)
    rho   = findlast(u .> (sv - r)./(1:length(u)))
    theta = (sv[rho] - r) / rho
    v    .= max(v .- theta, 0.0)
end

# This function retuns the (irange,jrange) indexes assigned to this worker
@everywhere function myrange(q::SharedArray) # à ne générer qu'une seule fois ?
    idx = indexpids(q)
    if idx == 0
        # This worker is not assigned a piece
        return 1:0, 1:0
    end
    nchunks = length(procs(q))
    splits  = [round(Int, s) for s in linspace(0,size(q,2),nchunks+1)]
    splits[idx]+1:splits[idx+1]
    # 1:size(q,1), splits[idx]+1:splits[idx+1]
end

@everywhere function updateA_chunk!(Y::SharedArray{Float64,2}, M::Array{Float64,2}, A::SharedArray{Float64,2}, sigma::Float64, id_channel, myrange)
    r  = size(M,2)
    C  = zeros(r,r)
    D  = zeros(size(M))
    X = (M.')*M
    mu = vecnorm(X, 2)
    for n in myrange # (p, n) in myrange
        # Update A
        A[:,n] .-= (X*view(A,:,n) .- (M.')*view(Y,:,n))/mu
        splxProj!(view(A,:,n), 1.0)
        C .+= view(A,:,n)*(view(A,:,n))'
        D .-= view(Y, :, n)*(view(A,:,n).')
        # ccall((:simplexproj_Condat,"D:\\Test_julia\\SplxDll.dll"), Void, (Ref{Cdouble},Ref{Cdouble},UInt64,Ref{Cdouble},),A[:,n],y,R,r); # do in parallel voir Ref{A[:,n]}
        # see http://docs.julialang.org/en/release-0.4/manual/parallel-computing/
    end
    put!(id_channel, (C,D))
end
@everywhere updateA_shared_chunk!(Y, M, A, sigma, id_channel) = updateA_chunk!(Y, M, A, sigma, id_channel, myrange(A))

function updateM!(M::Array{Float64,2}, C::Array{Float64,2}, D::Array{Float64,2}, GGt::Array{Float64,2})
    mu  = vecnorm(C + GGt, 2)
    M .-= (M*C + D)/mu
    broadcast!(max, M, M, 0.)
end

function mdist_prior(R)
    G = zeros(R,R*R);
    el = zeros(R,1);
    for k = 0:R-1
        el[k+1] = 1.;
        G[:,1+k*R:(k+1)*R] = -eye(R) + el*ones(1,R);
        el[k+1] = 0.;
    end
    GGt = G*(G.')
    return GGt
end

function palm_unmix(dataType::String, InputFile::String, OutputFile::String, nIter::Int, sigma::Float64, mu::Float64, stop::Float64) # stop::Float64
    local M::Array{Float64,2}
    # local A::Array{Float64,2}
    # local Y::Array{Float64,2}
    # Load data
    if dataType == "jld"
        Y = jldopen(InputFile, "r") do file
            read(file, "Y")
        end
        M = jldopen(InputFile, "r") do file
            read(file, "M0")
        end
        A = jldopen(InputFile, "r") do file
            read(file, "A0")
        end
    else #.mat
        file         = matopen(InputFile)
        # varnames   = names(file) # unused ?
        M            = read(file,"M0")
        A            = read(file,"A0")
        Y            = read(file,"Y")
        close(file)
    end
    D                = zeros(size(M))
    (L,N)            = size(Y)
    R                = size(M,2)
    # Conversion step
    A                = convert(SharedArray, A)
    Y                = convert(SharedArray, Y)
    # Initialization
    f                = zeros(nIter+1)
    const id_channel = RemoteChannel(()->Channel{Tuple}(nworkers()))
    C                = Array(Float64, (size(M,2), size(M,2)))
    timing           = zeros(nIter+1)
    f[1]             = sum((Y .- M*A).^2)/2 # to be computed in parallel ?...
    c                = sum(Y.^2)
    crit             = Inf64
    q                = 1 # counter
    # Generate GGt for endmember mutual distance
    GGt = mdist_prior(R)
    GGt = mu*GGt
    # PALM
    # for q = 1:nIter
    while (crit > stop) && (q < nIter)
        tic()
        @sync begin
            for k in workers()
                @async remotecall_fetch(updateA_shared_chunk!, k, Y, M, A, sigma, id_channel) # bounds error
            end
        end
        # Update auxiliary variables
        C .= 0.0
        D .= 0.0
        for k in workers()
            Cw, Dw = take!(id_channel)
            C    .+= Cw
            D    .+= Dw
        end
        # Update M
        updateM!(M, C, D, GGt)
        # Compute objective function
        f[q+1]      = 0.5*(sum(M.*(M*(C + GGt))) + c) + sum(M.*D) # écrire avec dot
        timing[q+1] = toq()
        crit        = abs(f[q+1] - f[q])/f[q]
        q          += 1
    end

    if dataType == "jld"
        # Save results (JLD format)
        jldopen(OutputFile, "w") do file
            write(file, "A", A)
            write(file, "M", M)
            write(file, "f", f)
            write(file, "t", timing)
        end
    else #.mat
        A = sdata(A)
        file = matopen(OutputFile, "w")
        write(file, "M", M)
        write(file, "A", A)
        write(file, "f", f)
        write(file, "t", timing)
        close(file)
    end
    # finalize(id_channel)
    return
end
