# Dictionary update
function updateM!(M::Array{Float64,2}, C::Array{Float64,2}, D::Array{Float64,2}, GGt::Array{Float64,2}, gamma_k::Float64)
    mu = max(vecnorm(C + GGt,2), eps())
    M1 = M .- (M*(C + GGt) .+ D)/mu
    # M1 .= broadcast(./, M1, sqrt(sum(M1.^2,1)))
    broadcast!(max, M1, M1, 0.)
    M .+= gamma_k*(M1 .- M) # slight modification
end

function mdist_prior(R)
    G = zeros(R,R*R);
    el = zeros(R,1);
    for k = 0:R-1
        el[k+1] = 1.;
        G[:,1+k*R:(k+1)*R] = -eye(R) + el*ones(1,R);
        el[k+1] = 0.;
    end
    GGt = G*(G.')
    return GGt
end

function main_adpalm(dataType::String, filename::String, outputname::String, niter::Int, gamma_k::Float64, mu::Float64, penalty::Float64, stop::Float64)
    # Version similar to master_Cannelli, but with automatic block distribution
    T = nworkers()
    # Load data
    if dataType == "jld"
        Y = jldopen(filename, "r") do file
            read(file, "Y")
        end
        M = jldopen(filename, "r") do file
            read(file, "M0")
        end
        A = jldopen(filename, "r") do file
            read(file, "A0")
        end
    else #.mat
        file         = matopen(filename)
        # varnames   = names(file) # unused ?
        M            = read(file,"M0")
        A            = read(file,"A0")
        Y            = read(file,"Y")
        D            = zeros(size(M))
        close(file)
    end
    l,r                = size(M)
    n                  = size(Y,2)
    Y                  = convert(SharedArray,Y)
    A                  = convert(SharedArray,A)
    N                  = size(A,2)
    # Counters
    k                  = 0
    const id_channel   = RemoteChannel(()->Channel{Tuple}(T))
    # Generate GGt for endmember mutual distance
    GGt = mdist_prior(r)
    GGt = penalty*GGt
    # const id_channel = RemoteChannel(()->Channel{Tuple}(T))
    # Auxiliary variables
    C = @parallel (+) for t = 1:T
        view(A, :, blk_size(t+1,T,N))*(view(A, :, blk_size(t+1,T,N)).')
    end
    D = @parallel (+) for t = 1:T
        -view(Y, :, blk_size(t+1,T,N))*(view(A, :, blk_size(t+1,T,N)).')
    end
    c = @parallel (+) for t = 1:T
        sum(view(Y, :, blk_size(t+1,T,N)).^2)
    end
    # Initialize f / residue
    f                  = zeros(niter+1)
    timing_async       = zeros(niter+1)
    f[1]               = 0.5*(sum(M.*(M*(C + GGt))) + c) + sum(M.*D)
    id                 = 1 # définir type de X à l'avance ?
    # Driver (master process)
    tic()
    for t in 1:T # asynchronous version
        @async remotecall_fetch(updateA_chunk, t+1, Y, M, A, id_channel)
    end
    while true
        @sync begin # l'instruction break fait sortir du @sync
            id,X = take!(id_channel)  # worker index + value ("Blocks until data is available" d'après la doc) [prévoir une autre instruction non-bloquante ?]
            gamma_k = gamma_k*(1. - mu*gamma_k)
            # update A
            # update intermediary variables
            b_size = blk_size(id, T, N)
            C .-= view(A, :, b_size)*(view(A, :, b_size).') # remove old info
            D .+= view(Y, :, b_size)*(view(A, :, b_size).')
            A[:, b_size] .+= gamma_k*(X .- view(A, :, b_size))
            C .+= view(A, :, b_size)*(view(A, :, b_size).') # replace by new value
            D .-= view(Y, :, b_size)*(view(A, :, b_size).')
            updateM!(M,C,D,GGt,gamma_k)
            f[k+2] = 0.5*(sum(M.*(M*(C + GGt))) + c) + sum(M.*D)
            timing_async[k+2] = toq()
            # break condition
            crit = abs(f[k+1] - f[k+2])/f[k+1]
            k += 1
            ((crit <= stop) || (k >= niter)) && break
            # (k >= niter) && break
            tic()
            @async remotecall_fetch(updateA_chunk, id, Y, M, A, id_channel)
        end
    end
    # Save results
    if dataType == "jld"
        # Save results (JLD format)
        jldopen(outputname, "w") do file
            write(file, "A", A)
            write(file, "M", M)
            write(file, "f", f)
            write(file, "t", timing_async)
            write(file, "nIter", niter)
            write(file, "epsilon", stop)
        end
    else #.mat
        A = sdata(A)
        file = matopen(outputname, "w")
        write(file, "M", M)
        write(file, "A", A)
        write(file, "f", f)
        write(file, "t", timing_async)
        write(file, "nIter", niter)
        write(file, "epsilon", stop)
        close(file)
    end
    finalize(id_channel)
    # rmprocs(workers())
    return
end

using JLD
using MAT
addprocs(3)
include("src_async/worker_cannelliv3.jl")
# filename = "data.jld"
# T = 3
# niter = 1
# t = 1
# # test gamma_k -> ok !
# gamma_k = 1.
@time main_adpalm("mat", "data/data_async_R9.mat", "results/async_R9.mat", 3, 1., 1.e-6, 1e-3, 1.) # data.jld data_async_R9.
println("Function warmup and compilation.")
@time main_adpalm("mat", "data/data_async_R9.mat", "results/async_R9.mat", 3000, 1., 1.e-6, 1e-3, 1.e-5) # indiquer nombre max d'itérations
# version un peu plus lente que v2, mais pas de point étrange
println("End of the algorithm.") # % d'utilisation des processeurs assez faible sur mon PC...
# 167.305077 seconds (1.13 M allocations: 4.027 GB, 0.38% gc time) % 51 GB d'allocations pour 4000 iter : beaucoup trop !
# vérifier que l'ensemble des données est traité... (27% seulement d'activité des processeurs...)
# rmprocs(workers())
exit()

# using JLD
# asynctime = jldopen("results/real/async_houston.mat", "r") do file # async_v3_R9 rsJulia_async_cannelli3.jld
#     read(file, "t")
# end
# f = jldopen("results/real/async_houston.mat", "r") do file
#     read(file, "f")
# end
# #
# using PyPlot
# figure();
# semilogy(cumsum(asynctime),f, color = "blue", label = "Distributed (async)", label = "async")


# asynctime = matopen("async_R9.mat", "r") do file # async_v3_R9 rsJulia_async_cannelli3.jld
#     read(file, "t")
# end
# f = matopen("async_R9.mat", "r") do file
#     read(file, "f")
# end
# #
# using PyPlot
# figure();
# semilogy(cumsum(asynctime),f, color = "blue", label = "Distributed (async)", label = "async")
#
# M = matopen("async_rd100.mat", "r") do file
#     read(file, "M")
# end
# figure();
# plot(M)
