using PyPlot
using JLD

filenames = ["palm_sync_var_R32_stop.jld","async_var_v3_R3_stop.jld"] # "palm_sync_R9_stop.jld","async_v3_R9_stop.jld"
legends = ["distributed PALM (sync)", "distributed PALM (async v3)", "distributed PALM (async v2)"] # voir version série

for k = 1:length(filenames)
    f = jldopen(filenames[k], "r") do file
        read(file, "f") # alternatively, say "@write file A"
    end
    t = jldopen(filenames[k], "r") do file
        read(file, "t") # alternatively, say "@write file A"
    end
    semilogy(cumsum(t), f, label = legends[k])
    hold
end
legend()
xlabel("time (s)")
ylabel("Objective")
# savefig("ascpalm_vs_scpalm_index.png")
