@everywhere function splxProj!(v, r::Float64)
    if r < 0
    error("Radius of simplex is negative: r = $(r)")
    end
    u     = sort(v, rev = true) # sort in descending order
    sv    = cumsum(u)
    rho   = findlast(u .> (sv - r)./(1:length(u)))
    theta = (sv[rho] - r) / rho
    v    .= max(v .- theta, 0.0)
end

# This function retuns the (irange,jrange) indexes assigned to this worker
@everywhere function myrange(q::SharedArray) # à ne générer qu'une seule fois ?
    idx = indexpids(q)
    if idx == 0
        # This worker is not assigned a piece
        return 1:0, 1:0
    end
    nchunks = length(procs(q))
    splits  = [round(Int, s) for s in linspace(0,size(q,2),nchunks+1)]
    splits[idx]+1:splits[idx+1]
    # 1:size(q,1), splits[idx]+1:splits[idx+1]
end

# This function retuns the (irange,jrange) indexes assigned to this worker
@everywhere function blk_size(id::Int, nchunks::Int, N::Int) # à ne générer qu'une seule fois ?
    splits  = [round(Int, s) for s in linspace(0, N, nchunks+1)]
    splits[id-1]+1:splits[id]
    # 1:size(q,1), splits[idx]+1:splits[idx+1]
end

# Kernel
@everywhere function updateA(Y::SharedArray{Float64}, M::Array{Float64}, A::SharedArray{Float64}, myrange, id_channel)
    A1 = view(A, :, myrange)
    Y1 = view(Y, :, myrange)
    X = M.'*M
    mu = max(vecnorm(X,2), eps())
    A2 = A1 .- (X*A1 .- (M.')*Y1)/mu # (M.')*(M*A1 .- Y1)/mu;
    # A2 .= max(A2, 0.);
    for n = 1:size(A2,2)
        splxProj!(view(A2,:,n), 1.0) # vérifier si la proj est bien active
    end
    put!(id_channel, (myid(), A2))
    return
end

@everywhere updateA_chunk(Y, M, A, id_channel) = updateA(Y, M, A, myrange(A), id_channel)
