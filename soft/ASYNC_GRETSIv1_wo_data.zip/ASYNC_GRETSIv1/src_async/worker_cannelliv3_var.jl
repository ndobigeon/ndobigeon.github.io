@everywhere function splxProj!(v, r::Float64)
    if r < 0
    error("Radius of simplex is negative: r = $(r)")
    end
    u     = sort(v, rev = true) # sort in descending order
    sv    = cumsum(u)
    rho   = findlast(u .> (sv - r)./(1:length(u)))
    theta = (sv[rho] - r) / rho
    v    .= max(v .- theta, 0.0)
end

# This function retuns the (irange,jrange) indexes assigned to this worker
@everywhere function myrange(q::SharedArray) # à ne générer qu'une seule fois ?
    idx = indexpids(q)
    if idx == 0
        # This worker is not assigned a piece
        return 1:0, 1:0
    end
    nchunks = length(procs(q))
    splits  = [round(Int, s) for s in linspace(0,size(q,2),nchunks+1)]
    splits[idx]+1:splits[idx+1]
    # 1:size(q,1), splits[idx]+1:splits[idx+1]
end

# This function retuns the (irange,jrange) indexes assigned to this worker
@everywhere function blk_size(id::Int, nchunks::Int, N::Int) # à ne générer qu'une seule fois ?
    splits  = [round(Int, s) for s in linspace(0, N, nchunks+1)]
    splits[id-1]+1:splits[id]
    # 1:size(q,1), splits[idx]+1:splits[idx+1]
end

# Kernel
@everywhere function updateAdM_chunk(Y::SharedArray{Float64,2}, M::Array{Float64,2}, A::SharedArray{Float64,2}, dM::SharedArray{Float64,2}, sigma::Float64, id_channel, myrange)
    r   = size(M,2)
    Mn  = Array(Float64,size(M))
    A1  = zeros(r, length(myrange))
    dM1 = zeros(size(M,1), size(M,2)*size(A1,2))
    X   = zeros(r,r)
    c   = 0.0
    k   = 1
    # for n in myrange # (p, n) in myrange
    #     # Update A
    #     Mn .= M .+ view(dM, :, r*(n-1)+1:r*n)
    #     mu = vecnorm((Mn.')*Mn, 2)
    #     A1[:,k] .= view(A,:,n) .- (Mn.')*(Mn*view(A,:,n) .- view(Y,:,n))/mu
    #     splxProj!(view(A1,:,k), 1.0)
    #     # ccall((:simplexproj_Condat,"D:\\Test_julia\\SplxDll.dll"), Void, (Ref{Cdouble},Ref{Cdouble},UInt64,Ref{Cdouble},),A[:,n],y,R,r); # do in parallel voir Ref{A[:,n]}
    #     # see http://docs.julialang.org/en/release-0.4/manual/parallel-computing/
    #     # Update dM
    #     mu = vecnorm(view(A1,:,k)*(view(A1,:,k).'), 2)
    #     dM1[:, (k-1)*r+1:k*r] .= view(dM, :, r*(n-1)+1:r*n) .- (Mn*view(A1,:,k) .- view(Y,:,n))*(view(A1,:,k).')/mu
    #     # E .= max(E,-M)
    #     dM1[:, (k-1)*r+1:k*r] .= view(dM1,:, (k-1)*r+1:k*r)*min(1.0, sigma/vecnorm(view(dM1,:, (k-1)*r+1:k*r), 2))
    #     k += 1
    # end
    for n in myrange # autre parallélisation possible
        # Update A
        Mn .= M .+ view(dM, :, r*(n-1)+1:r*n)
        X .= (Mn.')*Mn
        mu = vecnorm(X, 2)
        A1[:,k] .= view(A,:,n) .- (X*view(A,:,n) .- (Mn.')*view(Y,:,n))/mu # ERROR # (Mn.')*(Mn*view(A,:,n) .- view(Y,:,n))/mu
        splxProj!(view(A1, :, k), 1.0)
        # ccall((:simplexproj_Condat,"D:\\Test_julia\\SplxDll.dll"), Void, (Ref{Cdouble},Ref{Cdouble},UInt64,Ref{Cdouble},),A[:,n],y,R,r); # do in parallel voir Ref{A[:,n]}
        # see http://docs.julialang.org/en/release-0.4/manual/parallel-computing/
        # Update dM
        X .= view(A1,:,k)*(view(A1,:,k).')
        mu = vecnorm(X, 2)
        dM1[:, (k-1)*r+1:k*r] .= view(dM, :, r*(n-1)+1:r*n) .- (Mn*X .- view(Y,:,n)*(view(A1,:,k).'))/mu
        # dM1[:, (k-1)*r+1:k*r] .= max(view(dM1, :, (k-1)*r+1:k*r), -M) # à voir...
        dM1[:, (k-1)*r+1:k*r] .= view(dM1, :, (k-1)*r+1:k*r)*min(1.0, sigma/vecnorm(view(dM1, :, (k-1)*r+1:k*r), 2))
        k += 1
    end
    put!(id_channel,(myid(), A1, dM1))
end

@everywhere updateAdM_shared_chunk(Y, M, A, dM, sigma, id_channel) = updateAdM_chunk(Y, M, A, dM, sigma, id_channel, myrange(A))
