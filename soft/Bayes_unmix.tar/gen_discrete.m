function x = gen_discrete(values,probas,N,M)

%------------------------------------------------------------------
% This function allows ones to sample a discrete variables
% 
% % INPUT
%         values     : values taken by x
%         probas     : corresponding probabilities
%         N,M        : dimension of the output
% 
%
% OUTPUT
%       x  :  generated variables
%
%------------------------------------------------------------------

if sum(probas)~=1.,
   probas = probas/sum(probas);
end;

probas = probas(:).';
L      = length(probas);
K      = N*M;
psup   = cumsum(probas);
pinf   = [0 psup(1:end-1)];
Pinf   = kron(ones(1,K),pinf(:));
Psup   = kron(ones(1,K),psup(:));

u = rand(1,K);
U = kron(ones(L,1),u);

C = (U>Pinf) & (U<Psup);

V = kron(values(:),ones(1,K));
X = V.*C;
x = sum(X);

x = reshape(x,N,M);

