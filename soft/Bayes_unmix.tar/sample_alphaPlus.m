function [alphaPlus_out conv]= sample_alphaPlus(alphaPlus,y,invT,MPlus,sigma2)

%------------------------------------------------------------------
% This function allows ones to sample the parameters alphaPlus
%       according to its posterior f(alphaPlus|...)
% 
% INPUT
%       alphaPlus       : the current state of alphaPlus
%       y               : pixel to be unmixed
%       invT            : a useful quantity
%       MPlus           : the endmember matrix
%       sigma2          : the current state of sigma2 parameter
%
% OUTPUT
%       alphaPlus_out   : the new state of the alphaPlus parameter
%       conv            : criterium
%
%------------------------------------------------------------------

R = size(MPlus,2);

M  = MPlus(:,1:(R-1));
mr = MPlus(:,R);
u = ones(R-1,1);

accept = 0;
compt = 0;

while accept == 0 && (compt < 3)
    MATCov = sigma2 * invT;

    Vmoy   = MATCov/sigma2 * (M-mr*u')'*(y-mr);
    
    alpha_cand = multrandn(Vmoy,MATCov,1);
    alphaPlus_cand = [alpha_cand' 1-sum(alpha_cand)]';
    
    if sum(alphaPlus_cand>=0)==R
        alphaPlus_out = alphaPlus_cand(:);
        accept = 1;
    else
        compt = compt+1;
        alphaPlus_out = alphaPlus;
    end
end
conv = accept;







