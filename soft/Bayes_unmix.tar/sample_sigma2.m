function sigma2_out = sample_sigma2(L,y,MPlus,R,alphaPlus)

%------------------------------------------------------------------
% This function allows ones to sample the parameter sigma_2
%       according to its posterior f(sigma_2|...)
% 
% INPUT
%       L               : number of spectral bands
%       y               : the pixel to be unmixed
%       MPlus           : the endmember matrix
%       alphaPlus       : the current state of alphaPlus
%       R               : the number of endmember
%
% OUTPUT
%       sigma2_out      : the new state of the sigma2 parameter
%
%------------------------------------------------------------------

x = gamrnd(L/2,inv((norm(y-MPlus(:,1:R)*alphaPlus)^2)/2),1,1);
sigma2_out = 1/x;
