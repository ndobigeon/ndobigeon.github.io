clc
clear all
close all

% loading: endmember spectrum library
load spectres.txt;
spectres = spectres-min(spectres(:));
[N_bandes N_spectres] = size(spectres);
N_spectres = N_spectres-1;
wavelength = spectres(:,1);

% loading: pixel to be unmixed
load signal_SNR=15dB.mat y MPlus

% Markov chain length
Nmc = 500;

% number of burn-in period
Nbi = 100;

% Unmixing procedure
tic
TalphaPlus = unmixing(y,MPlus,Nmc);
toc

% exploitation
result = exploitation(TalphaPlus,Nbi,Nmc);

