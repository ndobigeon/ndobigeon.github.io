This package contains programs written by N. DOBIGEON, J.-Y. TOURNERET, for the
implementation of the linear spectral unmixing presented in the following paper:

 N. Dobigeon, J.-Y. Tourneret, C.-I Chang "Semi-supervised linear spectral unmixing
	using a hierarchical Bayesian model for hyperspectral imagery"
	IEEE Trans. on Signal Processing, 2006.

The main function is "unmixing.m".
Edit this file to understand the structure of the procedure based on a hierarchical 
model and a Gibbs sampling strategy.
The programs are written in MALAB code.
You will find in "example_unmixing.m" a code which allows you 
to perform the linear spectral unmixing on a mixed pixel "signal_SNR=15dB.mat" used in the paper.

If you have any question, : nicolas.dobigeon@enseeiht.fr
