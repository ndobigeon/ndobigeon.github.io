function logPr = compute_posterior(r,gam,delta02,alpha,nu,xi,beta,p,y);

%------------------------------------------------------------------
% This function compute the probability (up to a normalization)
%       of having the MC state R according to the posterior 
%       of interest
% 
% INPUT
%       r       : the MC state for the matrix R
%       gam     : gam parameter
%       delta02 : gam parameter
%       nu      : nu parameter
%       alpha   : alpha parameter
%       xi      : nu parameter
%       beta    : nu parameter
%       p       : model order (fixed)
%       y       : the signal to be segmented
%
% OUTPUT
%       logPr : the log of the probability
%
%------------------------------------------------------------------



global J N Tepsilon

for j=1:2^J
    tmp = r(:,1:N-1)-Tepsilon(:,j)*ones(1,N-1);
    S(j) = length(find(sum(abs(tmp),1)==0));
end
        
% number of ruptures in each sequence
K = sum(r,2);
Kmax = max(K);

% length of each segment in each sequence
n = zeros(J,Kmax);
rtraf=[ones(J,1) r];
for j=1:J
    n(j,1:K(j)) = diff(find(rtraf(j,:)==1));
end

% looking for the ruptures...
InstantRupt = zeros(J,Kmax+1);
for j=1:J
    InstantRupt(j,1:K(j)+1) = [0 find(r(j,:)==1)];
end

% initialisation des tableaux utiles
T2 = zeros(J,Kmax);
det_M= zeros(j,Kmax);

% computation of M_jk et T_jk
for j=1:J
    K_j = K(j);
        for k = 1:K_j
            [T2(j,k) det_M(j,k)] = compute_TM(InstantRupt(j,k),InstantRupt(j,k+1),p,delta02,y(j,:));
        end;
end
logPr =log(1/gam);

%computation
logPr = logPr + sum(gammaln(S+alpha));

logPr = logPr + xi*log(beta)-gammaln(xi)-(p*sum(K)/2)*log(delta02);
for j=1:J
    for k=1:K(j)
        logPr = logPr + (nu/2)*log(gam) + gammaln(n(j,k)/2+nu/2)-(n(j,k)/2+nu/2)*log(gam+T2(j,k))+1/2*log(det_M(j,k));
    end
end
