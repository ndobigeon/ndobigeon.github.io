function [ T2_jk det_M_jk  C_jk v_jk] = calcul_TM(InstantRupt_jk1,InstantRupt_jk2,p_jk,delta02,y_j)

%------------------------------------------------------------------
% Compute the quantities T2, M and cholesky factor C for a segment
% 
% INPUT
%       InstantRupt_jk1 : index for the beginning of the segment
%       InstantRupt_jk2 : index for the end of the segment
%       p_jk            : the order of the AR
%       delta02         : delta02 parameters
%       y_j             : the sequence to be segmented
%
% OUTPUT
%       S : the sums
%
%------------------------------------------------------------------

global J N pmax Tepsilon

l_jk1 = InstantRupt_jk1 + p_jk;
l_jk2 = InstantRupt_jk2 + p_jk;
y_jk = y_j(l_jk1+1:l_jk2)';

Y_jk = [];
for col = (0:p_jk-1)
    ind1 = l_jk1-col;
    ind2 = l_jk2-col-1;
    Y_jk = [Y_jk y_j(ind1:ind2)'];
end

InvM_jk = Y_jk'*Y_jk+eye(p_jk)/delta02;

% Cholesky's factor
C_jk = chol(InvM_jk)';
u = Y_jk'*y_jk;
v_jk = C_jk\u;

% output
T2_jk = y_jk'*y_jk-v_jk'*v_jk;
det_M_jk = prod(diag(C_jk))^(-2);
