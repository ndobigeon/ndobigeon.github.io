function r_out = echantillonner_r(r,p,gam,delta02,alpha,nu,xi,beta,y,step);

%------------------------------------------------------------------
% This function allows to sample the indicator matrix R
%       according to f(r|gam,delta02,alpha,nu,xi,beta,y)
% 
% INPUT
%       r       : the current state of the matrix R
%       gam     : the current state of the gam parameter
%       delta02 : the current state of the gam parameter
%       alpha   : alpha parameter
%       nu      : nu parameter
%       xi      : xi parameter
%       beta    : nu parameter
%       y       : the signal to be segmented
%       step    : step sampling
%
% OUTPUT
%       r_out : the new state of the matrix R
%
%------------------------------------------------------------------

global J N Tepsilon

valeurs = 1:2^J;
probas = zeros(1,2^J);

r_out = r;

for i=randperm(floor((N-1)/step))*step;
    
    % computation of the 2^J probabilities P(r_i = epsilon|...)
    for j=1:2^J
        r_out(:,i)=Tepsilon(:,j);
        Pr(j)=compute_posterior(r_out,gam,delta02,alpha,nu,xi,beta,p,y);
    end
    
    % strategy to avoid overfloat
    Prmax = max(Pr);
    probas=exp(Pr-Prmax);
    probas = probas/sum(probas);
    
    % the new state is drawed according the 2^J probabilities
    x = gen_discrete(valeurs,probas,1,1);
    r_out(:,i)=Tepsilon(:,x);
    
end