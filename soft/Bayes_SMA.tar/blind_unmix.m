function [Tab_A Tab_T Tab_sigma2 matU Y_bar Nmc] = blind_unmix(Y,R,P,Nmc,geo_method,Tsigma2r,bool_plot)

Y = Y';

% dimension of space of interest
L_red = (R-1);

% (crude) geometrical estimation
disp('GEOMETRICAL ENDMEMBER EXTRACTION')
[endm matP matU Y_bar endm_proj y_proj] = find_endm(Y,R,geo_method);
endm = abs(endm);

% projected endmembers
endm_proj = matP*(endm -Y_bar*ones(1,R));

% MC initialization
M_est = endm;
T_est = matP*(M_est-Y_bar*ones(1,R));
A_est = abs(pinv(M_est)*Y);
A_est = A_est./(sum(A_est,1)'*ones(1,R))';

% MC chains
Tab_A = zeros(Nmc,R,P);
Tab_T = zeros(Nmc,L_red,R);
Tab_sigma2 = zeros(Nmc,1);

% plot
if bool_plot
    figure(1)
    plot(M_est)
    title(['Estimated endmembers via ' geo_method])
    drawnow
    disp('--> Press any key to continue')
    pause
end

% MCMC algorithm
waitbar_flag = waitbar(0,'Push cancel button to stop Monte Carlo iterations','Name','Bayesian linear unmixing','CreateCancelBtn','waitbar_stop');
global run_simulation, run_simulation = 1;
m_compt = 1;
disp('MONTE CARLO ITERATIONS')
while m_compt<Nmc && run_simulation
    waitbar(m_compt/Nmc,waitbar_flag)

    
    % sampling noise variance
    sigma2_est = sample_sigma2(A_est,M_est,Y);
    
    % sampling abundance vectors
    A_est = sample_A(Y',M_est',A_est',R,P,sigma2_est)';


    % sampling endmember projections
    [T_est M_est] = sample_T_const(A_est,M_est,T_est,sigma2_est,Tsigma2r,matU,Y_bar,Y,endm_proj,bool_plot,y_proj);  
    
    % saving the MC chains 
    Tab_A(m_compt,:,:) = A_est;
    Tab_T(m_compt,:,:) = T_est;
    Tab_sigma2(m_compt,:) = sigma2_est;  
      
    % plot
    if bool_plot
        % estimated endmembers
        figure(1)
        plot(M_est)
        title('Estimated endmembers')
        drawnow
        
        % estimated projected endmembers
        figure(2)            
        scatter(y_proj(1,:),y_proj(2,:),'k.')
        hold on
        for r=1:R
            scatter(endm_proj(1,r),endm_proj(2,r),'bo');
            scatter(T_est(1,r),T_est(2,r),'g*');           
        end
        hold off
        legend('Pixels','Est. Endm. (geo)','Current Est. Endm.')
        title('Scatter plot in 2 spectral bands')
        drawnow
                                
    end
    
    m_compt = m_compt + 1;
    
end
close;

if run_simulation; delete(waitbar_flag); end
Nmc = m_compt;
disp('END')