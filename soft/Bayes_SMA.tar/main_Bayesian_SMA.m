clear all
close all
clc

%%% LOADING DATA
load spectres.txt

wave = spectres(:,1);
spectra = spectres(:,2:end);
clear spectres

pas = 2;
MATSpec = spectra(1:pas:end,[1 2 5])';
wave = wave(1:pas:end);

load  image_hyper_synth_R=3_16x16_structur_bruit_SNR=25dB.mat
M_true = MATSpec';
A_true = MATAbond';

clear MATAbond MATSpec

%%% BAYESIAN LINEAR UNMIXING
R = 3;
[P L] = size(Y);

% maximum iteration number
Nmc = 100;

% boolean for figures : 1 = plot / else = no plot
bool_plot = 1;

% initialization method
Tgeo_method = {'nfindr' 'vca'};
geo_method = Tgeo_method{1};
Tsigma2r = ones(R,1)*1e1;

% Bayesian linear unmixing
[Tab_A Tab_T Tab_sigma2 matU Y_bar Nmc] = blind_unmix(Y,R,P,Nmc,geo_method,Tsigma2r,bool_plot);


% COMPUTATION of MMSE ESTIMATES
Nbi = floor(Nmc/3);
A_MMSE = reshape(mean(Tab_A((Nbi+1):Nmc,:,:),1),R,P);
T_MMSE = reshape(mean(Tab_T((Nbi+1):Nmc,:,:),1),R-1,R);
M_est = matU*T_MMSE+Y_bar*ones(1,R);

%%% PLOT    
figure(1)
plot(wave,M_est)
hold on
plot(wave,M_true,':')
hold off
drawnow
title('MMSE estimates of the endmembers')