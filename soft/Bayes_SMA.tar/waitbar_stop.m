function  waitbar_stop

global run_simulation
run_simulation = 0;
delete(gcf);



