function [endm matP matU Y_bar endm_proj y_proj] = find_endm(Y,R,method)

L_red = R-1;
P = size(Y,2);
       
% PCA
disp('--> Begin - Principal Component analysis')
% [vect_prop y_red val_prop] = princomp(y);
Rmat = Y-(mean(Y,2)*ones(1,P));
Rmat = Rmat*Rmat';

[vect_prop, D] = eigs(Rmat,L_red) ;
D = eye(L_red);
vect_prop = vect_prop';
disp('--> End - Principal Component analysis')

% first L_red eigenvectors
V = vect_prop(1:L_red,:);

% first L_red  eigenvalues
V_inv = pinv(V);
Y_bar = mean(Y,2);

% projector
matP =  D^(-1/2)*V;

% inverse projector
matU = V_inv*D^(1/2);

% projecting
y_proj = matP*(Y -Y_bar*ones(1,P));

switch method
    case 'nfindr'

        % NFINDR
        disp('--> Begin - N-FINDR')
        Nb_iter = 5000;
        [endm_proj] = nfindr(y_proj',Nb_iter);
        disp('--> End - N-FINDR')
          
        % in hyperspectral space
        endm = matU*endm_proj+Y_bar*ones(1,R);
        

    case 'vca'
        
        % VCA
        disp('--> Begin - VCA')
        [endm] = vca(Y,'Endmembers',R,'verbose','off');
        disp('--> End - VCA')
        % in projected space
        endm_proj = matP*(endm -Y_bar*ones(1,R));
        
end
        
            


