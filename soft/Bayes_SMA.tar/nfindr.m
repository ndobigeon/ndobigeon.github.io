function [endm] = nfindr(y_proj,Niter)

% nfindr cod� avec recuit simul�

% size(y_red) = Nb_pix x Nb_bandes
[Nb_pix Nb_bandes] = size(y_proj);

Nb_endm = Nb_bandes+1;
 
%enveloppe QHULL
disp('  % convex hull')
ind = convhulln(y_proj);
envlp = y_proj(ind,:);
[Nb_sommet Nb_bandes] = size(envlp); 
disp(['  % Number of points defining the convex hull: ' int2str(Nb_sommet)])
% INITIALISATION
% choix de Nb_endm pixels
ind_perm = randperm(Nb_sommet);
combi = sort(ind_perm(1:Nb_endm));

% cacul du crit�re
candidat_n = envlp(combi,1:Nb_bandes)';
critere_n = -abs(det([candidat_n;ones(1,Nb_endm)]));
candidat_opt = candidat_n;
critere_opt = critere_n;

h = waitbar(0,['N-FINDR...'],'CreateCancelBtn','closereq', 'name', 'N-FINDR');
% n+1
for iter=1:Niter
    waitbar(iter/Niter,h)
    % candidat
    ind_perm = randperm(Nb_sommet);
    combi = sort(ind_perm(1:Nb_endm));
    candidat = envlp(combi,1:Nb_bandes)';
    critere = -abs(det([candidat;ones(1,Nb_endm)]));
    
    %test
    delta_critere = critere-critere_n;
    if delta_critere<0
        critere_n = critere;
        if critere < critere_opt
            critere_opt = critere;
            candidat_opt = candidat;
        end
    end
end
close(h)
endm = candidat_opt;


