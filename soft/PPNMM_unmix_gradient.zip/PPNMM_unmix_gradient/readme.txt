This package contains programs written by Y. ALTMANN, A. HALIMI, 
N. DOBIGEON and J.-Y. TOURNERET , for the implementation of the 
nonlinear spectral unmixing presented in the following paper:

Y. Altmann, A. Halimi, N. Dobigeon and J.-Y. Tourneret, 
"Supervised nonlinear spectral unmixing using a post-nonlinear 
mixing model for hyperspectral imagery," 
	IEEE Trans. on Image Processing, 2012.

The main function is "unmixing.m".
Edit this file to understand the structure of the procedure 
based on a gradient descent method.
The programs are written in MALAB code.
You will find in "example_unmixing.m" a code which allows you 
to perform the linear spectral unmixing on a synthetic mixed pixel 
"signal_SNR=15dB.mat".

If you have any question, : yoann.altmann@enseeiht.fr
