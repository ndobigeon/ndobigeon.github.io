clear all
close all
clc

% loading: pixel to be unmixed
load signal_SNR=15dB.mat

% Unmixing procedure
tic
[alpha,b] = unmixing(y,MPlus)
toc