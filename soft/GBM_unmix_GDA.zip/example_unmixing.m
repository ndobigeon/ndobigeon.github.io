clc
clear all
close all


% loading: endmember matrix (R=3 components)
load endmembers.mat MPlus


alpha0=[0.3 0.6 0.1]'; % Actual abundance vector
gamma0=[0.5 0.1 0.3]'; % Actual gamma vector
sigma20= 3*10^-4; % Actual noise variance  

% Mixed pixel
y= gene_Gamma(MPlus,[alpha0 ;gamma0])+ sqrt(sigma20)*randn(size(MPlus,1),1) ;

% Unmixing procedure
tic
[alpha gam]=GBM_gradient(y,MPlus);
toc

alpha0
alpha
gamma0
gam

