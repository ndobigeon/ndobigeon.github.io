function val=golden_section( theta0,df,MPlus,y,lb,ub)
%------------------------------------------------------------------
% This function allows ones to determine the optimal constrained line 
% search parameter using the golden section method.
% 
% 
% INPUT
%       theta0          : current point estimate
%       df              : current derivative vector
%       MPlus           : the endmember matrix
%       y               : observation vector to be unmixed
%       lb              : lower bound of the line search parameter
%       ub              : upper bound of the line search parameter
%
% OUTPUT
%       val             : optimal value of the line search parameter
%
%------------------------------------------------------------------

[L R]=size(MPlus);
l=10^(-6);
alpha=0.618;
b(1)=ub;a(1)=lb;
lambda(1) = lb+(1-alpha)*(ub-lb);
mu(1) = lb+alpha*(ub-lb);

al(1:R-1)=theta0(1:R-1)-lambda(1)*df(1:R-1)';
al(R)=1-sum(al(1:R-1));
for r=R+1:R*(R+1)/2
al(r)=theta0(r)-lambda(1)*df(r-1);
end
err_lambda = norm(y-gene_Gamma(MPlus,al'))^2 ;


al(1:R-1)=theta0(1:R-1)-mu(1)*df(1:R-1)';
al(R)=1-sum(al(1:R-1));
for r=R+1:R*(R+1)/2
al(r)=theta0(r)-mu(1)*df(r-1);
end
err_mu = norm(y-gene_Gamma(MPlus,al'))^2 ;

k=1;f=0;
while((b(k)-a(k)) > l)
    
if(err_lambda>err_mu & f==0)
    a(k+1)=lambda(k);
    b(k+1)=b(k);
    lambda(k+1)=mu(k); 
    mu(k+1)= a(k+1)+alpha*(b(k+1)-a(k+1));
    
    al(1:R-1)=theta0(1:R-1)-mu(k+1)*df(1:R-1)'; 
    al(R)=1-sum(al(1:R-1));
    for r=R+1:R*(R+1)/2
    al(r)=theta0(r)-mu(k+1)*df(r-1);
    end

    err_lambda=err_mu;
    err_mu = norm(y-gene_Gamma(MPlus,al'))^2;
    f=1;
    
elseif(err_lambda <= err_mu & f==0)
    a(k+1)=a(k);
    b(k+1)=mu(k);
    mu(k+1)=lambda(k); 
    lambda(k+1)= a(k+1)+(1-alpha)*(b(k+1)-a(k+1));
    
    al(1:R-1)=theta0(1:R-1)-lambda(k+1)*df(1:R-1)'; 
    al(R)=1-sum(al(1:R-1));
    for r=R+1:R*(R+1)/2
    al(r)=theta0(r)-lambda(k+1)*df(r-1);
    end
    
    err_mu=err_lambda;
    err_lambda = norm(y-gene_Gamma(MPlus,al'))^2;
    f=1;
end

k=k+1;f=0;

end

val = a(k)+(b(k)-a(k))/2;