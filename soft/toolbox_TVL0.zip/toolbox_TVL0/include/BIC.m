function [ crit ] = BIC( y,x )

(2*pi*sigma^2)^N*exp(

% Param & functions
tol     = 10^5;
dec.T   = @(x) transformTau_TV(x,1);

% Variables
span    = max(y)-min(y);
N       = length(y);
indr    = find(abs(dec.T(x))>span/tol);
nk      = diff([0 indr N]);
Kr      = length(indr);
Sk      = sum((x-mean(y)).^2);
S0      = sum((y-mean(y)).^2);
Skdiff  = S0-Sk;


crit    = (N-Kr+1)/2 * log(1+Sk/Skdiff) + gammaln((N-Kr+1)/2) - gammaln((N+1)/2) + Kr/2*log(S0) - (1/2)*sum(log(nk)) + (1/2-Kr)*log(N);

end

