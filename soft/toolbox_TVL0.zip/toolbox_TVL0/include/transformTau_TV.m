function GxGy = transformTau_TV(x,tau)


[n,m]=size(x);
GxGy = [x(:,(1+tau):m)/2-x(:,1:m-tau)/2,zeros(n,tau)];
