function [ index ] = JaccardIndexGaussianKernel( ry, rx, winGauss, sigmaGauss )
% FUNCTION [ index ] = JaccardIndexGaussianKernel( ry, rx, winGauss, sigmaGauss )
%
% INPUT ry & rx: indicator vectors (0 or 1) of same size
%
% INPUT winGauss, sigmaGauss: define a Gaussian kernel G = fspecial('gaussian',[1 winGauss],sigmaGauss)
%
% OUTPUT index: Weighted Jaccard index between G*rx and G*ry where '*' denotes the convolution product.
%
% For more information, see
% J. Frecon, N. Pustelnik, P. Abry, and L. Condat, On-the-fly Approximation of Multivariate Total Variation Minimization, Submitted, 2015.
%
% J. Frecon
% Version: 04-November-2015

G           = fspecial('gaussian',[1 winGauss],sigmaGauss);
rx          = conv(rx,G,'same');
ry          = conv(ry,G,'same');


indx        = find(rx ~= 0);
indy        = find(ry ~= 0);
shared      = intersect(indx,indy);

vec         = [rx(shared)' , ry(shared)'];

shared_min  = sum(min(vec,[],2));
shared_mean = sum(mean(vec,2));


notshared_y = sum(ry(find(rx==0)));
notshared_x = sum(rx(find(ry==0)));

index       = shared_min / (shared_mean + notshared_y + notshared_x);

end

