function [ indJacc ] = JaccardIndexGaussianKernel_vsignal( Y, X, winJacc, sigmaJacc, EPS )

if nargin == 4
    EPS = eps;
end

N  = length(Y);

ry = zeros(1,N-1);
rx = zeros(1,N-1);

ry(abs(diff(Y))>EPS) = 1;
rx(abs(diff(X))>EPS) = 1;

indJacc     = JaccardIndexGaussianKernel( ry, rx, winJacc, sigmaJacc );



end

