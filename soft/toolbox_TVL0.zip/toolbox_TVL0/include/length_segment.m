function nk = length_segment(x )
% function [ crit ] = BICmod( y,x )
%
% Modified Bayes Information Criterion with application to piecewise
% constant denoising.
%
% Input:    - 'y': Observation
%           - 'x': Candidate solution
%
% Output:   -'crit': modified BIC
%
% Reference: "A modified Bayes information criterion with application to
% the analysis of comparative genomic hybridization data", N.R. Zhang and
% D.0. Siegmund.
%
% Version: 09/09/2016. J.Frecon




% Param & functions
tol     = 10^5;
dec.T   = @(x) transformTau_TV(x,1);

% Variables
span    = max(x)-min(x);
N       = length(x);
indr    = find(abs(dec.T(x))>span/tol);
nk      = diff([0 indr N]);


