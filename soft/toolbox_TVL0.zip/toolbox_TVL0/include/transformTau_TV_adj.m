function x = transformTau_TV_adj(y,tau)

[n,m] = size(y);
% size(y(:,1:tau))
% size(y(:,1+tau:m-tau))
% size(y(:,1:m-2*tau))
% size(y(:,m-2*tau+1:m-tau))

x = -([y(:,1:tau)/2,y(:,1+tau:m-tau)/2- y(:,1:m-2*tau)/2,-y(:,m-2*tau+1:m-tau)/2]);