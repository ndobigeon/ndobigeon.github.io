function [u,rp,mup,indp,crit] = minL2Potts_vJF(f, gamma, weights)
%MINL2POTTS Minimizes the classical L^2-Potts problem
%
%Description
% Computes an exact minimizer of the L^2-Potts functional
%
%  \gamma \| D u \|_0 + \| u - f \|_2^2
%
% in O(n^2) time.
%
%Reference:
% F. Friedrich, A. Kempe, V. Liebscher, G. Winkler,
% Complexity penalized M-estimation: Fast computation
% Journal of Computational and Graphical Statistics, 2008
%
% See also: minL2iPotts, minL1Potts, minL1iPotts

% written by M. Storath
% $Date: 2013-10-04 13:43:18 +0200 (Fr, 04 Okt 2013) $	$Revision: 80 $


% ADD (JF, 18-04-16)
if size(f,1) ~= 1
    f = f';
end



% weighted and vector valued version exists only in Java
if ~exist('weights', 'var')
    weights = ones(size(f));
end

siz = size(f);

complexData = ~isreal(f);
% convert complex data to vector
if complexData
    f = [real(f(:)), imag(f(:))];
end

u = pottslab.JavaTools.minL2Potts( f, gamma, weights);

% convert from vector to complex
if complexData
    u = u(:,1) + 1i * u(:,2);
end

% reshape u to size of f
u = reshape(u, siz);

%--------------------------------------------------------------------------
%%show the result, if requested
if nargout == 0
    plot(f, '.', 'MarkerSize', 10);
    hold on
    stairs(u, 'r', 'LineWidth', 2);
    hold off
    legend({'Signal', 'L^2-Potts estimate'});
    grid on;
end



% ADD (JF, 18-04-16)
dec.T       = @(x) transformTau_TV(x,1);
span = max(f)-min(f);
tol  = 10^5;
rp = zeros(1,length(f)-1);
rp(abs(diff(u))>span/tol) = 1;
ind_rp          = find(abs(dec.T(u))>span/tol);
rp              = zeros(1,length(f));
rp(ind_rp)      = 1;
rp(end)          = 1;
ind_rp          = [ind_rp,length(f)];
ind0=1;
j=1;
while j<=length(ind_rp)
    j1 = ind0;
    j2 = ind_rp(j);
    mup(j) = mean( u(j1:j2));
    indp{j} = [j1:j2];
    ind0 = j2 + 1;
    j = j+1;
end


crit = 1/2*norm(u - f)^2 + gamma*length(find(abs(dec.T(u))>span/tol)); %Facteur span rajout� ! (09-Feb.-16)


end
