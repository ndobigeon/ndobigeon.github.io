close all hidden;
clear all;
clc;