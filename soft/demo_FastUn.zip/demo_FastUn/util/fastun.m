function [X]= fastun(Y,A,lambda2,lambda1,m,n,slicsize,slicreg)
%------------------------------------------------------------------
% FAST HYPERSPECTRAL UNMIXING USING A MULTISCALE SPARSE REGULARIZATION (FastUn)

% by T. INCE and N. DOBIGEON, IRIT/ENSEEIHT/TéSA - France - 202111
% 
% INPUT
%       Y        : L x N pixels to be unmixed where L is the number 
%                  of spectral band
%       A        : L x M spectral library 
%       [m,n]    : Spatial size of hyperspectral data
%       lambda1  : Regularization parameter for coarse approximation 
%       lambda2  : Regularization parameter for fine approximation
%       slicsize : SLIC superpixel size 
%       slicreg  : SLIC regularization parameter
%
% OUTPUT
%       X    : Estimated abundance matrix
%------------------------------------------------------------------

[L, K] = size(Y);
M = size(A,2);

img = ApplyPca(reshape(Y',m,n,L),3);
[numRows,numCols,numSpectra] = size(img);
scfact = mean(reshape(sqrt(sum(img.^2,3)),numRows*numCols,1));
img = img./scfact;
labels = vl_slic(single(img),slicsize,slicreg);    
numSuperpixels = double(max(labels(:)))+1;

temp = zeros(L,numSuperpixels);
for g=1:numSuperpixels
    indices = find(labels == (g-1));
    temp(:,g) = mean(Y(:,indices),2);    
end
X_hat = wsunsal(A,temp,'lambda',lambda1,'ADDONE','no','POSITIVITY','yes','TOL',1e-4, 'AL_iters',2000,'verbose','no');

X_low = zeros(M,K);
for g=1:numSuperpixels
    indices = find(labels == (g-1));
    X_low(:,indices) = repmat(X_hat(:,g),1,length(indices));
end

w2=(repmat(1./(sqrt(sum((X_low).^2,2))+1e-5),1,K));
X = w2sunsal(A,Y,w2,X_low,'lambda',lambda2,'ADDONE','no','POSITIVITY','yes','TOL',1e-4, 'AL_iters',2000,'verbose','no');
