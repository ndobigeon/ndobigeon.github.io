clc,clear all,close all
addpath(genpath('util'));
load dc2.mat

SNR = 20; % You can change SNR level for 20,30 and 40

rand('state',10);
randn('state',10);
[p,np] = size(X);
m = 100;
n = 100;
%%
load USGS_1995_Library.mat
[dummy index] = sort(datalib(:,1));
AA =  datalib(index,4:end);
min_angle = 4.44;       
[A, index] = prune_library2(AA,min_angle); % 240  signature 
[A, index, angles] = sort_library_by_angle(A);
%% select p endmembers  from A
supp = [1:p]; 
M = A(:,supp);
[L,p] = size(M);
%%
Psignal = sum(sum((M*X).^2))/numel(M*X);
Pnoise = Psignal*(10^(-SNR/10));
sigma = sqrt(Pnoise);
noise  = sigma*randn(L,np);
%%
Y = M*X + noise;
m1 = size(A,2);
N = m*n;
XT = zeros(m1,np);
XT(supp,:) = X;
nl = m;
nc = n;
%% Parameters for FastUn
if SNR == 20
    lambda1 = 5e-3;
    lambda2 = 0.25;
    slicsize = 7;
    slicreg = 0.01;
elseif SNR == 30
    lambda1 = 5e-3;
    lambda2 = 0.01;
    slicsize = 6;
    slicreg = 0.01;
elseif SNR == 40
    lambda1 = 5e-4;
    lambda2 = 0.004;
    slicsize = 6;
    slicreg = 0.01;
end
%%
tic;
Xfastun = fastun(Y,A,lambda2,lambda1,m,n,slicsize,slicreg);
tfastun = toc;
SRE_fastun = 20*log10(norm(XT,'fro')/norm(Xfastun-XT,'fro'));
RMSE_fastun= sqrt(mean((Xfastun(:) - XT(:)).^2));
ps_fastun = numel(find(Xfastun>5e-3))/(m1*N);
%%
img_orig = reshape(X',m,n,p);
img_fastun = reshape(Xfastun',m,n,m1);
close all
figure
for i=1:p
    subplot(2,9,i),imagesc(img_orig(:,:,i)),colormap(jet),axis image;
    subplot(2,9,i+p),imagesc(img_fastun(:,:,i)),colormap(jet),axis image;
end

fprintf('SRE = %f\nComputation time = %f seconds\n',SRE_fastun, tfastun)
