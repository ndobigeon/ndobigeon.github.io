This set of files contains Matlab demos for the FastUn algorithm introduced in the paper
"Fast hyperspectral unmixing using a multiscale sparse regularization" 
Submitted to IEEE Geoscience and Remote Sensing Letters.

Files:
demo_sd1.m   - demo for SD1
demo_sd2.m   - demo for SD2

Please add the folder "util" to include necessary files to run FastUn 

!! Important

Please download and install vlfeat-0.9.21 based on your operating system and after installation, save the MATLAB path.

Then all demos will work without any error.

