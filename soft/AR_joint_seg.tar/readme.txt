This package contains programs written by N. DOBIGEON, J.-Y. TOURNERET and M. DAVY, for the
implementation of the joint segmentation of AR processes described in the article:

 N. Dobigeon, J.-Y. Tourneret, J.D. Scargle "Joint Segmentation of Piecewise
	Constant Autoregressive Processes by using a Hierarchical Model and a
	Baysesian Sampling Approach"
	IEEE Trans. on Signal Processing, 2006.

The main function is "segmentation.m".
Edit this file to understand the structure of the procedure based on a hierarchical model
and a Gibbs sampling strategy.
The programs are written in MALAB code.
You will find in "example_segmentation.m" a code which allows you 
to perform the segmentation on the 2-D synthetic signal "signal.mat" used in the paper.

If you have any question, : nicolas.dobigeon@enseeiht.fr
