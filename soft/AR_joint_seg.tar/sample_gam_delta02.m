function [gam_out delta02_out, a,sigma2] = echantillonner_gam_delta02(r,p,gam,delta02,nu,xi,y);

%------------------------------------------------------------------
% This function allows to sample the parameters gam and delta02
%       according to f(gam,delta02|r,p,nu,xi,y)
% 
% INPUT
%       r       : the current state of the matrix R
%       p       : order of the AR's
%       gam     : the current state of the gam parameter
%       delta02 : the current state of the delta02 parameter
%       nu      : nu parameter
%       xi      : xi parameter
%       y       : the signal to be segmented
%
% OUTPUT
%       gam_out     : the new state of the gam parameter
%       delta02_out : the new state of the gam delta02
%
%------------------------------------------------------------------


global J N Tepsilon

% number of ruptures in each sequence
K = sum(r,2);
Kmax = max(K);

% length of the segments in each sequence
n = zeros(J,Kmax);
rtraf=[ones(J,1) r];
for j=1:J
    n(j,1:K(j)) = diff(find(rtraf(j,:)==1));
end

% looking for the ruptures
InstantRupt = zeros(J,Kmax+1);
for j=1:J
    InstantRupt(j,1:K(j)+1) = [0 find(r(j,:)==1)];
end

sigma2 = zeros(J,Kmax);
a = zeros(J,Kmax,p);
terme_delta02 = 0;
terme_gam = 0;
Tab_C_jk={};
Tab_v_jk={};
% GENERATION OF sigma2 ACCORDING TO f(sigma2\...)

% for each signal
for j=1:J
    K_j = K(j);
    
    % for each segment
        for k = 1:K_j
            
            [T2_jk det_M_jk C_jk v_jk] = compute_TM(InstantRupt(j,k),InstantRupt(j,k+1),p,delta02,y(j,:));
            
            Tab_C_jk{j,k} = C_jk;
            Tab_v_jk{j,k} = v_jk;
            x = gen_gamma((n(j,k)+nu)/2,(gam+T2_jk)/2);
            sigma2(j,k) = 1/x;

            % useful quantity for generation of gam
            terme_gam = terme_gam + 1/sigma2(j,k);
        end
end

% GENERATION OF (GAM,SIGMA2) SUIVANT f(gamma|...)
gam_out = gen_gamma(sum(K)*nu/2,terme_gam/2);


% GENERATION OF A ACCORDING TO f(a\...)

% for each signal
for j=1:J
    K_j = K(j);
    
    % for each segment
        for k = 1:K_j
            C_jk = Tab_C_jk{j,k};
            v_jk = Tab_v_jk{j,k};
            
            w = sqrt(sigma2(j,k))*randn(p,1);
            mu1 = C_jk\w;
            mu2 = v_jk;
            mu3 = C_jk'\mu2;
            a_jk = mu1+mu3;
            a(j,k,1:p) = a_jk;
            
            % useful quantity for generation of delta02
            terme_delta02 = terme_delta02 + 1/(sigma2(j,k))*(a_jk.')*a_jk;
        end
end

% GENERATION OF delta02 ACCORDING TO f(delta02|...)
x = gen_gamma(p*sum(K)/2+xi,terme_delta02/2);
delta02_out = 1/x;

            
