clear all
close all

% synthetic signal loading
%load signal.mat y
%y = [y(2,:)];

load signal.mat
y = y(1,:);
%clear x;

% simulation parameters
    % number of burn-in iterations
    Nbi = 15;
    % number of iteration of interest
    Nr  = 15;
    % sampling step for R
    step = 1;

% segmentation procedure
    [Tab_r, Tab_K] = segmentation(y,5,Nr+Nbi,step);

% plot
    exploitation(y,Tab_r, Tab_K, Nbi, Nr);

