function [R_out, alphaPlus_out, indMPlus_out] = update_MPlus(R,alphaPlus,indMPlus,y,sigma2,proba_d,proba_u,proba_b,MBiblio,Rmax)

%------------------------------------------------------------------
% This function allows ones to update the endmember spectrum matrix
% 
% % INPUT
%         R         : current state of the number of components
%         alphaPlus : current state of the abundance matrix
%         indMPlud  : indices of the current spectrum matrix
%         y         : pixel to be unmixed
%         sigma2    : noise variance
%         proba_d   : the probabilities of death move
%         proba_b   : the probabilities of birth move
%         proba_u   : the probabilities of switch move
%         MBiblio   : spectrum library
%         Rmax      : maximum number of endmember involved in the mixing model
% 
%
% OUTPUT
%       R_out         : the new state of the number of components
%       alphaPlus_out : the new state of the abundance matrix
%       indMPlus_out  : indices of the new spectrum matrix
%
%------------------------------------------------------------------


MPlus = MBiblio(:,indMPlus);

% the type of proposed move is chosen
move_R = gen_discrete([-1 0 1],[proba_d(R) proba_u(R) proba_b(R)],1,1);

% the candidate R is set
R_star = R + move_R;

if R_star ~= R 
    
    % a move with dimension matching is proposed
    % birth/death moves
    
    if move_R==1 % BIRTH
        
        % a spectrum is randomly added
        indM = gen_discrete(setdiff(1:Rmax,indMPlus),ones(1,Rmax-R)/(Rmax-R),1,1);
        indMPlus_star = [indMPlus indM];
        
        % the candidat MPlus is built
        MPlus_star = MBiblio(:,indMPlus_star);
        
        % a abundance coefficient is added
        w = betarnd(1,R,1,1);
        
        % the remaining coefficients are re-scaled
        alphaPlus_star = [alphaPlus*(1-w); w];
        
    else  % DEATH
      
        % a spectrum is randomly removed
        i = unidrnd(R);
        indMPlus_star = indMPlus;
        indMPlus_star(i) = [];        
        MPlus_star = MBiblio(:,indMPlus_star);

        % the corresponding abundance is removed
        alphaPlus_star = alphaPlus;
        w = alphaPlus(i);
        alphaPlus_star(i) = [];
        
        % the remaining coefficients are re-scaled
        alphaPlus_star = alphaPlus_star/sum(alphaPlus_star);        
    end
   
    % computation of the acceptance ratio
    accept = compute_proba_move_birth_death(MPlus_star,MPlus,alphaPlus_star,alphaPlus,R_star,R,sigma2,y,proba_d,proba_b,w,Rmax);
    
    if accept == 1
        % the move is accepted
        R_out = R_star;
        alphaPlus_out = alphaPlus_star;
        indMPlus_out = indMPlus_star;
    else
        % the move is rejected
        R_out = R;
        alphaPlus_out = alphaPlus;
        indMPlus_out = indMPlus;
    end
    
else
    
    % a move without dimension matching is proposed

    % if at least one endmember spectrum is available, we propose a switch
    % move

    if Rmax-R~=0
        
        % index of the spectrum to be replaced
        indM = gen_discrete(1:R, ones(1,R)/R,1,1);

        % index of the spectrum to be added
        indMbis = gen_discrete(setdiff(1:Rmax,indMPlus),ones(1,Rmax-R)/(Rmax-R),1,1);    
        indMPlus_star = indMPlus;
        indMPlus_star(indM) = indMbis;

        % switching
        MPlus_star = MBiblio(:,indMPlus_star);

        alphaPlus_star = alphaPlus;

         % computation of the acceptance ratio
         accept = compute_proba_move_switch(MPlus_star,MPlus,alphaPlus_star,alphaPlus,R,Rmax,sigma2,y);

        if accept == 1
            % the move is accepted
            indMPlus_out = indMPlus_star;
            alphaPlus_out = alphaPlus_star;
            R_out = R;
        else
            % the move is rejected          
            alphaPlus_out = alphaPlus;
            indMPlus_out = indMPlus;
            R_out = R;
        end

    else
        
        % all the spectra are allready involved
        alphaPlus_out = alphaPlus;
        indMPlus_out = indMPlus;
        R_out = R;
    end
    
end


    
