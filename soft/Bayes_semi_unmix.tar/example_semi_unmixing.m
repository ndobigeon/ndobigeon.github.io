clc
clear all
close all

% loading: endmember spectrum library
load spectres.txt;
spectres = spectres-min(spectres(:));
[N_bandes N_spectres] = size(spectres);
N_spectres = N_spectres-1;
Mlibrary = spectres(:,2:end);
wavelength = spectres(:,1);

% loading: pixel to be unmixed
load signal_SNR=15dB.mat y

% Markov chain length
Nmc = 2000;

% number of burn-in period
Nbi = 200;

% Unmixing procedure
tic
[TalphaPlus, TindMPlus, TR] = semi_unmixing(y,Mlibrary,Nmc);
toc
TindMPlus = sort(TindMPlus);

result = exploitation(TalphaPlus, TindMPlus, TR, Mlibrary, wavelength, Nbi, Nmc);

