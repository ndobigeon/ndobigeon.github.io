function accept = compute_proba_move_switch(MPlus_star,MPlus,alphaPlus_star,alphaPlus,R,Rmax,sigma2,y)

%------------------------------------------------------------------
% This function allows ones to compute the acceptance ratio
% for the switch move
% 
% % INPUT
%         MPlus_star     : candidate of the endmember matrix
%         MPlus          : current state of the endmember matrix
%         alphaPlus_star : candidate of the abundance matrix
%         alphaPlus      : current state of the abundance matrix
%         R              : current state of the number components
%         Rmax           : maximum number of endmember involved in the mixing model
%         sigma2         : noise variance
%         y              : pixel to be unmixed
% 
%
% OUTPUT
%       accept  :  equal to one if the new state is accepted
%                  zero otherwise 
%
%------------------------------------------------------------------


% likelihood ratio
A = -(norm(y-MPlus_star*alphaPlus_star)^2)/(2*sigma2) + (norm(y-MPlus*alphaPlus)^2)/(2*sigma2);

% proposal ratio
A = A + log(Rmax-R) - log(R);

rapport = exp(A);

% final probability
proba_accept_move =  min([1, rapport]);

% sampling according to proba_accept_move
accept = gen_discrete([1 0],[proba_accept_move 1-proba_accept_move],1,1);
