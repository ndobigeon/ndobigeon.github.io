function accept = compute_proba_move_birth_death(MPlus_star,MPlus,alphaPlus_star,alphaPlus,R_star,R,sigma2,y,proba_d,proba_b,w,Rmax)

%------------------------------------------------------------------
% This function allows ones to compute the acceptance ratio
% for the birth/death move
% 
% % INPUT
%         MPlus_star     : candidate of the endmember matrix
%         MPlus          : current state of the endmember matrix
%         alphaPlus_star : candidate of the abundance matrix
%         alphaPlus      : current state of the abundance matrix
%         R              : current state of the number components
%         Rmax           : maximum number of endmember involved in the mixing model
%         sigma2         : noise variance
%         y              : pixel to be unmixed
%         proba_d        : probabilities of death move 
%         proba_b        : probabilities of birth move
%         w              : added/removed abundance coefficient
% 
%
% OUTPUT
%       accept  :  equal to one if the new state is accepted
%                  zero otherwise 
%
%------------------------------------------------------------------



% likelihood ratio
A = -(norm(y-MPlus_star*alphaPlus_star)^2)/(2*sigma2) + (norm(y-MPlus*alphaPlus)^2)/(2*sigma2);

% Jacobian
if R_star-R == 1
    A = A + (R-1)*log(1-w);
else
    A = A - (R-2)*log(1-w);
end

% proposal ratio (move)
if R_star-R == 1
    A = A + log(proba_d(R+1)) - log(proba_b(R));
else
    A = A - log(proba_d(R)) + log(proba_b(R-1));
end

% proposal ratio (w)
if R_star-R == 1
    A  = A - log(betapdf(w,1,R)) ;
else
    A  = A + log(betapdf(w,1,R-1));
end

% proposal ratio (s*)
if R_star-R == 1
    A  = A - log(Rmax-R);
else
    A  = A + log(Rmax-(R-1));
end


% prior ratio
if R_star-R == 1
    A  = A + log(R);
else
    A  = A - log(R-1);
end

ratio = exp(A);

% final probability
proba_accept_move =  min([1, ratio]);

% sampling according to proba_accept_move
accept = gen_discrete([1 0],[proba_accept_move 1-proba_accept_move],1,1);
