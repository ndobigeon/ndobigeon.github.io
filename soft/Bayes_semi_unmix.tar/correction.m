function [R_out, alphaPlus_out, indMPlus_out] = correction(R, alphaPlus, indMPlus,t)

ind_neg = find(alphaPlus<t);

ind_sig = setdiff(1:R,ind_neg);

R_out = length(ind_sig);
alphaPlus_out = alphaPlus(ind_sig);
indMPlus_out  = indMPlus(ind_sig);