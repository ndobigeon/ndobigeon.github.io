This package contains programs written by N. DOBIGEON and J.-Y. TOURNERET, for the
implementation of the semi-supervised hyperspectral linear unmixing procedure 
when the endmembers involved in the mixing belong to a knwon library. For more details:

 N. Dobigeon, J.-Y. Tourneret, C.-I Chang "Semi-supervised linear spectral unmixing
	using a hierarchical Bayesian model for hyperspectral imagery"
	IEEE Trans. on Signal Processing, 2007.

The main function is "semi_unmixing.m".
Edit this file to understand the structure of the procedure based on a hierarchical model
and a Gibbs sampling strategy.
The programs are written in MALAB code.
You will find in "example_semi_unmixing.m" a code which allows you 
to perform the semi-supervised unmixing procedure synthetic pixel "signal_SNR=20dB" 
used in the paper.

If you have any question, : nicolas.dobigeon@enseeiht.fr
