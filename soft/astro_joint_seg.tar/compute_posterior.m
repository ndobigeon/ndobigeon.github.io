function logPr = calcul_cible(r,gam,nu,alpha,y);

%------------------------------------------------------------------
% This function compute the probability (up to a normalization)
%       of having the MC state R according to the posterior 
%       of interest
% 
% INPUT
%       r     : the MC state for the matrix R
%       gam   : gam parameter
%       nu    : nu parameter
%       alpha : alpha parameter
%       y     : the signal to be segmented
%
% OUTPUT
%       logPr : the log of the probability
%
%------------------------------------------------------------------


global J N Tepsilon

for j=1:2^J
    tmp = r(:,1:N-1)-Tepsilon(:,j)*ones(1,N-1);
    S(j) = length(find(sum(abs(tmp),1)==0));
end
        
% number of ruptures in each sequence
K = sum(r,2);
Kmax = max(K);

% length of each segment in each sequence
n = zeros(J,Kmax);
rtraf=[ones(J,1) r];
for j=1:J
    n(j,1:K(j)) = diff(find(rtraf(j,:)==1));
end

% computation
logPr = sum(gammaln(S+alpha)) - log(gam) - gammaln(sum(S+alpha));
for j=1:J
        Nechantj=[0, find(r(j,:)==1)];
        rtraf=[1,r(j,:)];
        sumYj = compute_sumY(y(j,:),Nechantj);
        logPr = logPr + nu*K(j)*log(gam) -K(j)*gammaln(nu) + sum(gammaln(sumYj+nu)-(sumYj+nu).*log(n(j,1:K(j))+gam));
end
