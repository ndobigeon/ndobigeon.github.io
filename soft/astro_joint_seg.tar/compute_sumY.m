function S = compute_sumY(y,Nechant)

%------------------------------------------------------------------
% Compute the sums of the signal samples in the segments
%       specified in Nechant
% 
% INPUT
%       y       : the sequence to be segmented
%       Nechant : the indexes of the beginning and ends
%                    of the segments
%
% OUTPUT
%       S : the sums
%
%------------------------------------------------------------------

Nrupt=length(Nechant)-1;
    for k=1:Nrupt
        % beginning of the k-th segment
        i1=Nechant(k)+1;
        % end of the k-th segment
        i2=Nechant(k+1);
        % length of the k-th segment
        nk=i2-i1+1;
        % computation
        S(k)=sum(y(i1:i2));
    end
