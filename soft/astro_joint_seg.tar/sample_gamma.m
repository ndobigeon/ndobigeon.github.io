function gam_out  = echantillonner_gamma(r,gam,nu,y);

%------------------------------------------------------------------
% This function allows to sample the parameter gam
%       according to f(gam|r,y)
% 
% INPUT
%       r     : the current state of the matrix R
%       gam   : the current state of the gam parameter
%       nu    : nu parameter
%       y     : the signal to be segmented
%
% OUTPUT
%       gam_out : the new state of the gam parameter
%
%------------------------------------------------------------------

global J N Tepsilon

% number of ruptures in each sequence
K = sum(r,2);
Kmax = max(K);

% length of the segments in each sequence
n = zeros(J,Kmax);
rtraf=[ones(J,1) r];
for j=1:J
    n(j,1:K(j)) = diff(find(rtraf(j,:)==1));
end

% for each signal
for j=1:J
    K_j = K(j);
    Nechantj=[0, find(r(j,:)==1)];

    SumYj = compute_sumY(y(j,:),Nechantj);

    % generation of lambda according to f(lambda|gam,y,r)
    for k = 1:K_j
        lambda(j,k)=gen_gamma(nu+SumYj(k),gam+n(j,k));
    end;

    % generation of gam according to f(gam|lambda,y,r)
    gam_out =  gen_gamma(sum(K)*nu,sum(lambda(:)));
            
end
            
