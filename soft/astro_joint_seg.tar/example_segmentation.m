clear all
close all

% synthetic signal loading
load signal.mat y
%y = [y(2,:)];

% simulation parameters
    % number of burn-in iterations
    Nbi = 50;
    % number of iteration of interest
    Nr  = 50;
    % sampling step for R
    step = 1;

% segmentation procedure
    [Tab_r, Tab_K] = segmentation(y,Nr+Nbi,step);
    
% plot
    exploitation(y,Tab_r, Tab_K, Nbi, Nr);

