function X = gen_dirichlet(a)

%------------------------------------------------------------------
% This function allows to sample according to a dirichlet distr.
% 
% INPUT
%       a : parameter vector of the distribution
%
% OUTPUT
%       X : the generated sample
%
%------------------------------------------------------------------


nb_config = length(a);

for i=1:nb_config
    X(i) = gen_gamma(a(i),1);
end
X = X/sum(X);