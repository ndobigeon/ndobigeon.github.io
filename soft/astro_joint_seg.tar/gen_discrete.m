function x = gen_discrete(valeurs,probas,N,M);

%------------------------------------------------------------------
% This function allows to sample the discrete variable x
%       which takes the values collected in valeurs
%       with the corresponding probabilities probas
% 
% INPUT
%       valeurs : possible values for x
%       probas  : probabilities of having each discrete value
%       N       : number of lines of x to be sampled
%       M       : number of columns of x to be sampled
%
% OUTPUT
%       x : a N-by-M matrix of values belonging in valeurs with
%                   probabilities probas
%
%------------------------------------------------------------------

if sum(probas)~=1.,
   %disp('ERREUR : somme des probabilit�s diff�rentes de 1');
   %disp('	  ==> normalisation des probabilit�s');
   probas = probas/sum(probas);
end;

% *** probabilit�s cumul�es ***
probas = probas(:).';
L      = length(probas);
K      = N*M;
psup   = cumsum(probas);
pinf   = [0 psup(1:end-1)];
Pinf   = kron(ones(1,K),pinf(:));
Psup   = kron(ones(1,K),psup(:));

% *** g�n�ration de variables uniformes
u = rand(1,K);
U = kron(ones(L,1),u);

% *** comparaisons ***
C = (U>Pinf) & (U<Psup);

% *** d�terminations des xi � partir des variables uniformes ***
V = kron(valeurs(:),ones(1,K));
X = V.*C;
x = sum(X);

% *** formation de la matrice ***
x = reshape(x,N,M);

