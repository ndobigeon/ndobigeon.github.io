This package contains programs written by N. DOBIGEON and J.-Y. TOURNERET, for the
implementation of the joint segmentation of astronomical data described in the article:

 N. Dobigeon, J.-Y. Tourneret, J.D. Scargle "Joint Segmentation of Multivariate
	Astronomical Time-Series: Bayesian Sampling with a Hierarchical Model"
	IEEE Trans. on Signal Processing, 2005.

The main function is "segmentation.m".
Edit this file to understand the structure of the procedure based on a hierarchical model
and a Gibbs sampling strategy.
The programs are written in MALAB code.
You will find in "example_segmentation.m" a code which allows you 
to perform the segmentation on the 2-D synthetic signal "signal.mat" used in the paper.

If you have any question, : nicolas.dobigeon@enseeiht.fr
