function alphafin = FCSGM_unmixing(y,M)

% FC-SGM algorithm for hyperspectral unmixing
% y = M\alpha+n
% y (Lx1) : observed pixel
% M (LxR) : endmember matrix
% \alpha (Rx1) abundances to be estimated
% L : number of spectal bands
% R : number of endmembers


% Algorithm parameters

kmax=100000;
[L,R]=size(M);
alphaest=zeros(R,kmax);
a=1/(1/10/max(y));
 
% Reconstruction

e=1/10/max(y);
eA=e*M;
E=eA;
EtE=E'*E;
m = size(EtE,1);
One=ones(m,1);
iEtE=inv(EtE);
iEtEOne=iEtE*One;
sumiEtEOne=sum(iEtEOne);


er=e*y;
f=er;
Etf=E'*f;


ls=iEtE*Etf;
lamdiv2=-(1-(ls'*One))/sumiEtEOne;
x2=ls-lamdiv2*iEtEOne;
 


 alphaest(:,1)=x2;
 alphaest(:,1)=alphaest(:,1)/sum(alphaest(:,1));

 k=1;
 diff=1;

while (abs(diff)>=1e-7 & k<kmax)

    k=k+1;

    alphaest(:,k)=alphaest(:,k-1).*(M'*y+a)./(M'*M*alphaest(:,k-1)+a*sum(alphaest(:,k-1)));

    airefin=sum(sum(alphaest(:,k)));
    alphaest(:,k)=alphaest(:,k)/airefin;    
    
    diff=alphaest(:,2:k)-alphaest(:,1:k-1);

end

alphafin=alphaest(:,k);

     
     
 

  
