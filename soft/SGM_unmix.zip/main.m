clear all
close all
clc

load spectra.txt
% loading: endmember spectra

spectra = spectra-min(spectra(:));
[L tmp] = size(spectra);
N_spectra = tmp-1;

% % column 1: Wavelength spectra
% % column 2: Construction Concrete spectrum
% % column 3: Green Grass
% % column 4: Micaceous Loam
% % column 5: Olive Green Paint
% % column 6: Bare Red Brick
% % column 7: Galvanized Steel Metal

% wavelength vector
wave = spectra(:,1);

% matrix of all the spectra
M_all = spectra(:,2:end);

% load signal
load signal_SNR=15dB.mat
alphaTrue = alpha';
clear alpha;

% endmember matrix
M = M_all(:,[1 2 3]);

% ISRA
A_SGM = SGM_unmixing(y,M);
disp(A_SGM);

% Normalized ISRA
A_FCSGM = FCSGM_unmixing(y,M);
disp(A_FCSGM);
