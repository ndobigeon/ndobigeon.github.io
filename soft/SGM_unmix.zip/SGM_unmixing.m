function alphafin = SGM_unmixing(y,M)

% SGM algorithm for hyperspectral unmixing
% y = M\alpha+n
% y (Lx1) : observed pixel
% M (LxR) : endmember matrix
% \alpha (Rx1) abundances to be estimated
% L : number of spectal bands
% R : number of endmembers


% Algorithm parameters

kmax=100000;
[L,R]=size(M);
alphaest=zeros(R,kmax);
a=0;
 
% Reconstruction

 alphaest(:,1)=rand(R,1);
 alphaest(:,1)=alphaest(:,1)/sum(alphaest(:,1));

 k=1;
 diff=1;

while (abs(diff)>=1e-7 & k<kmax)

    k=k+1;

    alphaest(:,k)=alphaest(:,k-1).*(M'*y+a)./(M'*M*alphaest(:,k-1)+a*sum(alphaest(:,k-1)));

    airefin=sum(sum(alphaest(:,k)));
    alphaest(:,k)=alphaest(:,k)/airefin;

    diff=alphaest(:,2:k)-alphaest(:,1:k-1);

end

alphafin=alphaest(:,k);

      
     
     
 

  
