function z = hinge(y)
%  z = hinge(y)
%
%   hinge function)

z = max(-y,0);
