function newg = BSsplitmerge(f, mindim)
% SPLITMERGE extract bands of a HS image using a split and merge algorithm

% Read HS image
[f , BInd]= hsimread(f);
disp('image read');
% Perform splitting first.
g = BandSplit(f, BInd, mindim);
% Now merge by looking at each band and fusing it with 
% all bands that violates the predicate(high correlation)
% Put all bands on ProcessList
% 	 Extract each band from ProcessList
% 	 Traverse remainder of list to find similar bands (correlation criterion)
% 	 If they are highly correlated then
%  		 merge the bands and recalculate merged values;
  [M N B] = size(g);
  newg = g;
  i = 1;
  while (i < B)
      region = newg(:,:,i);
      j = i+1;
      while (j < B)
          chkband = cat(3,newg(:,:,i),newg(:,:,j));
      if (~predicate(chkband))% corr2(f(i),f(j))if high 
          region = cat(3,region,newg(:,:,j));%add to region 
          % disp('merge');
          newg = cat(3,newg(:,:,1:j-1),newg(:,:,j+1:end)); %remove from list B= B-1;
          B = B-1;                             
      end;
      j = j+1;
      end;
 %Merge bands in region
[M N BR]=size(region); 
newg(:,:,i)=(1/BR) *sum(region,3);
i = i+1;
end;

% % Finally, obtain each connected region and label it with a different
% % integer value using function bwlabel.
% g=bwlabel(imreconstruct(MARKER,g));
% % crop and exit
% g=g(1:M,1:N);
return;


