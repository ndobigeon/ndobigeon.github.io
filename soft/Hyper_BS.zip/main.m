clc;
clear all;
load indian_pines_corrected.mat;
f = indian_pines_corrected;

% Read image
[f , BInd]= hsimread(f);
F = BSsplitmerge(f,0.1);


