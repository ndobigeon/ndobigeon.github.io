function g = BandSplit(f,BInd,mindim)
% This function decomposes the HS image bands(f) into sub-bands according
% to correlation function(fun)
% BInd is the vector of band indices for each band in f image
% mindim represents tha min index for the split band
% Note that in the fnction call we use @PREDICATE for the value of fun.
% PREDICATE is a function in the MATLAB path, provided by the user. Its
% syntax is
% FLAG = PREDICATE(REGION) which must return TRUE if the two images in
% REGION satisfy the predicate defined by the code in the function;
% otherwise, the value of FLAG must be FALSE.
% band_index = min distance bet two adjacent bands
newf = f;
newBInd = BInd;
[r B]=size(BInd);
ratio=1/3;
band_index = 1;


while (band_index > mindim)
i = 1;
 while(i < B)
     region = newf(:,:,i:i+1);
     if predicate(region)
         % disp('Split');
         % split the two images as follows
         % new band indices b1 and b2 is at equal distances
         % s1,i(b) = 1/(b-bmin+1) *x1
         b1 = newBInd(i)+(ratio);
         %S1 = (1/(b1-(newBInd(i))+1))*region(:,:,1);
         S1 = (1/3)*(region(:,:,1)+region(:,:,2));
         % s2,i(b) = 1/(bmax-b+1) *x2
         b2 = newBInd(i+1) -(ratio);
         % S2 = (1/(newBInd(i)+1-b2+1))* region(:,:,2);
         S2 = (2/3)* (region(:,:,1)+region(:,:,2));
         % Construct newf and newBInd
         newf = cat(3,newf(:,:,1:i),S1,S2,newf(:,:,i+1:end));
         newBInd = [newBInd(1:i),b1,b2,newBInd(i+1:end)];
         i = i+3;
         B = B+2;
     else
         i = i+1;
     end;
        
 end;
 % newf = BandSplit(newf,newBInd, (ratio/3),mindim,fun);
 band_index = ratio;
 ratio = ratio/3;
 end; 

 g=newf;
return;