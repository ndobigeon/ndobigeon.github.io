function flag = predicate(region)
% region means two adjacent bands
corr=corr2(region(:,:,1),region(:,:,2));
%disp(corr);
flag=(corr < 0.8) ;
end