function [ output_img, BInd ] = hsimread( input_img )
% Read HS image

[M N B]= size(input_img);
for i=1:B
    BInd(i)=i;
    output_img(:,:,i) = NormImage( input_img(:,:,i) );
end

end

