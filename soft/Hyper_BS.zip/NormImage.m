function [ dblImageS255 ] = NormImage( grayImage )
% Normalization of an image

originalMinValue = double(min(min(grayImage)));
originalMaxValue = double(max(max(grayImage)));
originalRange = originalMaxValue - originalMinValue;

% Get a double image in the range 0 to +255
desiredMin = 0;
desiredMax = 255;
desiredRange = desiredMax - desiredMin;
dblImageS255 = desiredRange * (double(grayImage) - originalMinValue) /originalRange + desiredMin;
end

