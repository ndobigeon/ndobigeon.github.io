function [PDir PDirTc]  =  sample_PDir_bloc(PDir,epsilon_PDir,alphan,label,varK,sumvarK,SumA,x1,x2);

%------------------------------------------------------------------
% UsGNCM by A. HALIMI  
% University of Toulouse - France - 2015
%
%
% INPUT 
%
% OUTPUT
%       PDir     : New sampled vector
%       PDirTc   : Acceptance ratio  (K X R)%
%------------------------------------------------------------------


PDir              = PDir'; %R  x K
[R K]             = size(PDir); 
PDirTc            = zeros(1,K); 
L                 = randi([45,55]);   
 
[PDir,PDirTc]  = CHMC_sampling_bloc_PDir(epsilon_PDir,L,PDir,eps*ones(R,K),100*ones(R,K),alphan,label,varK,sumvarK,SumA,x1,x2); 

PDirTc             = PDirTc(:);
PDir               = PDir'; %K  x R


 
 