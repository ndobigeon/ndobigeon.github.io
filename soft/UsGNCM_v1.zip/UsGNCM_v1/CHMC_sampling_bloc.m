function [q,Tc,p] = CHMC_sampling_bloc(epsilon,L,current_q,q_l,q_u,yn,sigman2,MPlus,vect,K,label,PDir,Ksi)
 % sigman2  de taille (1 X N^2)
%-------------------------------------------------------------------------
% Paper :
% A. Halimi, N. Dobigeon and J.-Y. Tourneret, "Unsupervised Unmixing of
% Hyperspectral Images Accounting for Endmember Variability", IEEE Trans. 
% Image Processing, 2015.
%
% Model:  UsGNCM (Unsupervised Generalized Normal Compositional Model)
%
% Contact Abderrahim Halimi (a.halimi@hw.ac.uk) for any comments
%-------------------------------------------------------------------------

Tc         = 1;
q          = current_q;
R          = size(q,1)+1;
N2         = size(q,2);
N          = sqrt(N2); 
p          = randn(size(q));
current_p  = p;
l          = q_u - q_l;
epsilon    = repmat(epsilon,R-1,1); 
q(find(q>0.999))  = 0.999;
q(find(q<0.001))  = 0.001;i=1;
p          = p - epsilon.*grad_U_bloc(q,yn,sigman2,MPlus,vect,i,K,label,PDir,Ksi)/2; 
                                                   
for i = 1:L
    q  = q + epsilon.*p; 
    % Check the constraints
    while(sum(sum(q<q_l | q>q_u)))
        [lig col]  = find(q<q_l | q>q_u);

        for ss = 1:length(lig)
            n = col(ss);
            d = lig(ss); 
                if(q(d,n)<q_l(d,n))  
                    num    = floor((q_l(d,n) - q(d,n))/(2*l(d,n)));
                    q(d,n) = q(d,n) + num*2*l(d,n);
                    q(d,n) = 2*q_l(d,n) - q(d,n);
                    p(d,n) = -p(d,n);
                end
                
                if(q(d,n)>q_u(d,n)) 
                    num    = floor((q(d,n) - q_u(d,n))/(2*l(d,n)));
                    q(d,n) = q(d,n) - num*2*l(d,n);
                    q(d,n) = 2*q_u(d,n) - q(d,n);
                    p(d,n) = -p(d,n);
                end
        end
    end 
    q(find(q>0.999))  = 0.999;
    q(find(q<0.001))  = 0.001;
    if(i~=L) 
        p = p - epsilon.*grad_U_bloc(q,yn,sigman2,MPlus,vect,i,K,label,PDir,Ksi); 
    end 
end
q(find(q>0.999))  = 0.999;
q(find(q<0.001))  = 0.001;

p  = p - epsilon.*grad_U_bloc(q,yn,sigman2,MPlus,vect,i,K,label,PDir,Ksi)/2; 
p  = -p;

current_U   = compute_U_bloc(current_q,yn,sigman2,MPlus,K,label,PDir,Ksi);
current_K   = sum(current_p.^2)/2; %current_p'*current_p/2; %
proposed_U  = compute_U_bloc(q,yn,sigman2,MPlus,K,label,PDir,Ksi);
proposed_K  = sum(p.^2)/2; %p'*p/2; %
 
vect_reject      = (rand(1,N2) > exp(current_U-proposed_U+current_K-proposed_K) );
Tc               = 1-vect_reject;
pos_reject       = find(vect_reject);
q(:,pos_reject)  = current_q(:,pos_reject);
 
 