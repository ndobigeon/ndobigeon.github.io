function [dU] = grad_PDir_bloc(PDir,alphan,label,sumvarK,x1,x2)
%-------------------------------------------------------------------------
% Paper :
% A. Halimi, N. Dobigeon and J.-Y. Tourneret, "Unsupervised Unmixing of
% Hyperspectral Images Accounting for Endmember Variability", IEEE Trans. 
% Image Processing, 2015.
%
% Model:  UsGNCM (Unsupervised Generalized Normal Compositional Model)
%
% Contact Abderrahim Halimi (a.halimi@hw.ac.uk) for any comments
%-------------------------------------------------------------------------
% PDir    de taille (R X K)
% alphan  de taille (R X N2)
% label  de taille (1 X N2)



[R K]  = size(PDir); 
dU     = zeros(R,K); 
psiSumPdir  = psi(sum(PDir));% 1 X K
psiPdir     = (psi(PDir));% R X K

for k=1:K 
    Nk       = sum(label ==k);
    dU(:,k)  = Nk*(x2+1)*  ( psiPdir(:,k)-psiSumPdir(1,k) ) ;
    
end
 
dU = dU + sumvarK; 