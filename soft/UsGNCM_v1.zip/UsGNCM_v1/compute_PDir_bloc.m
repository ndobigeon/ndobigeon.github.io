function [U] = compute_PDir_bloc(PDir,alphan,label,varK,SumA,x1,x2)
%-------------------------------------------------------------------------
% Paper :
% A. Halimi, N. Dobigeon and J.-Y. Tourneret, "Unsupervised Unmixing of
% Hyperspectral Images Accounting for Endmember Variability", IEEE Trans. 
% Image Processing, 2015.
%
% Model:  UsGNCM (Unsupervised Generalized Normal Compositional Model)
%
% Contact Abderrahim Halimi (a.halimi@hw.ac.uk) for any comments
%-------------------------------------------------------------------------
% PDir    de taille (R X K)
% alphan  de taille (R X N2)
% label  de taille (1 X N2)

[R K]  = size(PDir); 

U  = zeros(1,K); 

for k=1:K
    Nk(k)   = sum(label ==k);
    U(1,k)  = sum( squeeze(varK(:,:,k))     *  PDir(:,k)); % 1 X K  
end 
U = U + (x2+1)*Nk.*(sum(gammaln(PDir))- gammaln(sum(PDir))) + SumA - R*x1*Nk; % 1 X K
