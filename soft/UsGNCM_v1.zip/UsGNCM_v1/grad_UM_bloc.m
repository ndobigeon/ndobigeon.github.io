function [dU_dM] = grad_UM_bloc(MPlus,alphan,sigman2,yn,MEEA,gammalm1,coeff1,Agama2)
%-------------------------------------------------------------------------
% Paper :
% A. Halimi, N. Dobigeon and J.-Y. Tourneret, "Unsupervised Unmixing of
% Hyperspectral Images Accounting for Endmember Variability", IEEE Trans. 
% Image Processing, 2015.
%
% Model:  UsGNCM (Unsupervised Generalized Normal Compositional Model)
%
% Contact Abderrahim Halimi (a.halimi@hw.ac.uk) for any comments
%-------------------------------------------------------------------------
% MPlus matrice de taille (R X L)
% alphan abondances de taille (R X N^2)
% sigman2  de taille (1 X N^2)
% yn pixels de taille (L X N^2)


[R,L]   = size(MPlus);
[L,N2]  = size(yn);
s2      = 0.0009;%0.0007;%0.005;%0.02;    %% Sur les m_vca

MPlus   = MPlus';  %matrice de taille (L X R)
dU_dM   = coeff1 + reshape(sum(Agama2.*kron(MPlus,ones(R,1)),2),R,L) + (MPlus-MEEA)'/s2;% R   X L 
 