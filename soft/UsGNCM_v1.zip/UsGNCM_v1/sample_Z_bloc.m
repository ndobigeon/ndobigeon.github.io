
function [Znew alphan Tc] = sample_Z_bloc(Z,Y_bloc,MPlus,sigma2,epsilon_c,vect,K,label,PDir,Ksi);

%------------------------------------------------------------------
% UsGNCM 
% by A. HALIMI  
% University of Toulouse - France - 2015
% 
% INPUT
%       Z        : Matrix to be sampled (R-1 X N^2)
%       Y_bloc   : Matrix of observations (L X N^2)
%       MPlus    : the spectra used in the mixture
%       sigma2   : Matrix of noise variance (N X N)
%       epsilon_c: vector of stepsize (1 X N^2)
%       K        : Number of spatial classes
%       label    : spatial labels
%       PDir:    : Dirichlet parameters
%       Ksi      : Noise
%
% OUTPUT
%       Z        : New sampled matrix (R-1 X N^2)
%       alphan   : Matrix of abundances (R X N^2)
%       Tc       : Acceptance ratio  (N^2 X 1)
%
%------------------------------------------------------------------


Znew = zeros(size(Z));
R    = size(Znew,1)+1;
N    = sqrt(size(Znew,2));
Tc   = zeros(size(Z,2),1);

L              = randi([25,35]); %nuber of leapfrog
[Znew,Tc]      = CHMC_sampling_bloc(epsilon_c,L,Z,zeros(R-1,N^2),ones(R-1,N^2),Y_bloc,sigma2,MPlus,vect,K,label,PDir,Ksi);
                 
%%% Calcul de alpha
alphan(1,:) = 1- Znew(1,:);
for j=2:(R-1)
    alphan(j,:) = prod(Znew(1:(j-1),:),1).*(1-Znew(j,:));
end
alphan(R,:) = prod(Znew(1:(R-1),:));


