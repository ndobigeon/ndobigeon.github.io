function [dU_dsigma2] = grad_Usigma_bloc(sigman2,yn,MPlus,alphan,ApAp2,varo,Ksi)
%-------------------------------------------------------------------------
% Paper :
% A. Halimi, N. Dobigeon and J.-Y. Tourneret, "Unsupervised Unmixing of
% Hyperspectral Images Accounting for Endmember Variability", IEEE Trans. 
% Image Processing, 2015.
%
% Model:  UsGNCM (Unsupervised Generalized Normal Compositional Model)
%
% Contact Abderrahim Halimi (a.halimi@hw.ac.uk) for any comments
%-------------------------------------------------------------------------
% zn matrice de taille (R-1 X N^2)
% yn pixels de taille (L X N^2)
% sigman2 de taille (R X L)
% sigman2mod de taille (R X N^2 X L)
 
N2             = size(yn,2);
[L R]          = size(MPlus); 

beta_sig       = 0.00001; 
alpha_sig      = 1; 
 
ApRlAp         = ApAp2'*sigman2+Ksi;  %N2 X L
dU1U3_dsigma2  = 0.5*ApAp2*((1-varo./ApRlAp)./ApRlAp);   % R X L
dU2_dsigma2    = (alpha_sig+1)./sigman2 - beta_sig./(sigman2.^2); % R X L   
dU_dsigma2     = dU1U3_dsigma2+dU2_dsigma2;  % R X L 

 