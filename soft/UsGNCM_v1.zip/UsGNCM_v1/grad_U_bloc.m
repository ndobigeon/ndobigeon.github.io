function [dU_zn] = grad_U_bloc(zn,yn,sigman2,MPlus,vect,iteri,K,label,PDir,Ksi)
%-------------------------------------------------------------------------
% Paper :
% A. Halimi, N. Dobigeon and J.-Y. Tourneret, "Unsupervised Unmixing of
% Hyperspectral Images Accounting for Endmember Variability", IEEE Trans. 
% Image Processing, 2015.
%
% Model:  UsGNCM (Unsupervised Generalized Normal Compositional Model)
%
% Contact Abderrahim Halimi (a.halimi@hw.ac.uk) for any comments
%-------------------------------------------------------------------------
% zn matrice de taille (R-1 X N^2)
% yn pixels de taille (L X N^2)
% sigman2 de taille (R X L)
% sigman2mod de taille (R X N^2 X L)

N2        = size(zn,2);
R         = size(zn,1)+1;
L         = size(yn,1);
%%% alpha
alphan(1,:) = 1- zn(1,:);
for j=2:(R-1)
    alphan(j,:) = prod(zn(1:(j-1),:),1).*(1-zn(j,:));
end
alphan(R,:) = prod(zn(1:(R-1),:));

%%% Computations
for k=1:K
    pos     = find(label ==k);  
    for r=1:R-1
        du2_dz(r,pos)  = - (sum(PDir(k,r+1:R))-1)./zn(r,pos) + (PDir(k,r)-1) ./ (1-zn(r,pos) );%(R-1 X N^2) 
    end 
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  
ApRlAp2     = 1./((alphan.^2)'*sigman2+Ksi)';  % L X N2  %%% 
YmMA        = (yn - MPlus*alphan); % L X N2  %%% 
V           = (YmMA.*ApRlAp2);   % L X N2  %%%  
du1_da      = -MPlus'*V - (sigman2*(V.^2-ApRlAp2)).*alphan;
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
%%% Adjustment of the dimensions
du1_dz = zeros(R-1,N2); 
for r = 1:R-1 
    du1_dz(r,:) = du1_da(r,:).*(alphan(r,:)./(zn(r,:)-1))+ sum(du1_da(r+1:R,:).*alphan(r+1:R,:),1)./(zn(r,:));
end
dU_zn  = du1_dz+du2_dz;  % (R-1 X N^2)

 