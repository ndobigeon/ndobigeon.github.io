function [Pnoisenew NoiseTc] =   sample_SigNoise(epsilon_N,Pnoise,varo,ApAp2sigma2);
 
%------------------------------------------------------------------
% UsGNCM by A. HALIMI  
% University of Toulouse - France - 2015
%
% INPUT 
%
% OUTPUT
%       Pnoisenew     : New sampled vector
%       NoiseTc       : Acceptance ratio 
%
%------------------------------------------------------------------


[N2 L]            = size(varo); 
NoiseTc           = zeros(N2,1); 
L                 = randi([45,55]);                
[Pnoisenew,NoiseTc]  = CHMC_sampling_bloc_SigNoise(epsilon_N,L,Pnoise,zeros(1,N2),1*ones(1,N2),varo,ApAp2sigma2);
 
                                               
