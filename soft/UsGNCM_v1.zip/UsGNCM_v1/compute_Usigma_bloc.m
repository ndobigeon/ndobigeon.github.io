function [valn] = compute_Usigma_bloc(sigma2,yn,MPlus,alphan,ApAp2,varo,Ksi)
%-------------------------------------------------------------------------
% Paper :
% A. Halimi, N. Dobigeon and J.-Y. Tourneret, "Unsupervised Unmixing of
% Hyperspectral Images Accounting for Endmember Variability", IEEE Trans. 
% Image Processing, 2015.
%
% Model:  UsGNCM (Unsupervised Generalized Normal Compositional Model)
%
% Contact Abderrahim Halimi (a.halimi@hw.ac.uk) for any comments
%-------------------------------------------------------------------------
% zn matrice de taille (R-1 X N^2)
% yn pixels de taille (L X N^2)
% sigman2  de taille (R X L)
 
N2      = size(yn,2);
[L R]   = size(MPlus);

beta_sig  = 0.00001;%0.0000001;%0.0000001;%
alpha_sig = 1;%
gammal    = ((ApAp2)'*sigma2)+Ksi;  % N2 X L
gammalm1  = 1./gammal';  % L X N2 
 
  
U3         = 1/2*sum( log(gammal),1); % 1 X L   
U2         = (alpha_sig+1)*sum(log(sigma2),1) + beta_sig*sum(1./sigma2,1); % 1 X L
U1         = 0.5*sum(varo'.*gammalm1,2)';   % 1 X L 
   
valn       = U1+U2+U3;
 
 