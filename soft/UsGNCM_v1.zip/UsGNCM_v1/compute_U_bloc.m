function [valn] = compute_U_bloc(zn,yn,sigman2,MPlus,K,label,PDir,Ksi)
%-------------------------------------------------------------------------
% Paper :
% A. Halimi, N. Dobigeon and J.-Y. Tourneret, "Unsupervised Unmixing of
% Hyperspectral Images Accounting for Endmember Variability", IEEE Trans. 
% Image Processing, 2015.
%
% Model:  UsGNCM (Unsupervised Generalized Normal Compositional Model)
%
% Contact Abderrahim Halimi (a.halimi@hw.ac.uk) for any comments
%-------------------------------------------------------------------------
% zn matrice de taille (R-1 X N^2)
% yn pixels de taille (L X N^2)
% sigman2  de taille (R X L)
 
N2        = size(zn,2);
R         = size(zn,1)+1;
L         = size(yn,1);
%%%  alpha
alphan(1,:) = 1- zn(1,:);
for j=2:(R-1)
    alphan(j,:) = prod(zn(1:(j-1),:),1).*(1-zn(j,:));
end
alphan(R,:) = prod(zn(1:(R-1),:));
  
%%% Computations
for k=1:K
    pos              = find(label ==k); 
    for r=1:R-1
        U2(r,pos) = - ( (sum(PDir(k,r+1:R))-1)*log(zn(r,pos)) + (PDir(k,r)-1)*log(1-zn(r,pos))); 
    end  
end
U2    = sum(U2,1); % 1 X  N2  

gammal    = ((alphan.^2)'*sigman2)+Ksi;  % N2 X L
gammalm1  = 1./gammal;  %N2 X L  %%%
 
U1         = (sum((((yn - MPlus*alphan).^2)'.*gammalm1),2)/2)'; %1 X N2 
U3         = 1/2*sum( log(gammal),2  )'; % 1 X N^2
valn       = U1+U2+U3;
 
 