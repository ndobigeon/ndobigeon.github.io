function [Ta TMPlus Tsigma2 TPnoise TLabel TPDir epsilon_cc epsilon_MM epsilon_ss epsilon_NN ...
    Taux_acceptC  Taux_acceptM Taux_acceptsig  epsilon_Pdir Taux_PDir Taux_acceptN TFlabel]= ...
    unmixing(Y,Y_bloc,MEEA,Nmc,Nbi,N,Zinit,sigma2init,alpha0,epsilon_c,epsilon_M,epsilon_sig,epsilon_PDir,epsilon_N,K,label0)
%-------------------------------------------------------------------------
% Paper :
% A. Halimi, N. Dobigeon and J.-Y. Tourneret, "Unsupervised Unmixing of
% Hyperspectral Images Accounting for Endmember Variability", IEEE Trans.
% Image Processing, 2015.
%
% Code:  UsGNCM (Unsupervised Generalized Normal Compositional Model)
%
% Contact Abderrahim Halimi (a.halimi@hw.ac.uk) for any comments
%  
%-------------------------------------------------------------------------
%
% INPUT
%       Y              : Pixels NxNxL
%       Y_bloc         : Pixels LxN2
%       MEEA           : Extracted M using an EEA
%       Nbi            : Burn-in number
%       Nmc            : Number of samples
%       N              : Number of rows or columns
%       Zinit          : Coefficient related to abundances (initialization)
%       sigma2init     : Initialization of endmember variances
%       alpha0         : Actual abundances (equal to FCLS for real data)
%       alpha0         : Abundance
%       epsilon_c      : HMC parameter for the abundances
%       epsilon_M      : HMC parameter for the endmember means
%       epsilon_sig    : HMC parameter for the endmember variances
%       epsilon_PDir   : HMC parameter for the Dirichlet parameters
%       epsilon_N      : HMC parameter for the noise variance
%       K              : Number of spatial classes
%       label0         : Actual labels
%
%
% OUTPUT
%       Ta             : Abundance chains
%       TMPlus         : Endmember mean chains
%       Tsigma2        : Endmember variance chains
%       TPnoise        : Noise variance chains
%       TLabel         : Label chains
%       TPDir          : Dirichlet parameter chains
%       epsilon_cc     : evolution of the HMC parameter for the abundances
%       epsilon_MM     : evolution of the HMC parameter for the endmember means
%       epsilon_ss     : evolution of the HMC parameter for the endmember variances
%       epsilon_NN     : evolution of the HMC parameter for the noise variance
%       Taux_acceptC   : Acceptance rate for abundances
%       Taux_acceptM   : Acceptance rate for endmember means
%       Taux_acceptsig : Acceptance rate for endmember variances
%       epsilon_Pdir   : evolution of the HMC parameter for the dirichlet parameters
%       Taux_PDir      : Acceptance rate for dirichlet parameters
%       Taux_acceptN   : Acceptance rate for noise variances
%       TFlabel        : Conditional posterior label
%------------------------------------------------------------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%   Constants          %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
MPlus  = MEEA;
N2     = N^2;
[L R]  = size(MPlus);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% initialization of the parameters %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sigma2  = sigma2init;
Z       = Zinit;
Pnoise  = 0.000001*ones(N2,1); % N2 X 1
Label   = randi(K,1,N2); %label0;%
PDir    = ones(K,R); %  PDir  K X R

Ta       = zeros(R,N^2,Nmc-Nbi);
TPDir    = zeros(K,R,Nmc-Nbi);
TMPlus   = zeros(L,R,Nmc-Nbi);
Tsigma2  = zeros(R,L,Nmc-Nbi);
TPnoise  = zeros(N2,Nmc-Nbi);
TLabel   = zeros(1,N2,Nmc-Nbi);

Taux_acceptC   = zeros(N2,Nmc);
Taux_PDir      = zeros(K,Nmc);
Taux_acceptM   = zeros(L,Nmc);
Taux_acceptsig = zeros(L,Nmc);
Taux_acceptN   = zeros(N2,Nmc);


% % useful quantities
x1            = 0.01; % Dirichlet hyperparameter
x2            = 0.01; % Dirichlet hyperparameter
vect          = -repmat((R-1-(1:(R-1)))',1,N^2);
ynmod2        = repmat(reshape(Y_bloc',1,N2,L),R,1) ;% R X N2 X L
ynmod         = reshape(Y_bloc',1,N^2,L); %1 X N2 X L
pos1          = ones(1,N); % Checkboard
pos1(2:2:end) = 0;         % Checkboard
pos1          = toeplitz([pos1]); % Checkboard

compt   = 1;

% beginning
for m_compt= 1:Nmc  %deb:deb+20 %
    m_compt
    epsilon_cc(m_compt,:)   = epsilon_c;
    epsilon_MM(m_compt,:)   = epsilon_M;
    epsilon_ss(m_compt,:)   = epsilon_sig;
    epsilon_Pdir(m_compt,:) = epsilon_PDir;
    epsilon_NN(m_compt,:)   = epsilon_N;
    Ksi                     = repmat(Pnoise,1,L);% N2 X L 
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%  updating the Z coefficients   %%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [Z alphan Tc] = sample_Z_bloc(Z,Y_bloc,MPlus,sigma2,epsilon_c,vect,K,Label,PDir,Ksi);
    
    %     TZ(:,:,m_compt) = Z;
    if(m_compt>Nbi)
        Ta(:,:,m_compt-Nbi) = alphan;
    end
    Taux_acceptC(:,m_compt) = Tc;
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%% updating the Dirichlet coefficients  %%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    varK = zeros(N2,R,K);
    for k=1:K
        varK((Label ==k),:,k) = (x1 - log(alphan(:,(Label ==k))))'; %N2 X R
        sumvarK(:,k)          = sum((x1 - log(alphan(:,(Label ==k)))),2); %R X K
        SumA(k) = sum(sum(log(alphan(:,(Label ==k)))));
    end
    [PDir PDirTc]                   = sample_PDir_bloc(PDir,epsilon_PDir,alphan,Label,varK,sumvarK,SumA,x1,x2);
    if(m_compt>Nbi)
        TPDir(:,:,m_compt-Nbi)    = PDir;
    end
    Taux_PDir(:,m_compt)  = PDirTc;
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%    updating the M endmembers   %%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    gammal     = ((alphan.^2)'*sigma2)+Ksi;  % N2 X L
    gammalm1   = 1./gammal';  % L X N2
    coeff1     = (-(gammalm1.*Y_bloc)*alphan')';   % R   X L
    Agama2     =  (repmat(alphan,L,1).*  kron(gammalm1,ones(R,1))   ) * alphan'; % R L X R
    [MPlus MTc]  = sample_M_bloc(alphan,Y_bloc,MPlus,sigma2,epsilon_M,MEEA,gammalm1,coeff1,Agama2);
    if(m_compt>Nbi)
        TMPlus(:,:,m_compt-Nbi)     = MPlus;
    end 
    Taux_acceptM(:,m_compt) = MTc;
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%  updating the endmembers variance  %%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    ApAp2        = alphan.^2;% R X N2
    varo         = ((Y_bloc - MPlus*alphan).^2)';% N2 X L
    
    [sigma2 TCsig]            = sample_sigma_bloc(epsilon_sig,sigma2,Y_bloc,MPlus,alphan,ApAp2,varo,Ksi);
    if(m_compt>Nbi)
        Tsigma2(:,:,m_compt-Nbi)      = sigma2;
    end 
    Taux_acceptsig(:,m_compt) = TCsig; 
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%    updating the noise variance   %%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    ApAp2sigma2             = ApAp2'*sigma2;  %N2 X L
    [Pnoise TcN]            = sample_SigNoise(epsilon_N,Pnoise',varo,ApAp2sigma2);
    Pnoise                  = Pnoise';  % N2 X 1
    if(m_compt>Nbi)
        TPnoise(:,m_compt-Nbi)      = Pnoise;
    end 
    Taux_acceptN(:,m_compt) = TcN;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%       updating the Labels      %%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [Label Flabel]            = sample_Label_bloc(Label,sigma2,Y_bloc, MPlus,alphan,K,PDir,pos1);
    if(m_compt>Nbi)
        TLabel(:,:,m_compt-Nbi)       = Label;
    end 
    TFlabel(:,m_compt)        = Flabel;
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%    updating the epsilons       %%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    if(compt == 20 & m_compt<Nbi)
        TaC          = mean(Taux_acceptC(:,m_compt-19:m_compt),2)';
        epsilon_c    = 3*epsilon_c/4.*(TaC<0.5) + 5*epsilon_c/4.*(TaC>0.8)+epsilon_c.*(TaC>=0.5 & TaC<=0.8);
        TaM          = mean(Taux_acceptM(:,m_compt-19:m_compt),2)';
        epsilon_M    = 3*epsilon_M/4.*(TaM<0.5) + 5*epsilon_M/4.*(TaM>0.8)+epsilon_M.*(TaM>=0.5 & TaM<=0.8);
        TaS          = mean(Taux_acceptsig(:,m_compt-19:m_compt),2)';
        epsilon_sig  = 3*epsilon_sig/4.*(TaS<0.5) + 5*epsilon_sig/4.*(TaS>0.8)+epsilon_sig.*(TaS>=0.5 & TaS<=0.8);
        TaPdir       = mean(Taux_PDir(:,m_compt-19:m_compt),2)';
        epsilon_PDir = 3*epsilon_PDir/4.*(TaPdir<0.5) + 5*epsilon_PDir/4.*(TaPdir>0.8)+epsilon_PDir.*(TaPdir>=0.5 & TaPdir<=0.8);
        TaN          = mean(Taux_acceptN(:,m_compt-19:m_compt),2)';
        epsilon_N    = 3*epsilon_N/4.*(TaN<0.5) + 5*epsilon_N/4.*(TaN>0.8)+epsilon_N.*(TaN>=0.5 & TaN<=0.8);
        compt = 0;
    end
    
    compt = compt +1;
end
