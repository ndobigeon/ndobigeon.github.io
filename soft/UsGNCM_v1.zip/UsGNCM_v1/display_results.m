%-------------------------------------------------------------------------
% Paper :
% A. Halimi, N. Dobigeon and J.-Y. Tourneret, "Unsupervised Unmixing of
% Hyperspectral Images Accounting for Endmember Variability", IEEE Trans. 
% Image Processing, 2015.
%
% Model:  UsGNCM (Unsupervised Generalized Normal Compositional Model)
%
% Author: Abderrahim Halimi, 2017.
%-------------------------------------------------------------------------

%% Display results
figure(1) % Abudances
for r=1:R
    subplot(2,R,r); imagesc(reshape(alpha_FCLS(r,:),N,N));title(['Abund' num2str(r)]);colormap gray
    ylabel('FCLS')
    subplot(2,R,r+R); imagesc(reshape(Abund(r,:),N,N));title(['Abund' num2str(r)]);colormap gray
    ylabel('UsGNCM') 
end

     load Results_Madona.mat Abund EndMean EndVar NoiseV DirPar Label_est ...
    NRMSE NRMSE_FCLS RE SAM RE_VCA SAM_VCA RE_Est SAM_Est timet N R Nbi Nmc MPlus MEEA alpha_FCLS alpha0
 
figure(2) % Classification
RGB_Hyspex=[55 41 12]; 
subplot(1,2,1); image(im(:,:,RGB_Hyspex)/0.6);title(['Image']);colormap gray;axis image;colorbar
subplot(1,2,2); imagesc(reshape(Label_est,N,N));title(['Est. Label']);colormap gray;colorbar;axis image


figure(3) % Endmembers
for r=1:R
    subplot(R,1,r); plot(MEEA(:,r),'b');
    hold on; plot(EndMean(:,r),'k');
    hold on; plot(EndMean(:,r)+ 3*sqrt(EndVar(r,:))','k--');
    hold on; plot(EndMean(:,r)- 3*sqrt(EndVar(r,:))','k--');
    ylabel(['Endm. ' num2str(r)]) 
    if(r==1) legend('VCA','UsGNCM')
    elseif(r==4)
        xlabel('Bands')
    end
end