function [valn] = compute_SigNoise_bloc(Pnoise,varo,ApAp2sigma2)
%-------------------------------------------------------------------------
% Paper :
% A. Halimi, N. Dobigeon and J.-Y. Tourneret, "Unsupervised Unmixing of
% Hyperspectral Images Accounting for Endmember Variability", IEEE Trans. 
% Image Processing, 2015.
%
% Model:  UsGNCM (Unsupervised Generalized Normal Compositional Model)
%
% Contact Abderrahim Halimi (a.halimi@hw.ac.uk) for any comments
%-------------------------------------------------------------------------
% zn matrice de taille (R-1 X N^2)
% yn pixels de taille (L X N^2)
% sigman2  de taille (R X L)
% Pnoise  de taille (1 X N2)
 
 
[N2 L]     = size(varo);  
Ksi        = repmat(Pnoise',1,L);  % N2 X L
gammal     = ApAp2sigma2+Ksi;  % N2 X L
gammalm1   = 1./gammal';  % L X N2 
 
parexp     = 10^7; 
U3         = 1/2*sum( log(gammal),2)'; % 1 X N2    
U2         = parexp*Pnoise;%log(Pnoise); % 1 X N2  
U1         = 0.5*sum(varo'.*gammalm1,1);   %  1 X N2  
 
valn       = U1+U2+U3;%  1 X N2  
 
 