UsGNCM 1.0

First release: Feb. 2017

----------------------------------------------------------------------------
Copyright (c) 2017, Abderrahim Halimi, Nicolas Dobigeon, Jean-Yves Tourneret

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
----------------------------------------------------------------------------

The provided set of MATLAB files contains an implementation of the algorithm
described in the following paper:

[1] A. Halimi, N. Dobigeon and J.-Y. Tourneret, "Unsupervised Unmixing of 
	Hyperspectral Images Accounting for Endmember Variability," 
	IEEE Trans. Image Processing, vol. 24, no. 12, pp. 4904-4917, 2015. 

The proposed files partly uses MATLAB functions developed by the authors of the following papers.

[1] J. M. Nascimento and J. M. Bioucas-Dias, "Vertex component analysis: 
	a fast algorithm to unmix hyperspectral data", IEEE Trans. Geosci. Remote
	Sens., vol. 43, no. 4, pp. 898-910, April 2005.
	[Associated function: vca.m]
	http://www.lx.it.pt/~bioucas/code.htm 

[2] Daniel C. Heinz and Chein-I Chang, "Fully Constrained Least Squares 
	Linear Spectral Mixture Analysis Method for Material Quantification
	in Hyperspectral Imagery", IEEE Trans. Geosci. Remote Sens., vol. 39,
  	no. 3, pp. 529-545, March 2001.
	[Associated function: FCLS_single_Pixel.m] 


CONTACT INFORMATION:

            a.halimi@hw.ac.uk


