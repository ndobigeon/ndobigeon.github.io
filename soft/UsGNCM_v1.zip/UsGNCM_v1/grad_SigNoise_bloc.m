function [dU_dsigma2] = grad_SigNoise_bloc(Pnoise,varo,ApAp2sigma2)
%-------------------------------------------------------------------------
% Paper :
% A. Halimi, N. Dobigeon and J.-Y. Tourneret, "Unsupervised Unmixing of
% Hyperspectral Images Accounting for Endmember Variability", IEEE Trans. 
% Image Processing, 2015.
%
% Model:  UsGNCM (Unsupervised Generalized Normal Compositional Model)
%
% Contact Abderrahim Halimi (a.halimi@hw.ac.uk) for any comments
%-------------------------------------------------------------------------
% zn matrice de taille (R-1 X N^2)
% yn pixels de taille (L X N^2)
% sigman2 de taille (R X L)
% sigman2mod de taille (R X N^2 X L)
% Pnoise  de taille (1 X N2)





[N2 L]    = size(varo); 
Ksi       = repmat(Pnoise',1,L);  % N2 X L 
parexp    = 10^7;

%%%%%%%%%%%%%%%%%%%%%%%%   
ApRlAp          = ApAp2sigma2+Ksi;  %N2 X L
dU1_dPnoise     = -0.5*sum(varo./(ApRlAp).^2,2)'; % 1 X N2 
dU2_dPnoise     = parexp;%  1./Pnoise ; % 1 X N2 
dU3_dPnoise     = 0.5*sum(1./ApRlAp,2)'; % 1 X N2    
dU_dsigma2      = dU1_dPnoise+dU3_dPnoise+dU2_dPnoise;  %  1 X N2 
%%%%%%%%%%%%%%%%%%%%%%%%  
 