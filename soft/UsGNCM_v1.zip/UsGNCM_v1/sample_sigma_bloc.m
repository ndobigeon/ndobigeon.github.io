function [Sigmanew SigTc] = sample_sigma_bloc(epsilon_c,sigma2,Y_bloc,MPlus,alphan,ApAp2,varo,Ksi);
                                             
%------------------------------------------------------------------
% UsGNCM by A. HALIMI  
% University of Toulouse - France - 2015
%
% INPUT 
%
% OUTPUT
%       Sigmanew     : New sampled vector
%       SigTc        : Acceptance ratio 
%
%------------------------------------------------------------------



[Lb R]            = size(MPlus); 
SigTc             = zeros(Lb,1); 
L                 = randi([45,55]);                
[Sigmanew,SigTc]  = CHMC_sampling_bloc_sigma(epsilon_c,L,sigma2,zeros(R,Lb),100*ones(R,Lb),Y_bloc,MPlus,alphan,ApAp2,varo,Ksi);
 
 


