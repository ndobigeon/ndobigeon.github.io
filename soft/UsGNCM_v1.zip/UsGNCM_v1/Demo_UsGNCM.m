clc
clear all
close all

%-------------------------------------------------------------------------
% Paper :
% A. Halimi, N. Dobigeon and J.-Y. Tourneret, "Unsupervised Unmixing of
% Hyperspectral Images Accounting for Endmember Variability", IEEE Trans. 
% Image Processing, 2015.
%
% Model:  UsGNCM (Unsupervised Generalized Normal Compositional Model)
%
% Author: Abderrahim Halimi, 2017.
%-------------------------------------------------------------------------


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%       Image (square)       %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load image_Madona.mat
% im     of size N x N x L
% MPlus  of size L x R 
% MEEA   of size L x R 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%         Constants          %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
R       = 4;            % Number of endmembers
K       = 4;            % Number of spatial classes
N       = size(im,1);   % Rows or columns
L       = size(im,3);   % Number of spectral bands
label0  = ones(1,N^2);  % Intialization of the labels
sigma2  = 0.001*ones(R,L);% Intialization of the endmember variances
sigma20 = sigma2;% Actual endmember variances (when available)
Y       = im;
Y_bloc  = reshape(Y,N^2,L)';
display = 0;

disp('Choose 1 if you want to process the image (~4 hours for 50*50 images)')
disp('Choose 2 if you only want to plot some unmixing results')
Choice = input('Make your choice:')

if(Choice ==1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% Markov chain parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% These nummbers should be adjuested with the image size
%%% Larger images require higher Nmc and Nbi
Nmc = 12000; % number of samples
Nbi = 11000; % number of burn-in period

%%% HMC parameters
epsilon_c   = 0.006*ones(1,N^2);   % HMC parameter for the abundances
epsilon_M   = 0.0006*ones(1,L);    % HMC parameter for the endmember means
epsilon_sig = 0.00006*ones(1,L);   % HMC parameter for the endmember variances
epsilon_PDir= 0.01*ones(1,K);      % HMC parameter for the Dirichlet parameters
epsilon_N   = 10^(-8)*ones(1,N^2); % HMC parameter for the noise variance


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%   Useful quantities        %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for i=1:N^2
    alpha_FCLS(:,i)  = FCLS_single_pixel(MEEA,Y_bloc(:,i));
end
Zinit(1,:) = 1-alpha_FCLS(1,:);
Zinit(1,:) = 0.001.*(Zinit(1,:) <0.001) + 0.999.*(Zinit(1,:) >0.999) + Zinit(1,:).*(Zinit(1,:)<=0.999 & Zinit(1,:)>=0.001);
for i=2:R-1
    Zinit(i,:) = 1-alpha_FCLS(i,:)./prod(Zinit(1:i-1,:),1);
    Zinit(i,:) = 0.001.*(Zinit(i,:) <0.001) + 0.999.*(Zinit(i,:) >0.999) + Zinit(i,:).*(Zinit(i,:)<=0.999 & Zinit(i,:)>=0.001);
end
alpha_FCLS=0.001*(alpha_FCLS<=0.001)+0.99*(alpha_FCLS>0.99)+alpha_FCLS.*(alpha_FCLS>0.001 & alpha_FCLS<=0.99);
alpha0 = alpha_FCLS;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%   Unmixing procedure       %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic 
[TalphaPlus TMPlus Tsigma2 TPnoise TLabel TPDir epsilon_cc epsilon_MM epsilon_ss epsilon_NN...
    Taux_acceptC  Taux_acceptM Taux_acceptsig epsilon_Pdir Taux_PDir Taux_acceptN TFlabel] = ...
    unmixing(Y,Y_bloc,MEEA,Nmc,Nbi,N,Zinit,sigma2,alpha0,epsilon_c,epsilon_M,epsilon_sig,epsilon_PDir,epsilon_N,K,label0);
timet  = toc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%          Results           %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

sigma2 = sigma20';
[NRMSE NRMSE_FCLS RE SAM RE_VCA SAM_VCA RE_Est SAM_Est Label_est] = ...
    exploitation(Y,Y_bloc,TalphaPlus,alpha0,alpha_FCLS,TMPlus,MPlus,MEEA,Tsigma2,sigma2,TLabel,label0 ,Taux_acceptC,Taux_acceptM,Taux_acceptsig,K,Nbi,Nmc,display);

close all

Abund   = mean(TalphaPlus(:,:,1:Nmc-Nbi),3); % Abundances  R x N2
EndMean = mean(TMPlus(:,:,1:Nmc-Nbi),3);     % Endmember means L x R
EndVar  = mean(Tsigma2(:,:,1:Nmc-Nbi),3);     % Endmember variances R x L
NoiseV  = mean(TPnoise(:,1:Nmc-Nbi),2);     % Noise variances N2 x 1
DirPar  = mean(TPDir(:,:,1:Nmc-Nbi),3);     % Dirichlet coefficients K X R
save Results_Madona.mat Abund EndMean EndVar NoiseV DirPar Label_est ...
    NRMSE NRMSE_FCLS RE SAM RE_VCA SAM_VCA RE_Est SAM_Est timet N R Nbi Nmc MPlus MEEA alpha_FCLS alpha0

display_results

elseif(Choice ==2)
    load Results_Madona.mat Abund EndMean EndVar NoiseV DirPar Label_est ...
    NRMSE NRMSE_FCLS RE SAM RE_VCA SAM_VCA RE_Est SAM_Est timet N R Nbi Nmc MPlus MEEA alpha_FCLS alpha0
 
    display_results
else 
    error('Choice should be 1 or 2')
end 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
     
    