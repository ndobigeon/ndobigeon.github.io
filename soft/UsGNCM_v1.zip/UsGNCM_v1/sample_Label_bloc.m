function [Labelnew Flabel] = sample_Label_bloc(label,sigma2,yn, MPlus,alphan,K,PDir,pos1);

%-------------------------------------------------------------------------
% Paper :
% A. Halimi, N. Dobigeon and J.-Y. Tourneret, "Unsupervised Unmixing of
% Hyperspectral Images Accounting for Endmember Variability", IEEE Trans. 
% Image Processing, 2015.
%
% Model:  UsGNCM (Unsupervised Generalized Normal Compositional Model)
%
% Contact Abderrahim Halimi (a.halimi@hw.ac.uk) for any comments
%-------------------------------------------------------------------------

% PDir K X R
% label sigma2

N2        = size(label,2);
N         = sqrt(N2);
beta      = 1.5;% 1.1;%0.8;%
L         = size(yn,1);

betalab2   = gammaln(sum(PDir,2))  - sum(gammaln(PDir),2); % K X1
cste       = exp(betalab2);
%%%%%%%%%%%%%
for i=1:2
    pos         = find(pos1==(i-1));
    labelmat    = reshape(label,N,N);
    labelmatip1 = circshift(labelmat, [0 -1]);
    labelmatim1 = circshift(labelmat, [0 1]);
    labelmatjp1 = circshift(labelmat, [-1 0]);
    labelmatjm1 = circshift(labelmat, [1 0]);
    
    for k=1:K
        coeff  = repmat(PDir(k,:)'-1,1,N2);
        w1(k,:) =  cste(k) * prod(alphan.^coeff).* ...
            reshape(exp(beta*(((k-labelmatip1)==0) + ((k-labelmatim1)==0) + ((k-labelmatjp1)==0) + ((k-labelmatjm1)==0))),1,N2) ; % 1 X N2 ;  
    end
    
    w           = w1(:,pos);  % 1 X N2/2 ;  
    
    G           = sum(w,1); % 1 X N2/2
    w           = w./repmat(G,K,1); % K X N2/2
    interv_prob = cumsum(w);
    
    u           = repmat(rand(1,length(pos)),K,1);
    Labelnew    = sum(u > interv_prob,1) +1;
    label(pos)  = Labelnew;
    clear pos Labelnew
end

Labelnew = label;

%%%% Cond-posterior for MAP (test)
labelmat    = reshape(Labelnew,N,N);
labelmatip1 = circshift(labelmat, [0 -1]);
labelmatim1 = circshift(labelmat, [0 1]);
labelmatjp1 = circshift(labelmat, [-1 0]);
labelmatjm1 = circshift(labelmat, [1 0]);

for k=1:K
    cste2((Labelnew==k)) = cste(k);
end
Flabel = sum(cste2.* prod(alphan.^coeff).* ...
    reshape(exp(beta*(((labelmat-labelmatip1)==0) + ((labelmat-labelmatim1)==0) + ((labelmat-labelmatjp1)==0) + ((labelmat-labelmatjm1)==0))),1,N2)) ;



  

 