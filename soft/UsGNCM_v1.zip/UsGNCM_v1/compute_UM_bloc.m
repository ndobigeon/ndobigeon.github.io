function [valn] = compute_UM_bloc(MPlus,alphan,sigman2,yn,MEEA,gammalm1) 
%-------------------------------------------------------------------------
% Paper :
% A. Halimi, N. Dobigeon and J.-Y. Tourneret, "Unsupervised Unmixing of
% Hyperspectral Images Accounting for Endmember Variability", IEEE Trans. 
% Image Processing, 2015.
%
% Model:  UsGNCM (Unsupervised Generalized Normal Compositional Model)
%
% Contact Abderrahim Halimi (a.halimi@hw.ac.uk) for any comments
%-------------------------------------------------------------------------
% MPlus matrice de taille (R X L)
% alphan abondances de taille (R X N^2)
% sigman2  de taille (1 X N^2)
% yn pixels de taille (L X N^2)

s2     =  0.0009;%0.0007;%0.005;%0.02;    %% Sur les m_vca
% s2     =  1;%0.0007;%0.005;%0.02;    %% Sur les m_vca

MPlus  = MPlus';  %matrice de taille (L X R) 
valn   = 0.5* (sum((yn - MPlus*alphan).^2.*gammalm1,2)... 
       + diag(1/s2*(MPlus-MEEA)*(MPlus-MEEA)'))'; % taille  (1 X L)
  
  