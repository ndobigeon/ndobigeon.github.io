function [Mnew MTc] = sample_M_bloc(alphan,Y_bloc,MPlus,sigma2,epsilon_c,MEEA,gammalm1,coeff1,Agama2);

%-------------------------------------------------------------------------
% Paper :
% A. Halimi, N. Dobigeon and J.-Y. Tourneret, "Unsupervised Unmixing of
% Hyperspectral Images Accounting for Endmember Variability", IEEE Trans. 
% Image Processing, 2015.
%
% Model:  UsGNCM (Unsupervised Generalized Normal Compositional Model)
%
% Contact Abderrahim Halimi (a.halimi@hw.ac.uk) for any comments
%-------------------------------------------------------------------------




Mnew   = zeros(size(MPlus')); 
Lband  = size(MPlus,1);
[R N2] = size(alphan);  
L      = randi([45,55]); %randi([605,615]);


[Mnew,MTc]      = CHMC_sampling_bloc_M(epsilon_c,L,MPlus',zeros(R,Lband),ones(R,Lband),Y_bloc,sigma2,alphan,MEEA,gammalm1,coeff1,Agama2);
  
Mnew           = Mnew'; % size L X R
MTc            = MTc(:); % size L X 1